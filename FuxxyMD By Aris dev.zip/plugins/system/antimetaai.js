let handler = m => m;

handler.before = async(m, { conn }) => {
	if (m.sender !== "13135550002@s.whatsapp.net") return;
	if (global.db.data.chats[m.chat].antiMeta) return;
	
	m.delete();
}
export default handler;