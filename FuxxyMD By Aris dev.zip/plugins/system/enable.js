let handler = async (m, { conn, usedPrefix, command, args, isOwner, isAdmin, isROwner }) => {
  let isEnable = /true|enable|(turn)?on|1/i.test(command);
  let chat = global.db.data.chats[m.chat];
  let bot = global.db.data.settings[conn.user.jid] || {};
  let type = (args[0] || '').toLowerCase();
  
  // Object to define cases and their respective properties
  const cases = {
  welcome: { 
    groupOnly: true, 
    adminOnly: true,
    key: 'welcome' 
  },
  bye: { 
    groupOnly: true, 
    adminOnly: true,
    key: 'bye' 
  },
  antinsfw: { 
    groupOnly: true, 
    adminOnly: true,
    key: 'antiNsfw' 
  },
  detect: { 
    adminOnly: true, 
    key: 'detect' 
  },
  composing: {
    rownerOnly: true,
     key: "composing"
  },
  antiviewonce: { 
    groupOnly: true,
    adminOnly: true, 
    key: 'viewonce' 
  },
  antidelete: {
    groupOnly: true,
    rownerOnly: true,
    key: 'antidelete' 
  },
  antilink: {
    groupOnly: true,
    adminOnly: true,
    key: 'antiLink'
  },
  antibot: {
    groupOnly: true,
    adminOnly: true,
    key: 'antiBot'
  },
  anticall: {
    rownerOnly: true,
    key: 'anticall',
  },
  antisticker: {
    groupOnly: true,
    adminOnly: true,
    key: 'antiSticker'
  },
  antimetaai: {
    groupOnly: true,
    adminOnly: true,
    key: 'antiMeta'
  },
  joinonly: {
    rownerOnly: true,
    key: 'allakses',
  },
  onlyprem: {
    rownerOnly: true,
    key: 'onlyprem',
  },
  autojoin: {
    rownerOnly: true,
    key: 'autoJoin'
  },
  antitoxic: {
    groupOnly: true,
    adminOnly: true,
    key: 'antiToxic'
  },
  antitagsw: {
    groupOnly: true,
    adminOnly: true,
    key: 'antiTagsw'
  },
  antispam: {
    groupOnly: true,
    adminOnly: true,
    key: 'antiSpam'
  },
  restrict: {
    opts: true,
    ownerOnly: true,
    key: 'restrict',
  },
  game: {
    groupOnly: true,
    adminOnly: true,
    key: 'games'
  },
  autoreadpc: {
    ownerOnly: true,
    key: 'autoreadpc',
  },
  rowneronly: {
    rownerOnly: true,
    key: "rownerOnly"
  },
  adminonly: {
    groupOnly: true,
    adminOnly: true,
    key: 'adminonly'
  },
  rpg: {
    groupOnly: true,
    adminOnly: true,
    key: 'rpg'
  },
  nyimak: {
    rownerOnly: true,
    key: 'nyimak',
    opts: true
  },
  autoread: {
    ownerOnly: true,
    key: 'autoread',
  },
  pconly: {
    rownerOnly: true,
    key: 'pconly',
    opts: true
  },
  gconly: {
    rownerOnly: true,
    key: 'gconly',
    opts: true
  },
  autobio: {
    rownerOnly: true,
    key: 'autoBio',
  },
  backup: {
    rownerOnly: true,
    key: 'backup',
  }
}

  if (!cases[type]) {
    // Generate list dynamically from cases object
    let list = Object.entries(cases)
      .map(
        ([key, value]) =>
          `> ${(value.key in chat ? chat[value.key] : bot[value.key]) ? "*[ON]*" : "*[OFF]*"} ${key.capitalize()}`
      )
      .join("\n");

    return m.reply(`List Option:\n\n${list}\n\nExample:\n${usedPrefix}on welcome <To activate>\n${usedPrefix}off welcome <To deactivate>`);
  }

  let caseConfig = cases[type];
  
  // Check permissions based on case config
  if (caseConfig.ownerOnly && !isOwner) {
    global.dfail("owner", m, conn);
    throw false;
  }
  if (caseConfig.rownerOnly && !isROwner) {
    global.dfail("rowner", m, conn);
    throw false;
  }
  if (caseConfig.groupOnly && !m.isGroup) {
    global.dfail("group", m, conn);
    throw false;
  }
  if (caseConfig.adminOnly && !(isAdmin || isOwner)) {
    global.dfail("admin", m, conn);
    throw false;
  }

  // Apply the setting change
  if (caseConfig.opts) {
  	global.opts[caseConfig.key] = isEnable;
  }
  
  else if (caseConfig.key in chat) {
    chat[caseConfig.key] = isEnable;
  } else if (caseConfig.key in bot) {
    bot[caseConfig.key] = isEnable;
  }

  m.reply(` *•[ Status ]•*
 
 *Type :* ${type} 
 *Pengaturan* : *${isEnable ? "Aktif ✅" : "Non Aktif ❎"}* 
 *Untuk* : ${caseConfig.groupOnly ? "Chat Ini" : "Bot Ini"}
`);
};

handler.help = ["enable", "disable"];
handler.tags = ["group", "owner"];
handler.command = /^((en|dis)able|(tru|fals)e|(turn)?o(n|ff)|[01])$/i;
handler.group = true

export default handler;