/*
   * COZY MD
   * Credit Nzx | wa.me/6282223537406
   * Dilarang share/menjual sc ini tanpa seizin saya
*/

let handler = m => m;

handler.before = async(m, { conn, isAdmin }) => {
	if (m.isBaileys && m.fromMe) return;
	if (isAdmin) return;
	if (!global.db.data.chats[m.chat].antiTagsw) return;
	if (m.mtype !== "groupStatusMentionMessage") return;
	if (!m.isGroup) return;
	
	let user = global.db.data.users[m.sender];
	let warn = 2 //Warn limit
	user.warn += 1
	if (user.warn >= warn) {
		await m.reply(`Kamu dikick karena telah mention status di grup ini dan warn melebihi batas.\nAdios`)
		await conn.groupParticipantsUpdate(m.chat, m.sender, "remove");
	} else {
		await m.reply(`Kamu terkena pelanggaran karena telah mention status di grup ini.\nPelanggaran: ${user.warn}/${warn}`);
	}
}

export default handler;