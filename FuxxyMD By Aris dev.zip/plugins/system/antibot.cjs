/*
   * COZY MD
   * Credit Nzx | wa.me/6282223537406
   * Dilarang share/menjual sc ini tanpa seizin saya
*/

async function before(m, { conn }) {
  let chat = global.db.data.chats[m.chat];
  if (chat.antiBot) {
  if (m.formMe) return
  if (m.isBaileys) {
  await m.delete()
  await conn.sendMessage(m.chat, {
  text: `Bot Terdeteksi!`,
  }, { quoted: m });
  await conn.groupParticipantsUpdate(m.chat, [m.sender], "remove");
  }
  }
}
module.exports = {
    before,
}