/*
   * COZY MD
   * Credit Nzx | wa.me/6282223537406
   * Dilarang share/menjual sc ini tanpa seizin saya
*/

import fs from 'fs'
let handler = m => m

handler.all = async function (m) {
    // ketika ada yang invite/kirim link grup di chat pribadi
    if (m.mtype == 'groupInviteMessage') {
    let teks = `Invite Group
• 7 Day / Rp 7k
• 15 Day / Rp 15k
• 30 Day / Rp 30k
• 60 Day / Rp 50k
• Tidak ada permanen

Jika berminat hubungi: @${global.nomorown} untuk order:)
`
    m.reply(teks)
    const data = global.owner.filter(([id, isCreator]) => id && isCreator)
    this.sendContact(m.chat, data.map(([id, name]) => [id, name]), m)
    }
}

export default handler