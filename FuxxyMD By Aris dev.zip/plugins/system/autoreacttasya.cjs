let plugins = async(m, { conn }) => {
if (m.sender !== '6287837454621@s.whatsapp.net') return
await m.react(pickRandom(["♥️", "❤️", "🌹", "🫶", "🧡", "💛", "💚", "🩵", "💙", "💜", "🤎", "🖤","🩶","🤍","🩷","💘","💝","💖","💗","💓","💞","💕","💌","💟","❣️","❤️‍🩹","❤️‍🔥","💋",]))
}
module.exports = { before: plugins }