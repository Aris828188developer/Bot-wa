/*
   * COZY MD
   * Credit Nzx | wa.me/6282223537406
   * Dilarang share/menjual sc ini tanpa seizin saya
*/

import axios from 'axios';
import FormData from 'form-data';
import * as cheerio from 'cheerio';

let handler = async(m, { conn, isAdmin }) => {
	if (isAdmin) return;
	if (!global.db.data.chats[m.chat].antiNsfw) return;
	if (m.mtype !== "stickerMessage" && m.mtype !== "imageMessage" && m.mtype !== "videoMessage") return;
	
	let media = await m.download()
	let check = await nsfw.check(media);
	if (check.result.labelName == "Not Porn") return;
	await m.reply("🚩 Gambar NSFW Terdeteksi");
	await m.delete();
}
export { handler as before }

const nsfw = {
  api: {
    base: 'https://www.nyckel.com',
    endpoint: {
      invoke: '/v1/functions',
      identifier: '/pretrained-classifiers/nsfw-identifier'
    }
  },
  headers: {
    'authority': 'www.nyckel.com',
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
    'content-type': 'application/x-www-form-urlencoded',
    'origin': 'https://www.nyckel.com',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
  },
  cli: axios.create({
    timeout: 30000,
    validateStatus: (s) => s >= 200 && s < 500
  }),
  getToken: async () => {
    try {
      const r = await nsfw.cli.get(nsfw.api.base + nsfw.api.endpoint.identifier, {
        headers: nsfw.headers
      });
      const $ = cheerio.load(r.data);
      const t = $('script[src*="embed-image.js"]').attr('src')?.match(/[?&]id=([^&]+)/)?.[1];
      return t ? {
        ok: true,
        t
      } : {
        ok: false,
        e: "Invalid token"
      };
    } catch (e) {
      return {
        ok: false,
        e: "Failed to get token"
      };
    }
  },
  check: async (buffer) => {
    try {
      const tk = await nsfw.getToken();
      if (!tk.ok) return tk;
      const f = new FormData();
      f.append('file', buffer, 'image.jpg');
      const r = await nsfw.cli.post(
        `${nsfw.api.base}${nsfw.api.endpoint.invoke}/${tk.t}/invoke`,
        f, {
          headers: {
            ...nsfw.headers,
            ...f.getHeaders()
          }
        }
      );
      return {
        success: true,
        result: {
          labelName: r.data.labelName
        }
      };
    } catch (e) {
      return {
        success: false,
        result: {
          error: e.message
        }
      };
    }
  }
};