const linkRegex = /anj(k|g)?|ajn?(g|k)|bang(ke|kak)|a?njin(g|k)|asw|bajingan|b(a?n)?gsa?t|ko?nto?l|me?me?(k|q)|pe?pe?(k|q)|meki|titi(t|d)|pe?ler|tetek|toket|ngewe|go?blo?k|to?lo?l|idiot|(k|ng)e?nto?(t|d)|jembut|bego|dajj?al|janc(u|o)k|pantek|(mo)?nyet|puki ?(mak)?|kimak|kampang|lonte|col(i|mek?)|pelacur|henceu?t|nigga|fuck|dick|bitch|tits|bastard|asshole|bo?ke?(p|f)/i;

module.exports.before = async function(m, { conn, isOwner, command, text }) {
    if (isOwner) return;
    
    const deleteMessage = { delete: { remoteJid: m.key.remoteJid, fromMe: false, id: m.key.id, participant: [m.sender] } };
    
    if (m.isBaileys && m.fromMe) return;
    let chat = global.db.data.chats[m.chat];
    let isGroupToxic = linkRegex.exec(m.text);
    if (chat.antiToxic && isGroupToxic && m.isGroup) {
        await conn.sendMessage(m.chat, { delete: m.key });
    }
    return !0;
};