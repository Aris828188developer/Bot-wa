const fs = require('fs');
const archiver = require('archiver');
const path = require('path');
const cron = require('node-cron');
const moment = require('moment-timezone');
const os = require('os');


const ownerNumber = global.nomorown + "@s.whatsapp.net"
let namebot = global.namebot

let backupInProgress = false;
const deleteOldBackups = () => {
  const files = fs.readdirSync(path.resolve(__dirname, '../../'));
  const backupFiles = files.filter(file => file.startsWith('backup_') && file.endsWith('.zip'));
  
  backupFiles.forEach(file => {
    fs.unlinkSync(path.resolve(__dirname, '../../', file));
  });
};


const getPing = async () => {
  const start = Date.now();
  await new Promise(resolve => setTimeout(resolve, 100));
  const end = Date.now();
  return end - start;
};


const performBackup = async (conn, chat) => {
  if (backupInProgress) {
    console.log('Backup already in progress. Skipping new backup request.');
    return;
  }
  backupInProgress = true;
  const ping = await getPing();
  
  deleteOldBackups();

  
  let backupName = `backup_${moment().tz('Asia/Jakarta').format('YYYYMMDD')}.zip`;
  let output = fs.createWriteStream(backupName);
  let archive = archiver('zip', { zlib: { level: 9 } });

  const currentTime = moment().tz('Asia/Jakarta').format('YYYY-MM-DD HH:mm:ss');

  output.on('close', function () {
    let caption = `🔹 *BACKUP* 🔹
---------------------------------
🕒 *Waktu*   : ${currentTime}
✅ *Status*  : Berhasil
📂 *Backup*  : ${backupName}
📊 *Ukuran*  : ${(archive.pointer() / 1024 / 1024).toFixed(2)} MB
🌐 *Ping*    : ${ping} ms
---------------------------------
Powered by: *${namebot}*
`;
    let targetChat = chat || ownerNumber; 
    conn.sendFile(targetChat, backupName, backupName, caption);
    backupInProgress = false;
  });

  archive.on('warning', function (err) {
    if (err.code === 'ENOENT') {
      console.warn(err);
    } else {
      let caption = `🔹 *BACKUP* 🔹
---------------------------------
🕒 *Waktu*   : ${currentTime}
✅ *Status*  : Gagal
📂 *Backup*  : ${backupName}
📊 *Ukuran*  : 0 MB
🌐 *Ping*    : ${ping} ms
---------------------------------
Powered by: *${namebot}*
`;
      conn.sendMessage(ownerNumber, { text: caption });
      backupInProgress = false;
      throw err;
    }
  });

  archive.on('error', function (err) {
    let caption = `🔹 *BACKUP* 🔹
---------------------------------
🕒 *Waktu*   : ${currentTime}
✅ *Status*  : Gagal
📂 *Backup*  : ${backupName}
📊 *Ukuran*  : 0 MB
🌐 *Ping*    : ${ping} ms
---------------------------------
Powered by: *${namebot}*
`;
    conn.sendMessage(ownerNumber, { text: caption });
    backupInProgress = false;
    throw err;
  });

  archive.pipe(output);

  archive.glob('**/*', {
    cwd: path.resolve(__dirname, '../../'),
    ignore: [
      'node_modules/**',  
      'tmp/**', 
      '.npm/**', 
      'backup_*.zip',  
      backupName       
    ]
  });

  archive.finalize();
}

let handler = async (m, { conn }) => {
  if (conn.user.jid !== global.conn.user.jid) return;

  
  if (m.key.remoteJid && m.key.remoteJid.endsWith('@g.us')) {
    conn.sendMessage(m.chat, { text: 'ꜱᴏʀʀʏ, ᴛʜɪꜱ ᴄᴏᴍᴍᴀɴᴅ ᴄᴀɴ ᴏɴʟʏ ʙᴇ ᴜꜱᴇᴅ ɪɴ ᴘʀɪᴠᴀᴛᴇ ᴄʜᴀᴛ.' });
    return;
  }

  conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key }});
  performBackup(conn, m.chat);
}

handler.help = ['backup'];
handler.tags = ['owner'];
handler.command = /^backup$/i;

handler.owner = true;

module.exports = handler;


cron.schedule('0 */6 * * *', () => {
	if (global.db.data.settings[conn.user.jid].backup) {
		performBackup(global.conn);
	}
});