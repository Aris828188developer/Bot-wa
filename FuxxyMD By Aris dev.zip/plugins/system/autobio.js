let handler= (m) => m;
handler.all = async function (m) {
  let setting = db.data.settings[this.user.jid];
  if (!setting.autoBio) return
  let _uptime = process.uptime() * 1000;
  let uptime = clockString(_uptime);
  await this.setBio(
    `${namebot} | Runtime: ${uptime} |  Mode: ${global.opts["self"] ? "Private" : opts["gconly"] ? "Group" : "Public"} | Version: ${version}`,
  ).catch((_) => _);
};

export default handler

function clockString(ms) {
  let h = isNaN(ms) ? "--" : Math.floor(ms / 3600000);
  let m = isNaN(ms) ? "--" : Math.floor(ms / 60000) % 60;
  let s = isNaN(ms) ? "--" : Math.floor(ms / 1000) % 60;
  return [h, m, s].map((v) => v.toString().padStart(2, "0")).join(":");
}