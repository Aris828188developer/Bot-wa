const didyoumean = require('didyoumean');
const similarity = require('similarity');

let handler = (m) => m;

handler.after = async function (m, { match, usedPrefix }) {
  if ((usedPrefix = (match[0] || '')[0])) {
    //if (m.plugin) return
    let noPrefix = m.text.replace(usedPrefix, '').trim();
    let alias = Object.values(global.plugins).filter(v => v.help && !v.disabled).map(v => v.help).flat(1).map(v => v.split(" ")[0].trim());
    let mean = await didyoumean(noPrefix, alias);
    let sim = similarity(noPrefix, mean);
    let similarityPercentage = parseInt(sim * 100);
    
    console.log(similarityPercentage)
    if (mean && noPrefix.toLowerCase() !== mean.toLowerCase() && similarityPercentage >= 75) {
    	if (similarityPercentage == 100) return
        await this.appenTextMessage(m, "." + mean)
    }
  }
};

module.exports = handler;