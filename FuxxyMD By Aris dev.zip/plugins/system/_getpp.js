//getpp support number recode by Angga
//No hapus wm
//wa.me/6285895954504
import fetch from "node-fetch";

let handler = async (m, { conn, command, args }) => {
  try {
    let who;
    
    if (args[0]) {
      who = args[0].includes('@') ? args[0] : args[0] + '@s.whatsapp.net';
    } else if (m.isGroup) {
      who = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted.sender;
    } else {
      who = m.quoted.sender ? m.quoted.sender : m.sender;
    }

    let pp = await conn.profilePictureUrl(who, 'image').catch((_) => "https://telegra.ph/file/24fa902ead26340f3df2c.png");
   
    conn.sendFile(m.chat, pp, "nih bang.png", 'Selesai....', m, { jpegThumbnail: await (await fetch(pp)).buffer() });
  } catch (error) {
    console.error(error);
    let sender = m.sender;
    
    let pp = await conn.profilePictureUrl(sender, 'image').catch((_) => "https://telegra.ph/file/24fa902ead26340f3df2c.png");
    conn.sendFile(m.chat, pp, 'ppsad.png', "Selesai....", m, { jpegThumbnail: await (await fetch(pp)).buffer() });
  }
}

handler.help = ['getpp <nomor telepon | @tag/reply>'];
handler.tags = ['group'];
handler.command = /^(getpp|getpic?t?|pp)$/i;

export default handler;