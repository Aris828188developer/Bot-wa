let handler = async (m, { conn }) => {
  global.db.data.chats[m.chat].isBanned = false
  m.reply('Iya iya gweh bangun')
}
handler.help = ['bangunwoi']
handler.tags = ['owner']
handler.customPrefix = /^(vynzz bangun|woi bot bangun|.bangun|.bangunwoi)$/i
handler.command = new RegExp
handler.owner,handler.mods = true

module.exports = handler