let handler = async (m, { conn, participants }) => {
  // if (participants.map(v=>v.jid).includes(global.conn.user.jid)) {
    global.db.data.chats[m.chat].isBanned = true
    conn.reply(m.chat, 'Baiklah, gweh akan tidur lagi', m)
  // } else m.reply('There is a host number here...')
}
handler.customPrefix = /^(dah tidur lagi sana|dah tidur lagi|jangan respon disini|woi gausah respon disini|gausah respon di sini|.vynzzbot off dulu|.offdulu)$/i
handler.command = new RegExp
handler.mods = true

module.exports = handler