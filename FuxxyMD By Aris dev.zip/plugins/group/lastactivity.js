let handler = async (m, { conn, command }) => {
  try {
    let now = Date.now();
    let groups = await conn.groupFetchAllParticipating();
    let an = [];

    for (let groupId in groups) {
      let metadata = groups[groupId];
      let sortedParticipants = metadata.participants
        .filter((v) => v.admin !== 'admin' && v.admin !== 'superadmin')
        .filter((v) => v.lastKnownPresence && (now - v.lastKnownPresence < 3600 * 1000)); 

      if (sortedParticipants.length > 0) {
        an.push({
          id: metadata.id,
          title: metadata.subject,
          participants: sortedParticipants
        });
      }
    }

    if (an.length > 0) {
      let teks = '```\n';
      an.forEach((v, i) => {
        teks += `* ${i + 1}. ${v.title}\n* Peserta yang baru saja offline:\n`;
        v.participants.forEach((x) => {
          teks += ` - @${x.id.split('@')[0]}\n`;
        });
        teks += '\n';
      });
      teks += '```';

      conn.reply(m.chat, teks, m, {
        contextInfo: {
          mentionedJid: an.flatMap((v) => v.participants.map((p) => p.id))
        }
      });
    } else {
      conn.reply(m.chat, 'Tidak ada orang yang baru saja offline dalam 1 jam terakhir', m);
    }
  } catch (ahh) {
    console.ahh(ahh);
    conn.reply(m.chat, 'Ahhhhhhh', m);
  }
};

handler.command = handler.help = ['lastactivity', 'listactivity'];
handler.tags = ['group'];
handler.group = true;

export default handler;