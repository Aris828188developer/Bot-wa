import fs from 'fs'
import fetch from 'node-fetch'
let handler = async(m, { conn, text, participants }) => {
	let msg = (m.quoted || m)
	let teks = (m.quoted ? m.quoted.text : text)
	let mime = ((m.quoted || m.msg).mimetype)
const fkontak = {
	"key": {
    "participants":"0@s.whatsapp.net",
		"remoteJid": "status@broadcast",
		"fromMe": false,
		"id": "Halo"
	},
	"message": {
		"contactMessage": {
			"vcard": `BEGIN:VCARD\nVERSION:3.0\nN:Sy;Bot;;;\nFN:y\nitem1.TEL;waid=${m.sender.split('@')[0]}:${m.sender.split('@')[0]}\nitem1.X-ABLabel:Ponsel\nEND:VCARD`
		}
	},
	"participant": "0@s.whatsapp.net"
}
    if (mime) {
    	let media = await msg.download()
    	conn.sendFile(m.chat, media, "", teks, fkontak, false, { mentions: participants.map(a => a.id) })
    } else {

    conn.sendMessage(m.chat, { text: teks, mentions: participants.map(a => a.id) }, {quoted:fkontak})
    }
}
handler.help = ['hidetag']
handler.tags = ['group']
handler.command = /^(h|ht|hidetag)$/i
handler.group = true
handler.admin = true

export default handler