let handler = async(m, { conn, isAdmin, text }) => {
	if (text.toLowerCase() == "on") {
		global.db.data.chats[m.chat].shutup = false
		m.reply("Berhasil ON Bot");
	} else if (text.toLowerCase() == "off") {
		global.db.data.chats[m.chat].shutup = true
		m.reply("Berhasil OFF Bot");
	} else {
		throw "Contoh: .bot off/on";
	}
}
handler.help = ["bot *[on/off]*"]
handler.tags = ["group", "main"]
handler.command = ["bot"]
handler.admin = true;
handler.group = true;

export default handler;