/*
   * COZY MD
   * Credit Nzx | wa.me/6282223537406
   * Dilarang share/menjual sc ini tanpa seizin saya
*/

let handler = async (m, { conn }) => {
	let who = m.quoted ? m.quoted.sender : m.mentionedJid ? m.mentionedJid[0] : ''
	if (!who || who.includes(conn.user.jid)) throw `*quote / @tag* salah satu !`
	try {
		await conn.groupParticipantsUpdate(m.chat, [who], 'promote')
	} catch (e) {
		console.log(e)
	}
}

handler.help = ['promote *[tag/reply]*']
handler.tags = ['group']
handler.command = /^(promote|pm)$/i

handler.admin = true
handler.botAdmin = true
handler.group = true

export default handler