import { promises, readFileSync } from 'fs'
let misi = JSON.parse(readFileSync('./lib/misi.json'))
async function handler(m, { conn, args, text, usedPrefix, command }) {
  conn.mission = conn.mission || {}
  if (m.sender in conn.mission) return m.reply("⏳ Kamu masih melakukan misi! Tunggu sampai selesai!")

  try {
    let json = misi[Math.floor(Math.random() * misi.length)]
    const cooldown = 5 * (1000 * 60) // Cooldown 5 menit
    let user = global.db.data.users[m.sender] 
    
    if (user.health === 0 || user.stamina === 0 || user.mana === 0) {
      return m.reply("⚡ Stamina kamu kurang! Ketik `.heal` untuk menggunakan potion dan melanjutkan petualangan! 🧪")
    }

    if (typeof user.lastmisi !== "number") global.db.data.users[m.sender].lastmisi = 0
    if (typeof user.exp !== "number") global.db.data.users[m.sender].exp = 0
    if (typeof user.crystal !== "number") global.db.data.users[m.sender].crystal = 0

    let timers = (cooldown - (new Date - user.lastmisi))
    if (new Date - user.lastmisi <= cooldown) return m.reply(`⏳ Misi dalam cooldown! Tunggu selama ${clockString(timers)} sebelum memulai misi lagi.`)

    if (!user.skill) return m.reply("⚔️ Kamu belum memiliki skill untuk menjalankan misi!")

    if (!(m.sender in conn.mission)) {
      conn.mission[m.sender] = {
        sender: m.sender,
        timeout: setTimeout(() => {
          m.reply('⌛ Waktu habis! Misi dibatalkan.')
          delete conn.mission[m.sender]
        }, 60000), // 1 menit untuk menerima misi
        json
      }

      let caption = `✨ *Misi Baru Telah Diberikan!*\n
🛡️ *Rank:* ${json.rank}\n
📜 *Misi:* ${json.misii}\n
🎁 *Reward:*\n
⭐ Exp: ${json.exp}\n
💎 Crystal Mana: ${json.crystal}\n
\nKetik *terima* untuk menerima misi\nKetik *tolak* untuk membatalkan misi`
      
      return conn.reply(m.chat, caption, m)
    }
  } catch (e) {
    console.error(e)
    if (m.sender in conn.mission) {
      let { timeout } = conn.mission[m.sender]
      clearTimeout(timeout)
      delete conn.mission[m.sender]
      m.reply('❌ Misi dibatalkan.')
    }
  }
}

handler.before = async m => {
  conn.mission = conn.mission || {}
  if (!(m.sender in conn.mission)) return
  if (m.isBaileys) return

  let { timeout, json } = conn.mission[m.sender]
  const cooldown = 5 * (1000 * 60) // Cooldown 5 menit
  let user = global.db.data.users[m.sender]

  let txt = (m.msg && m.msg.selectedDisplayText ? m.msg.selectedDisplayText : m.text ? m.text : '').toLowerCase()
  if (txt !== "terima" && txt !== "tolak" && txt !== "gas") return

  if (typeof user.lastmisi !== "number") global.db.data.users[m.sender].lastmisi = 0
  if (typeof user.exp !== "number") global.db.data.users[m.sender].exp = 0
  if (typeof user.crystal !== "number") global.db.data.users[m.sender].crystal = 0

  let timers = (cooldown - (new Date - user.lastmisi))
  if (new Date - user.lastmisi <= cooldown) return m.reply(`⏳ Kamu sudah menjalankan misi! Tunggu ${clockString(timers)} sebelum mencoba lagi.`)
  if (!user.skill) return m.reply("⚔️ Kamu belum memiliki skill!")

  let randomaku = Math.floor(Math.random() * 101)
  let randomkamu = Math.floor(Math.random() * 81)
  let aud = ["Mana habis", "Stamina habis", "Diserang monster", "Dibokong monster"]
  let aui = aud[Math.floor(Math.random() * aud.length)]

  try {
    if (/^terima?$/i.test(txt)) {
      if (randomaku > randomkamu) {
        m.reply(`🏅 Misi berhasil! Kamu telah menyelesaikan misi *${json.misii}* 🎉`)
        if (json.title) m.reply(`🎖️ Kamu mendapatkan title: *${json.title}*!`)
        user.exp += json.exp
        user.crystal += json.crystal
        user.title += json.title || ''
        user.misi += json.misii || ''
      } else {
        m.reply(`❌ Misi gagal! Kamu gagal karena *${aui}* 😓`)
      }
      user.lastmisi = new Date * 1
      clearTimeout(timeout)
      delete conn.mission[m.sender]
      return !0
    } else if (/^tolak?$/i.test(txt)) {
      clearTimeout(timeout)
      delete conn.mission[m.sender]
      m.reply('❌ Misi dibatalkan.')
      return !0
    }
  } catch (e) {
    clearTimeout(timeout)
    delete conn.mission[m.sender]
    m.reply('⚠️ Terjadi kesalahan saat menjalankan misi!')
    console.error(e)
  }
}

handler.help = ['mission']
handler.tags = ['rpg']
handler.command = /^(m(isi)?(ission)?)$/i

export default handler

function clockString(ms) {
  let d = Math.floor(ms / 86400000)
  let h = Math.floor(ms / 3600000) % 24
  let m = Math.floor(ms / 60000) % 60
  let s = Math.floor(ms / 1000) % 60
  return `${d} hari, ${h} jam, ${m} menit, ${s} detik`
}