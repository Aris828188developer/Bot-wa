let handler = async (m, { conn, usedPrefix, text }) => {
    let user = global.db.data.users[m.sender]
    
    let ini_txt = `🌿 [ *GUDANG BUAH KAMU* ] 🌿\n\n`
    
    ini_txt += `🍌 Pisang: *${user.pisang}*\n`
    ini_txt += `🍇 Anggur: *${user.anggur}*\n`
    ini_txt += `🥭 Mangga: *${user.mangga}*\n`
    ini_txt += `🍊 Jeruk: *${user.jeruk}*\n`
    ini_txt += `🍏 Apel: *${user.apel}*\n\n`
    
    ini_txt += `💰 *Ingin Dapat Uang?* 💰\n`
    ini_txt += `Ketik *${usedPrefix}jual* untuk menjual buah-buahanmu dan dapatkan Money 💸`

    m.reply(ini_txt)
}

handler.menufun = ['buah']
handler.tag = ['rpg']
handler.command = /^((list)?(buah|fruits?))$/i
handler.register = true

export default handler