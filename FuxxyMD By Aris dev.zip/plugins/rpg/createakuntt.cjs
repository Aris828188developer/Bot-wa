let handler = async (m, { conn, command, args, usedPrefix }) => {
    let user = global.db.data.users[m.sender];

    try {
        if (command === 'createakuntt') {
            if (args.length === 0) {
                return m.reply("Silakan masukkan nama akun TikTok Anda.\nContoh: .createakuntt Indra Furina");
            }

            let tiktokAccountName = args.join(' ');

            user.tiktok_account = tiktokAccountName;
            m.reply(`Akun TikTok Anda telah berhasil dibuat/diedit\nAkun: ${tiktokAccountName}`);
        } else if (command === 'deleteakuntt') {
            if (!user.tiktok_account) {
                return m.reply("Anda belum memiliki akun TikTok.");
            }

            // Delete akun user
            delete user.tiktok_account;
            m.reply("Akun TikTok Anda telah dihapus dari sistem kami.");
        } else if (/live/i.test(command) && args[0] === 'tiktok') {
            
            if (!user.tiktok_account) {
                return m.reply("Buat akun terlebih dahulu\nKetik: .createakuntt");
            }

        } else {
            return m.reply("Perintah tidak dikenali.\n\n*.createakuntiktok*\n> Untuk membuat atau mengedit akun TikTok Anda.\n\n*.deleteakun*\n> Untuk menghapus akun TikTok Anda dari sistem kami.");
        }
    } catch (err) {
        m.reply("Error\n\n" + err.stack);
    }
};

handler.help = ['createakuntt', 'deleteakun']; 
handler.tags = ['rpg'];
handler.command = /^(createakuntt|deleteakuntt)$/i;
handler.register = true;
handler.group = true;

module.exports = handler;