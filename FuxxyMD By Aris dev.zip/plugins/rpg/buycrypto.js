/* WM BY NZX AND FIXED BY ANGGA
HAPUS WM YAPIT 7 TURUNAN RORRRRRR
API LIMIT, TAPI SANTAI AJA PERMENIT RESET
*/

import axios from "axios";

let handler = async (m, { args, conn }) => {
    const crypto = ["btc", "xrp", "eth", "sol", "bnb"];
    const payment = ["dana", "ovo", "gopay", "bank"];
    
    if (args.length !== 3 || !crypto.includes(args[0].toLowerCase())) {
        return m.reply("Input salah! Cara: .buycrypto [token] [nominal] [payment]\nContoh: .buycrypto btc 10000 dana\nList Token: $BTC, $ETH, $XRP, $SOL, $BNB\nList Payment: Bank, Dana, Gopay, Ovo");
    }
    
    const kripto = args[0].toLowerCase();
    const nominal = parseFloat(args[1]);
    const paymentMethod = args[2].toLowerCase();

    if (isNaN(nominal) || nominal <= 0) return m.reply("Input nominal dengan benar.");
    if (nominal < 500000) return m.reply("Minimal beli crypto adalah Rp500.000.");
    if (!payment.includes(paymentMethod)) return m.reply("Input payment list dengan benar.");

    const user = global.db.data.users[m.sender];

    let prices;
    try {
        prices = await axios.get("https://api.coingecko.com/api/v3/simple/price?ids=bitcoin,ethereum,ripple,solana,binancecoin&vs_currencies=idr");
    } catch (err) {
        return m.reply("Gagal ambil harga coin crypto");
    }

    const tokn = prices.data[kripto === "btc" ? "bitcoin" : kripto === "eth" ? "ethereum" : kripto === "xrp" ? "ripple" : kripto === "sol" ? "solana" : "binancecoin"].idr;
    const nominalInCrypto = nominal / tokn;

    if (user[paymentMethod] < nominal) return m.reply(`Saldo di *${paymentMethod.toUpperCase()}* kamu tidak cukup!`);

    m.reply("*_Memproses Transaksi..._*");
    await conn.delay(Math.floor(Math.random() * (60000 - 1000 + 1)) + 1000);

    user[kripto] = (user[kripto] || 0) + nominalInCrypto;
    user[paymentMethod] -= nominal;

    let mess = `*Successfully Payout*\n\n`;
    mess += `*Token:* $${kripto.toUpperCase()}\n`;
    mess += `*Nominal:* Rp${nominal.toLocaleString("id-ID")}\n`;
    mess += `*Nominal Token:* ${nominalInCrypto} $${kripto.toUpperCase()}\n`;
    mess += `*Jumlah Token Saat Ini:* ${user[kripto]} $${kripto.toUpperCase()}`;
    
};

handler.tags = ["rpg"];
handler.help = ["buycrypto"];
handler.command = /^(buycrypto)$/i;

export default handler;