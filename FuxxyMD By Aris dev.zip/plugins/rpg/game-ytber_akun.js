let handler = async (m, { command, conn }) => {
    try {
        let user = global.db.data.users[m.sender];
        let nama = user.name || 'Tidak diketahui';
        let namayt = user.nameyt || '';
        let bsubs = user.subscriber || 0;
        let blike = user.liketotal || 0;
        let spbutton = user.silverplaybutton || 0;
        let gpbutton = user.goldplaybutton || 0;
        let dpbutton = user.diamondplaybutton || 0;

        if (!namayt) throw m.reply("[❗] Kamu belum mempunyai akun youtube\n\nbuat akun youtube-mu menggunakan perintah:\n/buatyt");

        let like = typeof blike === 'number' ? blike.toLocaleString() : '0';
        let subs = typeof bsubs === 'number' ? bsubs.toLocaleString() : '0';
        let mentionedJid = [m.sender];

        let stt = `*📛 YOUTUBE - STUDIO 📛*

┌───[ *ɪɴғᴏ ᴀᴋᴜɴ ʏᴛ* ]
│• 👤 *Pemilik:* @${m.sender.replace(/@.+/, '')}
│• 🏷️ *Nama:* ${nama}
│• 🌐 *Nama Channel:* ${namayt}
│• 👥 *Subscribers:* ${subs}
│• 👍🏻 *Total like:* ${like}
└─⬤
┌───[ *ᴀᴄʜɪᴇᴍᴠᴇɴᴛ* ]
│• ⬜ *Silver play button:* ${spbutton === 0 ? 'Belum Punya' : '✅'}
│• 🟨 *Gold play button:* ${gpbutton === 0 ? 'Belum Punya' : '✅'}
│• 💎 *Diamond play button:* ${dpbutton === 0 ? 'Belum Punya' : '✅'}
└─⬤`;

        conn.sendMessage(m.chat, {
      text: stt, 
      contextInfo: {
          mentionedJid: [m.sender], 
          forwardingScore: "999",
          isForwarded: false,
     forwardedNewsletterMessageInfo: {
          "newsletterName": null, 
          "serverMessageId": null, 
          "newsletterJid": "0@newsletter",
         }, 
                externalAdReply: {
      title: ' Y O U T U B E - S T U D I O ',
      body: 'official account YouTube of ' + namayt,
      thumbnailUrl: "https://files.catbox.moe/j9esdj.jpg",
      souceUrl: '',
      mediaType: 1,
      renderLargerThumbnail: true
      }}}, { quoted: m})
    } catch (err) {
        console.error(err);
        m.reply('Terjadi kesalahan:  ' + err.message);
    }
}

handler.tags = ['game', 'rpg']
handler.help = ['akunyt']
handler.command = /^(akunyt)$/i
handler.register = true

export default handler