/**
@credit Angga
@Kagenou - MD
@Whatsapp Bot
@Support dengan Donasi ✨
wa.me/6285895954504
**/

let Tio = async (m, { conn, command }) => {
    const user = global.db.data.users[m.sender];
    const dungeons = [
        {
            name: 'Dungeon Dark Forest',
            boss: 'Dark Beast',
            maxHealth: 500,
            currentHealth: 500,
            rewardExp: 10000,
            rewardMoney: 5000,
            difficulty: 'Medium',
            specialAttack: { name: 'Dark Roar', damage: 75, cooldown: 3 },
            phase: 1
        },
        {
            name: 'Dungeon Ice Cave',
            boss: 'Ice Dragon',
            maxHealth: 1000,
            currentHealth: 1000,
            rewardExp: 20000,
            rewardMoney: 15000,
            difficulty: 'Hard',
            specialAttack: { name: 'Ice Breath', damage: 100, cooldown: 4 },
            phase: 1
        }
    ];

    if (user.health < 50) {
        return conn.reply(m.chat, `⚠️ *Kesehatanmu tidak cukup untuk memasuki dungeon!*\nGunakan perintah *.heal* untuk memulihkan kesehatanmu.`, m);
    }

    let chosenDungeon = dungeons[Math.floor(Math.random() * dungeons.length)];
    let specialAttackCooldown = 0;

    conn.reply(m.chat, `
🔮 *Masuk Dungeon: ${chosenDungeon.name}*
🐉 Boss: ${chosenDungeon.boss}
❤️ Health Boss: ${chosenDungeon.currentHealth}/${chosenDungeon.maxHealth}
❤️ Health Kamu: ${user.health}
🗡️ Kesulitan: ${chosenDungeon.difficulty}

🔄 Gunakan perintah:
- *serang*
- *pertahanan*
- *gunakanitem*
- *gunakanskill*
`, m);

    const handleAction = async (action) => {
        let response = '';
        let damage = Math.floor(Math.random() * 50) + 50;
        switch (action) {
            case 'serang':
                chosenDungeon.currentHealth -= damage;
                response = `🔴 Kamu menyerang ${chosenDungeon.boss} dan memberikan ${damage} damage!`;
                break;

            case 'pertahanan':
                response = '🛡️ Kamu bertahan dan mengurangi damage dari serangan boss!';
                damage = Math.floor(damage / 2); // Mengurangi damage boss
                break;

            case 'gunakanitem':
                if (user.items && user.items.includes('Potion')) {
                    user.health += 100;
                    response = `💊 Kamu menggunakan potion dan memulihkan 100 kesehatan!`;
                } else {
                    response = '⚠️ Kamu tidak memiliki potion!';
                }
                break;

            case 'gunakanskill':
                if (specialAttackCooldown === 0) {
                    chosenDungeon.currentHealth -= chosenDungeon.specialAttack.damage;
                    specialAttackCooldown = chosenDungeon.specialAttack.cooldown;
                    response = `⚡ Kamu menggunakan *${chosenDungeon.specialAttack.name}* dan memberikan ${chosenDungeon.specialAttack.damage} damage!`;
                } else {
                    response = `⚠️ Skill sedang cooldown! Tunggu ${specialAttackCooldown} turn lagi untuk menggunakannya.`;
                }
                break;

            default:
                response = '⚠️ Pilihan tidak valid. Gunakan *serang*, *pertahanan*, *gunakanitem*, atau *gunakanskill*.';
                break;
        }
        if (chosenDungeon.currentHealth > 0) {
            let bossAttack = Math.floor(Math.random() * 50) + 50;
            user.health -= bossAttack;
            response += `\n\n${chosenDungeon.boss} menyerang kamu dan memberikan ${bossAttack} damage!`;
        }
        if (chosenDungeon.currentHealth <= (chosenDungeon.maxHealth * 0.5) && chosenDungeon.phase === 1) {
            chosenDungeon.phase = 2;
            response += `\n\n💥 *${chosenDungeon.boss} memasuki fase kedua!* Boss menjadi lebih kuat!`;
        }
        if (chosenDungeon.currentHealth <= 0) {
            user.exp += chosenDungeon.rewardExp;
            user.money += chosenDungeon.rewardMoney;
            return conn.reply(m.chat, `
🎉 *Kamu berhasil mengalahkan ${chosenDungeon.boss}!*
🎁 Hadiah:
- 🗡️ *Exp*: +${chosenDungeon.rewardExp}
- 💰 *Uang*: +${chosenDungeon.rewardMoney}`, m);
        } else if (user.health <= 0) {
            return conn.reply(m.chat, '💀 *Kamu kalah dalam pertarungan!*', m);
        }
        if (specialAttackCooldown > 0) specialAttackCooldown--;

        conn.reply(m.chat, `
❤️ Health Boss: ${chosenDungeon.currentHealth}/${chosenDungeon.maxHealth}
❤️ Health Kamu: ${user.health}
🔄 Gunakan perintah:
- *serang*
- *pertahanan*
- *gunakanitem*
- *gunakanskill*

${response}`, m);
    };
    switch (command) {
        case 'serang':
        case 'pertahanan':
        case 'gunakanitem':
        case 'gunakanskill':
            await handleAction(command);
            break;

        default:
            conn.reply(m.chat, '⚠️ Pilihan tidak valid. Gunakan salah satu perintah aksi.', m);
            break;
    }
};

Tio.command = /^(raid|dungeon|serang|pertahanan|gunakanitem|gunakanskill)$/i;
Tio.group = true;

export default Tio;