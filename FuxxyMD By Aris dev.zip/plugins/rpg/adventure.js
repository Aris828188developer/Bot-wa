let Tio = async (m, { conn, text, usedPrefix }) => {
    try {
        let lokasi = ['savanah', 'dessert', 'boreal forest', 'tropical forest'];
        
        if (!text || !lokasi.includes(text.toLowerCase())) {
            return conn.sendMessage(m.chat, {
                text: `🌍 *ADVENTURE - Jelajahi Dunia!*\nPilih Lokasi Petualanganmu 🧭:\n- savanah\n- dessert\n- boreal forest\n- tropical forest\n\n📖 Contoh:\n.adventure savanah`,
                buttons: [
                    {
                        buttonId: `${usedPrefix}adventure savanah`,
                        buttonText: { displayText: 'Savanah' }
                    },
                    {
                        buttonId: `${usedPrefix}adventure dessert`,
                        buttonText: { displayText: 'Dessert' }
                    },
                    {
                        buttonId: `${usedPrefix}adventure boreal forest`,
                        buttonText: { displayText: 'Boreal Forest' }
                    },
                    {
                        buttonId: `${usedPrefix}adventure tropical forest`,
                        buttonText: { displayText: 'Tropical Forest' }
                    }
                ],
                viewOnce: true,
                headerType: 5
            }, { quoted: m });
        }

        let __timers = (new Date - global.db.data.users[m.sender].lastadventure);
        let _timers = (3600000 - __timers);
        let timers = clockString(_timers);

        if (global.db.data.users[m.sender].health > 79) {
            if (new Date - global.db.data.users[m.sender].lastadventure > 3600000) {
                let health = Math.floor(Math.random() * 101);
                let exp = Math.floor(Math.random() * 10000);
                let uang = Math.floor(Math.random() * 100000);
                let diamond = Math.floor(Math.random() * 10);
                let emerald = Math.floor(Math.random() * 50);
                let itemrand = ['Potion', 'Common crate', 'Uncommon crate', 'Legendary crate'];
                let hadiah = itemrand[Math.floor(Math.random() * itemrand.length)];
                
                let str = `
🗺️ *Lokasi Petualangan*: ${text}
🎉 *Hasil Petualangan*:
❤️ *Kesehatan Berkurang:* -${health}
🗡️ *Exp:* +${exp}
💰 *Uang:* +${uang}
💎 *Diamond:* +${diamond}
🟢 *Emerald:* +${emerald}
🎁 *Hadiah Spesial:* ${hadiah}

🌟 Petualanganmu berakhir dengan sukses!
`.trim();

                conn.sendMessage(m.chat, {
                    text: str,
                    contextInfo: {
                        externalAdReply: {
                            title: 'RPG - ADVENTURE',
                            body: 'Adventure Exploring The World',
                            thumbnailUrl: 'https://files.catbox.moe/n0azm3.jpg',
                            sourceUrl: 'https://chat.whatsapp.com/F5UYBkIp9qb5CnMtwwjMyh', 
                            mediaType: 1,
                            renderLargerThumbnail: true
                        }
                    }
                }, { quoted: m });

                global.db.data.users[m.sender].health -= health;
                global.db.data.users[m.sender].exp += exp;
                global.db.data.users[m.sender].money += uang;
                global.db.data.users[m.sender].diamond += diamond;
                global.db.data.users[m.sender].emerald += emerald;
                global.db.data.users[m.sender].lastadventure = new Date * 1;
            } else {
                conn.reply(m.chat, `🚫 Kamu Sudah Berpetualang Hari Ini.\n⏳ Tunggu selama *${timers}* untuk bisa petualang lagi.`, m);
            }
        } else {
            conn.reply(m.chat, '⚠️ *Minimal 80 Health* untuk bisa berpetualang.\n🧪 Gunakan *.heal* untuk memulihkan kesehatanmu atau beli potion dengan *.buy potion (jumlah)*.', m);
        }
    } catch (e) {
        console.error(e);
        conn.reply(m.chat, '❌ Terjadi kesalahan.', m);
    }
};

Tio.help = ['adventure'];
Tio.tags = ['rpg'];
Tio.command = /^(adventure|petualang)$/i;
Tio.group = true;
Tio.fail = null;

export default Tio;

function clockString(ms) {
    let h = Math.floor(ms / 3600000);
    let m = Math.floor(ms / 60000) % 60;
    let s = Math.floor(ms / 1000) % 60;
    return [h, m, s].map(v => v.toString().padStart(2, '0')).join(':');
}