const timeout = 1800000;

let handler = async (m, { conn, usedPrefix, text }) => {
    let user = global.db.data.users[m.sender];
    let { bibitapel, bibitanggur, bibitmangga, bibitpisang, bibitjeruk, pisang, anggur, mangga, jeruk, apel } = user;

    if (bibitapel < 500 || bibitanggur < 500 || bibitmangga < 500 || bibitpisang < 500 || bibitjeruk < 500) {
        return m.reply(`🌱 *Pastikan Kamu Memiliki Semua Bibit* 🌱 

1️⃣ Bibit Apel: ${bibitapel} 
2️⃣ Bibit Mangga: ${bibitmangga} 
3️⃣ Bibit Jeruk: ${bibitjeruk} 
4️⃣ Bibit Pisang: ${bibitpisang} 
5️⃣ Bibit Anggur: ${bibitanggur} 

💰 *Ketik:* ${usedPrefix}shop buy bibitmangga 500 

*List Bibit:* 
- bibitmangga 
- bibitanggur 
- bibitpisang 
- bibitjeruk 
- bibitapel`);
    }

    let time = user.lastberkebon + timeout;
    if (new Date - user.lastberkebon < timeout) {
        throw `⏳ Anda sudah menanam! Mohon tunggu hasil panenmu selama *${msToTime(time - new Date())}* lagi.`;
    }

    if (bibitmangga > 499 && bibitapel > 499 && bibitpisang > 499 && bibitjeruk > 499 && bibitanggur > 499) {
        let pisangpoin = Math.floor(Math.random() * 500);
        let anggurpoin = Math.floor(Math.random() * 500);
        let manggapoin = Math.floor(Math.random() * 500);
        let jerukpoin = Math.floor(Math.random() * 500);
        let apelpoin = Math.floor(Math.random() * 500);

        user.pisang += pisangpoin;
        user.anggur += anggurpoin;
        user.mangga += manggapoin;
        user.jeruk += jerukpoin;
        user.apel += apelpoin;

        user.bibitpisang -= 500;
        user.bibitanggur -= 500;
        user.bibitmangga -= 500;
        user.bibitjeruk -= 500;
        user.bibitapel -= 500;
        user.lastberkebon = new Date * 1;

        let hsl = `🎉 *Selamat ${conn.getName(m.sender)}! Kamu mendapatkan:* 🎉 

🍌 +${pisangpoin} Pisang 
🍇 +${anggurpoin} Anggur 
🥭 +${manggapoin} Mangga 
🍊 +${jerukpoin} Jeruk 
🍏 +${apelpoin} Apel`;

        conn.reply(m.chat, hsl, m);

        setTimeout(() => {
            conn.reply(m.chat, `⏰ Waktunya Berkebun Lagi, Kak! 🌱`, m);
        }, timeout);
    } else {
        if (bibitmangga < 500) return m.reply(`⚠️ Pastikan Bibit Mangga Kamu *500* Untuk Bisa Berkebun`);
        if (bibitapel < 500) return m.reply(`⚠️ Pastikan Bibit Apel Kamu *500* Untuk Bisa Berkebun`);
        if (bibitpisang < 500) return m.reply(`⚠️ Pastikan Bibit Pisang Kamu *500* Untuk Bisa Berkebun`);
        if (bibitjeruk < 500) return m.reply(`⚠️ Pastikan Bibit Jeruk Kamu *500* Untuk Bisa Berkebun`);
        if (bibitanggur < 500) return m.reply(`⚠️ Pastikan Bibit Anggur Kamu *500* Untuk Bisa Berkebun`);
    }
};

handler.help = ['berkebun'];
handler.tags = ['rpg'];
handler.command = /^(berkebun)/i;
handler.group = true;
handler.limit = true;
handler.register = true

export default handler;

function msToTime(duration) {
    let milliseconds = parseInt((duration % 1000) / 100),
        seconds = Math.floor((duration / 1000) % 60),
        minutes = Math.floor((duration / (1000 * 60)) % 60),
        hours = Math.floor((duration / (1000 * 60 * 60)) % 24);

    hours = (hours < 10) ? "0" + hours : hours;
    minutes = (minutes < 10) ? "0" + minutes : minutes;
    seconds = (seconds < 10) ? "0" + seconds : seconds;

    return `${hours} Jam ${minutes} Menit ${seconds} Detik`;
}