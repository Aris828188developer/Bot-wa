const timeout = 1800000;

let handler = async (m, { conn, usedPrefix, text }) => {
    let user = global.db.data.users[m.sender];
    let time = user.lastkill + timeout;

    if (new Date() - user.lastkill < timeout) {
        return conn.reply(m.chat, `⏳ Kamu sudah melakukan kill, tunggu selama ${msToTime(time - new Date())} lagi!`, m);
    }

    if (user.pisau < 1) {
        return conn.reply(m.chat, `🔪 Kamu tidak memiliki pisau untuk kill!`, m);
    }

    let success = Math.random() > 0.3;
    let topKillUsers = Object.entries(global.db.data.users)
        .filter(([key, value]) => value.kills > 0)
        .sort((a, b) => (b[1].kills || 0) - (a[1].kills || 0))
        .slice(0, 5)
        .map(([key, value], index) => `${index + 1}. ${conn.getName(key)} - ${value.kills || 0} kills`)
        .join('\n');

    if (success) {
        let uang = 195383; 
        let kardus = 24;
        let exp = 269;
        let bank = 311001;

        user.money += uang;
        user.kardus += kardus;
        user.exp += exp;
        user.bank += bank;
        user.kills = (user.kills || 0) + 1;
        user.lastkill = new Date() * 1; 
        user.pisau -= 1;

        let cooldownMessage = msToTime(timeout);

        let responseMessage = `
🎯 Kill Reward!
🎉 Selamat! Kamu baru saja berhasil menggunakan fitur kill dan mendapatkan hadiah berikut:
💵 Uang: +${uang}
📦 Kardus: +${kardus}
⭐ EXP: +${exp}
🏦 Bank: +${bank}

Cooldown selesai dalam: ${cooldownMessage}.

👑 Top Kill Users:
${topKillUsers}

Tetap semangat dan teruslah berjuang!
        `;
        conn.reply(m.chat, responseMessage, m);
    } else {
        user.health -= 30;
        user.money -= 1000000;
        user.limit -= 10;
        user.lastkill = new Date() * 1;
        user.pisau -= 1;

        let cooldownMessage = msToTime(timeout);

        let responseMessage = `
❌ Gagal melakukan kill! Kamu dikenakan denda: 
💔 -30 Health
💸 -1000000 Money
📉 -10 Limit

Cooldown selesai dalam: ${cooldownMessage}.

👑 Top Kill Users:
${topKillUsers}

Tetap semangat dan teruslah berjuang!
        `;
        conn.reply(m.chat, responseMessage, m);
    }

    setTimeout(() => {
        conn.reply(m.chat, `Yuk waktunya kill lagi 👋…`, m);
    }, timeout);
};

handler.help = ['kill'];
handler.tags = ['rpg'];
handler.command = /^(kill)/i;
handler.group = true;
handler.fail = null;
handler.limit = true;

export default handler;

function msToTime(duration) {
    var milliseconds = parseInt((duration % 1000) / 100),
        seconds = Math.floor((duration / 1000) % 60),
        minutes = Math.floor((duration / (1000 * 60)) % 60),
        hours = Math.floor((duration / (1000 * 60 * 60)) % 24);

    hours = (hours < 10) ? "0" + hours : hours;
    minutes = (minutes < 10) ? "0" + minutes : minutes;
    seconds = (seconds < 10) ? "0" + seconds : seconds;

    return hours + " jam " + minutes + " menit " + seconds + " detik";
}