/**
@credit Tio
@Tixo MD
@Whatsapp Bot
wa.me/6282285357346
**/

import fs from 'fs';

let Tio = async (m) => {

    const codes = JSON.parse(await fs.readFileSync("./system/json/redeem/code.json"));
    
    if (codes.length === 0) {
        return m.reply('Tidak ada kode redeem yang tersedia.');
    }

    let message = "Daftar Kode Redeem:\n\n";
    
    codes.forEach(codeEntry => {
        const { code, hadiah, expired } = codeEntry;
        const remainingTime = getRemainingTime(expired);
        
        message += `Code: ${code}\nHadiah:\n`;
        
        for (const [jenis, jumlah] of Object.entries(hadiah)) {
            message += `- ${jenis}: ${jumlah}\n`;
        }

        message += `Expired: ${remainingTime}\n\n`;
    });

    m.reply(message.trim());
};

Tio.help = ['listkode'];
Tio.tags = ['rpg'];
Tio.command = /^(listkode|daftarkode)$/i;

export default Tio;

function getRemainingTime(expired) {
    const remaining = expired - Date.now();

    if (remaining <= 0) {
        return "sudah kedaluwarsa";
    }

    const hours = Math.floor(remaining / (1000 * 60 * 60));
    const minutes = Math.floor((remaining % (1000 * 60 * 60)) / (1000 * 60));

    if (hours > 0) {
        return `${hours} jam lagi`;
    } else if (minutes > 0) {
        return `${minutes} menit lagi`;
    } else {
        return "sebentar lagi";
    }
}