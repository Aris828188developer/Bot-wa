let { MessageType } = (await import('baileys-fuxxy')).default
let handler = async (m, { conn }) => {

let name = global.db.data.users[m.sender].name || 'Pengguna'
let level = global.db.data.users[m.sender].level || 1
let exp = global.db.data.users[m.sender].exp || 0
let paus = global.db.data.users[m.sender].paus || 0
let kepiting = global.db.data.users[m.sender].kepiting || 0
let gurita = global.db.data.users[m.sender].gurita || 0
let cumi = global.db.data.users[m.sender].cumi || 0
let buntal = global.db.data.users[m.sender].buntal || 0
let dory = global.db.data.users[m.sender].dory || 0
let lumba = global.db.data.users[m.sender].lumba || 0
let lobster = global.db.data.users[m.sender].lobster || 0
let hiu = global.db.data.users[m.sender].hiu || 0
let udang = global.db.data.users[m.sender].udang || 0
let ikan = global.db.data.users[m.sender].ikan || 0
let orca = global.db.data.users[m.sender].orca || 0

let kolam = `🐠 *—「 KOLAM IKAN 」—* 🐟

👤 *Nama:* ${name}
🆙 *Level:* ${level}
⭐ *Exp:* ${exp}

━━━━━━━━━━━━━━━
🐳 *Paus:* ${paus}
🦀 *Kepiting:* ${kepiting}
🐙 *Gurita:* ${gurita}
🦑 *Cumi:* ${cumi}
🐡 *Ikan Buntal:* ${buntal}
🐟 *Dory:* ${dory}
🐬 *Lumba-lumba:* ${lumba}
🦞 *Lobster:* ${lobster}
🦈 *Hiu:* ${hiu}
🦐 *Udang:* ${udang}
🐠 *Ikan Biasa:* ${ikan}
🐋 *Orca:* ${orca}

🌊 Teruslah menjaga kolammu dan tingkatkan koleksi ikannya!`.trim()

conn.reply(m.chat, kolam, m)
}

handler.help = ['kolam']
handler.tags = ['rpg']
handler.command = /^(kolam(ikan)?|kotak(ikan)?)$/i
handler.group = true
handler.register = true

export default handler

const more = String.fromCharCode(8206)
const readMore = more.repeat(4001)