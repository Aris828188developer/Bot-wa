let handler = async (m, { conn, text, usedPrefix, command }) => {
  let dapat = (Math.floor(Math.random() * 100000))
  let gagal = (Math.floor(Math.random() * 10)) // Peluang gagal
  let nomors = m.sender
  let who
  if (m.isGroup) who = m.mentionedJid[0]
  else who = m.chat
  if (!who) throw '⚠️ Tag orang yang ingin kamu rampok! 😈'
  if (typeof db.data.users[who] == 'undefined') throw 'Pengguna tidak ada dalam database 📉'

  let __timers = (new Date - global.db.data.users[m.sender].lastrob)
  let _timers = (3600000 - __timers) 
  let timers = clockString(_timers)
  let users = global.db.data.users

  if (new Date - global.db.data.users[m.sender].lastrob > 3600000) {
    if (10000 > users[who].money) throw '💸 Orang yang kamu tag tidak memiliki cukup uang. Jangan rampok orang miskin! 😔'

    if (gagal > 7) {
      users[m.sender].money -= 5000 // Penalti jika gagal
      conn.reply(m.chat, `😵 Kamu gagal merampok dan ketahuan! Polisi datang dan kamu kena denda Rp.5000. 🚓`, m)
    } else {
      users[who].money -= dapat * 1
      users[m.sender].money += dapat * 1
      conn.reply(m.chat, `💰 Sukses! Kamu berhasil merampok Rp.${dapat} dari target! 🏃‍♂️ Kabur cepat sebelum tertangkap! 😈`, m)

      if (gagal > 4) {
        let bonus = Math.floor(Math.random() * 5000)
        users[m.sender].money += bonus
        conn.reply(m.chat, `🎉 Keberuntungan ada di pihakmu! Saat melarikan diri, kamu menemukan bonus Rp.${bonus} di jalan! 🤑`, m)
      }
    }

    global.db.data.users[m.sender].lastrob = new Date * 1
  } else {
    conn.reply(m.chat, `⏳ Kamu sudah merampok baru-baru ini. Tunggu ${timers} lagi untuk merampok lagi! ⏰`, m)
  }
}

handler.help = ['merampok']
handler.tags = ['rpg']
handler.command = /^merampok|rob$/
handler.limit = true
handler.group = true
handler.register = true

export default handler

function pickRandom(list) {
  return list[Math.floor(Math.random() * list.length)]
}

function clockString(ms) {
  let d = isNaN(ms) ? '--' : Math.floor(ms / 86400000)
  let h = isNaN(ms) ? '--' : Math.floor(ms / 3600000) % 24
  let m = isNaN(ms) ? '--' : Math.floor(ms / 60000) % 60
  let s = isNaN(ms) ? '--' : Math.floor(ms / 1000) % 60
  return ['\n' + d, ' *Hari*\n ', h, ' *Jam*\n ', m, ' *Menit*\n ', s, ' *Detik* '].map(v => v.toString().padStart(2, 0)).join('')
}