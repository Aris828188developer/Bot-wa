/**
@credit Angga
@Kagenou - MD
@Whatsapp Bot
@Support dengan Donasi ✨
**/

import fetch from 'node-fetch';
import fs from 'fs';

let handler = async (m, { conn }) => {
    try {
        let u = global.db.data.users[m.sender]
        if (!u.isInJail) {
            return conn.reply(m.chat, 'Kamu tidak berada di penjara!', m);
        }
        let fineAmount = 3000000;
        if (u.money < fineAmount) {
            return conn.reply(m.chat, `Uangmu tidak cukup untuk membayar denda sebesar *${fineAmount.toLocaleString()}* 💵.`, m);
        }
        u.money -= fineAmount;
        u.isInJail = false;
        u.jailTime = 0;

        return conn.reply(m.chat, `✅ Kamu telah membayar denda sebesar *${fineAmount.toLocaleString()}* 💵 dan keluar dari penjara.`, m);

    } catch (e) {
        throw `Terjadi kesalahan.`;
    }
};

handler.help = ['payfine'];
handler.tags = ['rpg'];
handler.command = /^(payfine)$/i;
handler.group = true;

export default handler;