let handler = async (m, { conn, usedPrefix }) => {
    let user = global.db.data.users[m.sender];
    let __timers = (new Date() - user.lastnambang);
    let _timers = (10800000 - __timers);
    let timers = clockString(_timers);
    let penambang = await conn.getName(m.sender);

    if (user.stamina < 20) return m.reply(`Stamina Kamu Tidak Cukup\nHarap Isi Stamina Kamu Dengan *${usedPrefix}eat*`);
    if (__timers < 10800000) throw m.reply(`Kamu Masih Kelelahan\nHarap Tunggu ${timers} Lagi`);

    let resources = Array.from({ length: 9 }, (_, i) => Math.floor(Math.random() * (i < 4 ? (i === 0 ? 5 : (i === 1 ? 10 : 7)) : (i < 7 ? 200 : 100))) * 2);

    let [ran1, ran2, ran3, ran4, ran5, ran6, ran7, ran8, ran9] = resources;

    let teks = [
        `${penambang} tengah bekerja keras di tambang, menantikan hasil dari usahanya...`,
        `⛏️ Dengan tekun, ${penambang} mengeksploitasi tambang ini untuk mendapatkan hasil terbaik...`,
        `🔍 Setelah menunggu dengan sabar, ${penambang} menemukan lapisan yang kaya akan hasil..`,
        `🚜 Dengan hati-hati dan keahlian, ${penambang} mulai mengekstraksi hasil tambang yang berharga...`,
        `💰 Akhirnya, setelah proses yang panjang, ${penambang} berhasil mendapatkan hasil tambang yang melimpah!`,
        `*🎉 Dengan bangga, ${penambang} melihat hasil dari kerja kerasnya yang membuahkan hasil yang memuaskan!*
──────────────────────
> 💎 Berlian: ${ran1}
> ⛓️ Iron: ${ran2}
> 🪙 Emas: ${ran3}
> 🟩 Emerald: ${ran4}
> 🪨 Batu: ${ran5}
> 🟤 Clay: ${ran6}
> ⬛ Coal: ${ran7}
> 🏜️ Sand: ${ran8}
> ✨ Exp: ${ran9}

\`Stamina Kamu Berkurang -20\``
    ];

    // Update user resources
    user.diamond += ran1;
    user.iron += ran2;
    user.gold += ran3;
    user.emerald += ran4;
    user.rock += ran5;
    user.clay += ran6;
    user.coal += ran7;
    user.sand += ran8;
    user.exp += ran9;
    user.stamina -= 20;
    
    let { key } = await conn.sendMessage(m.chat, { text: `${penambang} Mencari Area Nambang.....` }, { quoted: m });

    await conn.delay(590);

    for (let i = 0; i < teks.length; i++) {
        await conn.sendMessage(m.chat, { text: teks[i], edit: key });
        await conn.delay(5000);
    }
    
    user.lastnambang = new Date() * 1;
};

handler.help = ['nambang'];
handler.tags = ['rpg'];
handler.command = /^(nambang|menambang)$/i;
handler.group = true;
handler.register = true;

export default handler;

function clockString(ms) {
    let d = isNaN(ms) ? '--' : Math.floor(ms / 86400000);
    let h = isNaN(ms) ? '--' : Math.floor(ms / 3600000) % 24;
    let m = isNaN(ms) ? '--' : Math.floor(ms / 60000) % 60;
    let s = isNaN(ms) ? '--' : Math.floor(ms / 1000) % 60;
    return ['\n' + d, ' *Hari*\n ', h, ' *Jam*\n ', m, ' *Menit*\n ', s, ' *Detik* '].map(v => v.toString().padStart(2, 0)).join('');
}