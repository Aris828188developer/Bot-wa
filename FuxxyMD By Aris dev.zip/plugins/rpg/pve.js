/**
@Created By Angga
@Kagenou - MD
@wa.me/6285895954504
**/
let handler = async (m, { conn, usedPrefix }) => {
    let user = global.db.data.users[m.sender]
    const cooldownTime = 10 * 60 * 1000; 
    const lastUsed = user.lastPve || 0;
    const timeNow = new Date().getTime();

    if (timeNow - lastUsed < cooldownTime) {
        let remainingTime = cooldownTime - (timeNow - lastUsed);
        let minutes = Math.floor(remainingTime / 60000);
        let seconds = Math.floor((remainingTime % 60000) / 1000);
        return m.reply(`⏳ *Cooldown Berlangsung!*\nSilakan tunggu *${minutes} menit* dan *${seconds} detik* lagi sebelum menggunakan fitur ini kembali.`);
    }

    if (user.level < 5) return m.reply('❗ Kamu harus mencapai *Level 5* untuk mengakses mode pertarungan ini!')

    const monsters = [
        { name: '🧟‍♂️ Goblin', level: 5, hp: 50, damage: [10, 20], effect: '💥', imgUrl: 'https://files.catbox.moe/7ctjj5.jpg' },
        { name: '🦅 Phoenix', level: 10, hp: 150, damage: [30, 40], effect: '💢', imgUrl: 'https://files.catbox.moe/nvpdlm.png' },
        { name: '🐲 Dragon', level: 20, hp: 300, damage: [40, 50], effect: '🔥', imgUrl: 'https://files.catbox.moe/usqk5y.jpg' },
        { name: '🐉 Black Dragon', level: 30, hp: 500, damage: [50, 60], effect: '☠️', imgUrl: 'https://files.catbox.moe/cx0fs5.jpg' }
    ]

    let monster = monsters.filter(m => m.level <= user.level)
    monster = monster[Math.floor(Math.random() * monster.length)]

    await conn.sendMessage(m.chat, { 
        image: { url: monster.imgUrl }, 
        caption: `🦖 *Petualangan Dimulai!* 🦖\n\n🔥 Kamu bertemu dengan *${monster.name}* (Level ${monster.level}, HP: ${monster.hp})!\n⚔️ Bersiaplah untuk *pertarungan epik*!` 
    })
    await delay(1000)

    let playerHP = user.hp || 100
    let monsterHP = monster.hp

    m.reply(`⚔️ *Pertarungan Dimulai* ⚔️\n\n💪 Kamu: *${playerHP}* HP\n👾 *${monster.name}*: *${monsterHP}* HP`)
    await delay(1000)

    while (playerHP > 0 && monsterHP > 0) {
        await conn.sendMessage(m.chat, {
            text: `🤔 *Apa tindakanmu berikutnya?*`,
            buttons: [
                {
                    buttonId: `attack_${m.sender}`,
                    buttonText: { displayText: '🔪 Serang Biasa' },
                    type: 1
                },
                {
                    buttonId: `special_${m.sender}`,
                    buttonText: { displayText: '⚡ Serangan Spesial' },
                    type: 1
                },
                {
                    buttonId: `heal_${m.sender}`,
                    buttonText: { displayText: '🛡️ Penyembuhan' },
                    type: 1
                }
            ],
            viewOnce: true,
            headerType: 1,
        }, { quoted: m })

        let response = await getActionResponse(m)

        if (response === 'attack') {
            let playerDamage = getRandom(10, 20)
            monsterHP -= playerDamage
            m.reply(`🔪 *Serangan Biasa!*\n\nKamu menyerang *${monster.name}* dan menyebabkan *${playerDamage}* damage! 💥\n\n❤️ Sisa HP *${monster.name}*: ${monsterHP}`)
        } else if (response === 'special') {
            let skillDamage = getRandom(20, 40)
            monsterHP -= skillDamage
            m.reply(`⚡ *Serangan Spesial!*\n\nKamu melepaskan kekuatan luar biasa dan menyebabkan *${skillDamage}* damage pada *${monster.name}*! 💢\n\n🔥 Sisa HP *${monster.name}*: ${monsterHP}`)
        } else if (response === 'heal') {
            let healAmount = getRandom(10, 30)
            playerHP += healAmount
            m.reply(`🛡️ *Penyembuhan Aktif!*\n\nKamu memulihkan *${healAmount}* HP! 🌟\n\n❤️ HP kamu sekarang: ${playerHP}`)
        }
        await delay(2000)

        if (monsterHP <= 0) {
            let rewardMoney = monster.level * 5000
            let rewardExp = monster.level * 200
            user.money += rewardMoney
            user.exp += rewardExp
            m.reply(`🎉 *Kemenangan!* 🎉\n\nKamu berhasil mengalahkan *${monster.name}*! 🏆\n\n💰 *Harta Rampasan*:\n+ ${rewardMoney.toLocaleString()} Money\n+ ${rewardExp} Exp`)
            break
        }

        let monsterDamage = getRandom(monster.damage[0], monster.damage[1])
        playerHP -= monsterDamage
        m.reply(`${monster.effect} *${monster.name}* menyerangmu dan menyebabkan *${monsterDamage}* damage! 😱\n\n❤️ Sisa HP kamu: ${playerHP}`)
        await delay(2000)

        if (playerHP <= 0) {
            let dendaMoney = monster.level * 2000
            user.money -= dendaMoney
            m.reply(`💀 *Kekalahan!* 💀\n\nKamu dikalahkan oleh *${monster.name}*... 😔\n\n💸 Denda: -${dendaMoney.toLocaleString()} Money`)
            break
        }
    }

    user.lastPveUsed = new Date().getTime();
}

handler.help = ['pve']
handler.tags = ['rpg']
handler.command = /^(pve)$/i
handler.register = true
handler.group = true
handler.rpg = true

export default handler

function getRandom(min, max) {
    min = Math.ceil(min)
    max = Math.floor(max)
    return Math.floor(Math.random() * (max - min + 1)) + min
}

const delay = time => new Promise(res => setTimeout(res, time))

async function getActionResponse(m) {
    return new Promise(resolve => {
        conn.ev.on('messages.upsert', async ({ messages }) => {
            let message = messages[0]
            if (message.key.remoteJid === m.chat && message.message.buttonsResponseMessage) {
                let buttonId = message.message.buttonsResponseMessage.selectedButtonId
                if (buttonId.includes('attack')) resolve('attack')
                else if (buttonId.includes('special')) resolve('special')
                else if (buttonId.includes('heal')) resolve('heal')
            }
        })
    })

}