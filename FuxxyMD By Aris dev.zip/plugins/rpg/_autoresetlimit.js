/* Auto Reset Limit By Fuxxy
mohon tidak menghapus watermark*/

import cron from 'node-cron';

let messageSentToday = false;

let handler = (m) => m;

handler.before = async function (m, { conn }) {
  // Jalankan cron setiap jam 00:00 WIB
  cron.schedule(
    '00 00 * * *',
    async () => {
      let users = global.db.data.users || {};

      // Filter user yang limitnya di bawah batas tertentu (optional)
      let resetUsers = Object.entries(users).filter(
        ([_, data]) => typeof data.limit === 'number'
      );

      if (resetUsers.length > 0 && !messageSentToday) {
        const newLimit = 150;

        resetUsers.forEach(([_, data]) => {
          data.limit = newLimit;
        });

        console.log(`[✅] Reset limit ${resetUsers.length} user ke ${newLimit}`);

        // Kirim notifikasi ke semua grup
        const groups = await conn.groupFetchAllParticipating();
        const groupIds = Object.keys(groups);

        const announcement = `📢 Limit seluruh user telah direset otomatis menjadi ${newLimit} limit.`;

        groupIds.forEach(groupId => {
          conn.fakeReply(
            groupId,
            announcement,
            '0@s.whatsapp.net',
            global.namebot,
            'status@broadcast'
          );
        });

        messageSentToday = true; // Cegah pengiriman berulang dalam satu hari

        // Reset flag keesokan harinya
        setTimeout(() => {
          messageSentToday = false;
        }, 24 * 60 * 60 * 1000); // 24 jam
      }
    },
    {
      scheduled: true,
      timezone: 'Asia/Jakarta',
    }
  );
};

export default handler;