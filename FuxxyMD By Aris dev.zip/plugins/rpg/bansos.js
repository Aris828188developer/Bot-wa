/**
@credit Angga
@Kagenou - MD
@Whatsapp Bot
@Support dengan Donasi ✨
**/

import fetch from 'node-fetch';
import fs from 'fs';

let handler = async (m, { conn, args, usedPrefix, DevMode }) => {
    try {
        let u = global.db.data.users[m.sender];
        u.lastbansos = u.lastbansos || 0;
        u.corruptionLevel = u.corruptionLevel || 0;
        u.isInJail = u.isInJail || false;
        u.jailTime = u.jailTime || 0;
        u.items = u.items || [];
        global.corruptionStats = global.corruptionStats || { totalMoney: 0, totalCaught: 0 };
        global.weeklyLeaderboard = global.weeklyLeaderboard || {};

        let Aku = `${Math.floor(Math.random() * 101)}`.trim();
        let Kamu = `${Math.floor(Math.random() * 81)}`.trim();
        let A = (Aku * 1);
        let K = (Kamu * 1);
        let kb = 'https://telegra.ph/file/afcf9a7f4e713591080b5.jpg';
        let mb = 'https://telegra.ph/file/d31fcc46b09ce7bf236a7.jpg';
        let t = (new Date - u.lastbansos);
        let timers = clockString(10800000 - t); 

        if (t < 10800000) {
            return conn.reply(m.chat, `*Sudah Melakukan Korupsi!*\n💰 Kamu harus menunggu selama:\n🕓 ${timers} untuk mencoba lagi.`, m);
        }

        if (u.isInJail) {
            let timePassed = (new Date()).getTime() - u.jailTime;
            if (timePassed < 3600000) { 
                return conn.reply(m.chat, `⚠️ Kamu masih di penjara! Tunggu ${clockString(3600000 - timePassed)} untuk keluar.`, m);
            }
            u.isInJail = false;
        }

        let randomEvent = triggerRandomEvent(u);
        if (randomEvent) {
            return conn.reply(m.chat, randomEvent.message, m);
        }

        if (A > K) {
            conn.sendFile(m.chat, kb, 'b.jpg', `*Kamu Tertangkap!* Kamu gagal melakukan korupsi dana bansos.\nDenda: *3 Juta* rupiah 💵\n\nKamu masuk penjara selama 1 jam\ngunakan .payfine untuk membayar denda dan langsung keluar dari penjara.`, m);
            u.money -= 3000000;
            u.isInJail = true;
            u.jailTime = new Date().getTime();
            global.corruptionStats.totalCaught++;
        } else if (A < K) {
            u.corruptionLevel++;
            let bonus = 3000000 + (u.corruptionLevel * 50000); 
            u.money += bonus;
            
            conn.sendFile(m.chat, mb, 'b.jpg', `*Berhasil Korupsi!*\nKamu mendapatkan dana bansos sebesar *${bonus.toLocaleString()}* 💵\n📈 Level Korupsi: ${u.corruptionLevel}.`, m);
            u.lastbansos = new Date * 1;
            global.corruptionStats.totalMoney += bonus;
            global.weeklyLeaderboard[m.sender] = (global.weeklyLeaderboard[m.sender] || 0) + bonus;
        } else {
            conn.reply(m.chat, `*Maaf!* Kamu gagal korupsi dana bansos, tetapi berhasil melarikan diri tanpa denda. 🏃`, m);
            u.lastbansos = new Date * 1;
        }
    } catch (e) {
        throw `Terjadi kesalahan.`;
    }
};

handler.help = ['bansos'];
handler.tags = ['rpg'];
handler.command = /^(bansos|korupsi)$/i;
handler.group = true;

export default handler;

function clockString(ms) {
    let d = isNaN(ms) ? '--' : Math.floor(ms / 86400000);
    let h = isNaN(ms) ? '--' : Math.floor(ms / 3600000) % 24;
    let m = isNaN(ms) ? '--' : Math.floor(ms / 60000) % 60;
    let s = isNaN(ms) ? '--' : Math.floor(ms / 1000) % 60;
    return ['\n*' + d + '* _Hari_ ☀️\n ', '*' + h + '* _Jam_ 🕐\n ', '*' + m + '* _Menit_ ⏰\n ', '*' + s + '* _Detik_ ⏱️ '].map(v => v.toString().padStart(2, 0)).join('');
}

function triggerRandomEvent(user) {
    const events = [
        {
            chance: 2.5,
            message: `🎉 *Keberuntunganmu Luar Biasa!* Kamu menemukan dana tambahan sebesar *1 Juta* 💵 dalam perjalanan korupsi!`,
            effect: () => {
                user.money += 1000000;
            },
        },
        {
            chance: 3,
            message: `⚠️ *Pengawasan Ketat!* Tidak ada peluang korupsi hari ini. Tunggu waktu yang lebih baik.`,
        },
        {
            chance: 5,
            message: `🚨 *Pengawasan Intensif!* Semua korupsi dihentikan untuk minggu ini.`,
        },
    ];

    let random = Math.random() * 100;
    let cumulativeChance = 0;

    for (let event of events) {
        cumulativeChance += event.chance;
        if (random < cumulativeChance) {
            if (event.effect) event.effect();
            return event;
        }
    }

    return null;
}