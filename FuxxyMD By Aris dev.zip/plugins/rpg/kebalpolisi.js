/**
@credit Angga
@Kagenou - MD
@Whatsapp Bot
@Support dengan Donasi ✨
**/

import fetch from 'node-fetch';
import fs from 'fs';

let handler = async (m, { conn }) => {
    try {
        let u = global.db.data.users[m.sender];
        let itemCost = 8000000
        if (u.money < itemCost) {
            return conn.reply(m.chat, `Uangmu tidak cukup untuk membeli item Kebal Polisi. Kamu membutuhkan *${itemCost.toLocaleString()}* 💵`, m);
        }
        u.money -= itemCost;
        if (!u.items.includes('Kebal Polisi')) {
            u.items.push('Kebal Polisi');
        }
        return conn.reply(m.chat, `✅ Kamu telah membeli item *Kebal Polisi* seharga *${itemCost.toLocaleString()}* 💵.\nItem ini akan mengurangi risiko penangkapan saat korupsi.`, m);

    } catch (e) {
        throw `Terjadi kesalahan.`;
    }
};

handler.help = ['kebalpolisi'];
handler.tags = ['rpg'];
handler.command = /^(kebal(polisi))$/i;
handler.group = true;

export default handler;