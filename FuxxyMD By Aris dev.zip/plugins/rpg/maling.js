const timeout = 604800000 // 7 hari dalam milidetik

let handler = async (m, { conn, usedPrefix, text }) => {
    let time = global.db.data.users[m.sender].lastmulung + timeout
    if (new Date - global.db.data.users[m.sender].lastmulung < timeout) throw `🚨 Kamu baru saja merampok bank! Tunggu selama ${msToTime(time - new Date())} lagi sebelum melakukan aksi lagi. Bersantai dulu ya! 😎`

    let botolnye = Math.floor(Math.random() * 30000)
    let kalengnye = Math.floor(Math.random() * 999)
    let kardusnye = Math.floor(Math.random() * 1000)

    global.db.data.users[m.sender].money += botolnye
    global.db.data.users[m.sender].exp += kalengnye
    global.db.data.users[m.sender].kardus += kardusnye
    global.db.data.users[m.sender].lastmulung = new Date * 1

    m.reply(`🎉 *Selamat! Kamu berhasil melakukan aksi dengan hasil:*\n
    💸 *Uang:* ${botolnye}
    📦 *Kardus:* ${kardusnye}
    ⭐ *Exp:* ${kalengnye}
    
    Jangan sampai tertangkap, lanjutkan aksi berikutnya setelah jeda waktu! 🕒`)

    setTimeout(() => {
        conn.reply(m.chat, `🚨 Ayo waktunya merencanakan perampokan berikutnya... Siapkan dirimu! 💣`, m)
    }, timeout)
}

handler.help = ['maling']
handler.tags = ['rpg']
handler.command = /^(maling)$/i
handler.owner = false
handler.register = true
handler.mods = false
handler.premium = false
handler.group = true
handler.private = false

handler.admin = false
handler.botAdmin = false

handler.fail = null
handler.limit = true
handler.exp = 0
handler.money = 0

export default handler 

function msToTime(duration) {
  var milliseconds = parseInt((duration % 1000) / 100),
    seconds = Math.floor((duration / 1000) % 60),
    minutes = Math.floor((duration / (1000 * 60)) % 60),
    hours = Math.floor((duration / (1000 * 60 * 60)) % 24)

  hours = (hours < 10) ? "0" + hours : hours
  minutes = (minutes < 10) ? "0" + minutes : minutes
  seconds = (seconds < 10) ? "0" + seconds : seconds

  return hours + " Jam " + minutes + " Menit " + seconds + " Detik"
}