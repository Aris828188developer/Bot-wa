let handler = async(m, { conn, text, usedPrefix, command, args }) => {
	if (!args[0]) throw `Perintah Salah!\n\nGunakan perintah \`${usedPrefix+command} [buy/sell] [item]\` atau:\n\`${usedPrefix+command} list\` Untuk melihat list item`
	let itemlist = ["necklace"]
	let rpg = global.db.data.rpg;
	switch (args[0]) {
		case "buy": {
			if (!args[1]) throw `Perintah Salah!\n\nGunakan perintah \`${usedPrefix+command} buy [item]\``
			let item = args[1]
			if (!Object.keys(rpg.ah).includes(item)) throw `Tidak ada item yang dijual untuk *${item.toUpperCase()}*`
			conn.ah = conn.ah || {}
			let itm = rpg.ah[item]
			let price = Object.keys(Object.fromEntries(Object.entries(itm).sort(([keys, key]) => Number(keys) - Number(key))))
			let selectitm = itm[price[0]]
			if (global.db.data.users[m.sender].bank < price[0]) throw `Saldo di bank mu tidak cukup. Isi bank dulu sebesar *${price[0]}*`
			let msg = await conn.sendMessage(m.chat, { text: `*Apakah kamu yakin, ingin membeli ${item.toUpperCase} seharga ${price[0]} ?. React Emoji ini untuk konfirmasi:*\n\n-- ❤️: Beli\n-- 👍: Tidak\n` }, { quoted: m });
			conn.ah[msg.key.id] = {
				sender: m.sender,
				item: item,
				price: price[0],
				msg: m
			}
		}
		break;
		case "sell": {
			if (!args[1]) throw `Perintah Salah!\n\nGunakan perintah \`${usedPrefix+command} sell [item] [price]\``
		}
		break;
	}
}
handler.command = handler.help = ["ah", "actionhouse"];
handler.tags = ["rpg"];
handler.rpg = true;

handler.before = async (m, { conn }) => {
	if (!conn.ah) return;
	if (!m.message?.reactionMessage) return;
	if (!(m.message?.reactionMessage?.key?.id in conn.ah)) return;
	
	let id = m.message?.reactionMessage?.key?.id
	let { msg, sender, item, price } = conn.ah[id];
	if (m.sender !== sender) return;
	if (m.message.reactionMessage.text == "❤️") {
		if (!global.db.data.rpg.ah[item] || !global.db.data.rpg.ah[item][price]) {
			delete conn.ah[id]
			return conn.sendMessage(m.chat, { text: `Tidak ada *${item.toUpperCase()}* dengan harga *${price}* di action house. Coba cek lagi` }, { quoted: msg })
		}
		if (global.db.data.users[sender].bank < price) return conn.sendMessage(m.chat, { text: `Saldo di bank mu tidak cukup. Isi bank dulu sebesar *${price}*` }, { quoted: msg });
		global.db.data.users[sender].bank -= price;
		global.db.data.users[sender][item] = global.db.data.users[sender][item] || 0
		global.db.data.users[sender][item] += 1
		delete conn.ah[id]
		await conn.sendMessage(global.db.data.rpg.ah[item][price].owner, { text: `Barang kamu sudah dibeli oleh *${m.name}*. Saldo bank kamu +${price - (price * (5 / 100))} (5% tax)` });
		global.db.data.users[global.db.data.rpg.ah[item][price].owner].bank += price - (price * (5 / 100))
		delete global.db.data.rpg.ah[item][price]
		
		return conn.sendMessage(m.chat, { text: `*[ ✅ ]* Berhasil membeli *${item.toUpperCase()}* seharga *${price}*. Saldo saat ini: *${global.db.data.users[sender].bank}*` }, { quoted: msg });
	} else if (m.message.reactionMessage.text == "👍") {
		delete conn.ah[id];
		conn.sendMessage(m.chat, { text: `Dibatalkan.` });
	}
}

export default handler;