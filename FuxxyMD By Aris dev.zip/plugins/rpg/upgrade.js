let handler = async (m, { conn, command, args, usedPrefix }) => { 
    try { 
        let user = global.db.data.users[m.sender];
        let kayu = user.kayu * 1;
        let batu = user.batu * 1;
        let string = user.string * 1;
        let money = user.money * 1;
        let iron = user.iron * 1;
        let fishingrod = user.fishingrod * 1;
        let pickaxe = user.pickaxe * 1;
        let sword = user.sword * 1;
        let type = (args[0] || '').toLowerCase();
        let prefix = usedPrefix;
        
        const buttons1 = [
            { buttonId: `${prefix}craft fishingrod`, buttonText: { displayText: `🔨 Craft ${rpg.emoticon('fishingrod')} FishingRod` }, type: 1 },
            { buttonId: `${prefix}craft pickaxe`, buttonText: { displayText: `🔨 Craft ${rpg.emoticon('pickaxe')} Pickaxe` }, type: 1 },
            { buttonId: `${prefix}craft sword`, buttonText: { displayText: `🔨 Craft ${rpg.emoticon('sword')} Sword` }, type: 1 },
        ];

        let lmao1 = `🛠️ Gunakan Format *${usedPrefix}${command} [type]*\nContoh: *${usedPrefix}${command} fishingrod*\n\n*📌List yang Bisa Di Upgrade:*\n${rpg.emoticon('fishingrod')} FishingRod\n${rpg.emoticon('pickaxe')} Pickaxe\n${rpg.emoticon('sword')} Sword`.trim();

        const buttonMessage1 = {
            text: lmao1,
            footer: wm,
            buttons: buttons1,
            headerType: 1
        };

        switch (type) {
            case 'fishingrod':
                if (fishingrod == 0) {
                    const buttons = [
                        { buttonId: usedPrefix + `craft fishingrod`, buttonText: { displayText: `🔨 Craft ${rpg.emoticon('fishingrod')} FishingRod` }, type: 1 },
                    ];
                    let lmao = `❌ Anda belum memiliki *🎣 FishingRod*\nUntuk mendapatkannya, ketik *${usedPrefix}craft fishingrod*`;
                    const buttonMessage = {
                        text: lmao,
                        footer: wm,
                        buttons: buttons,
                        headerType: 1
                    };
                    return conn.sendMessage(m.chat, buttonMessage, { quoted: m });
                }
                if (fishingrod > 9) return conn.sendButton(m.chat, `✅ *${rpg.emoticon('fishingrod')} FishingRod* kamu sudah level max!`, wm, 'Inventory', usedPrefix + 'inv', m);
                let _kayu = fishingrod * 25;
                let _string = fishingrod * 15;
                let _money = fishingrod * 10000;
                if (kayu < _kayu || string < _string || money < _money) {
                    return conn.sendButton(m.chat, `❌ Material kamu kurang!!\n${kayu < _kayu ? `🔨 Kayu Kamu Kurang: *${_kayu - kayu}*` : ''}${string < _string ? `\n📜 String Kamu Kurang: *${_string - string}*` : ''}${money < _money ? `\n💰 Uang Kamu Kurang: *${_money - money}*` : ''}`, wm, 'Cek Inventory', usedPrefix + 'inv', m);
                }
                user.fishingrod += 1;
                user.kayu -= _kayu;
                user.string -= _string;
                user.money -= _money;
                user.fishingroddurability = fishingrod * 50; 
                conn.send2Button(m.chat, `🎉 Succes mengupgrade *${rpg.emoticon('fishingrod')} FishingRod*`, wm, 'Menu', usedPrefix + 'menu', 'Inventory', usedPrefix + 'inv', m);
                break;
            case 'pickaxe':
                if (pickaxe == 0) {
                    const buttons = [
                        { buttonId: usedPrefix + `craft pickaxe`, buttonText: { displayText: `🔨 Craft ${rpg.emoticon('pickaxe')} Pickaxe` }, type: 1 },
                    ];
                    let lmao = `❌ Anda belum memiliki *⛏️ Pickaxe*\nUntuk memilikinya, ketik *${usedPrefix}craft pickaxe*`;
                    const buttonMessage = {
                        text: lmao,
                        footer: wm,
                        buttons: buttons,
                        headerType: 1
                    };
                    return conn.sendMessage(m.chat, buttonMessage, { quoted: m });
                }
                if (pickaxe > 9) return conn.sendButton(m.chat, `✅ *${rpg.emoticon('pickaxe')} Pickaxe* kamu sudah level max!`, wm, 'Inventory', usedPrefix + 'inv', m);
                let __batu = pickaxe * 25;
                let __kayu = pickaxe * 15;
                let __money = pickaxe * 15000;
                if (batu < __batu || kayu < __kayu || money < __money) {
                    return conn.sendButton(m.chat, `❌ Material kamu kurang!!\n${batu < __batu ? `🔨 Batu kamu kurang: *${__batu - batu}*` : ''}${kayu < __kayu ? `\n🔨 Kayu kamu kurang: *${__kayu - kayu}*` : ''}${money < __money ? `\n💰 Uang kamu kurang: *${__money - money}*` : ''}`, wm, 'Cek Inventory', usedPrefix + 'inv', m);
                }
                user.pickaxe += 1;
                user.kayu -= __kayu;
                user.batu -= __batu;
                user.money -= __money;
                user.pickaxedurability = pickaxe * 50; 
                conn.sendButton(m.chat, `🎉 Succes mengupgrade *${rpg.emoticon('pickaxe')} Pickaxe*`, wm, 'Inventory', usedPrefix + 'inv', m);
                break;
            case 'sword':
                if (sword == 0) {
                    const buttons = [
                        { buttonId: usedPrefix + `craft sword`, buttonText: { displayText: `🔨 Craft ${rpg.emoticon('sword')} Sword` }, type: 1 },
                    ];
                    let lmao = `❌ Anda belum memiliki *⚔️ Sword*\nUntuk memilikinya, ketik *${usedPrefix}craft sword*`;
                    const buttonMessage = {
                        text: lmao,
                        footer: wm,
                        buttons: buttons,
                        headerType: 1
                    };
                    return conn.sendMessage(m.chat, buttonMessage, { quoted: m });
                }
                if (sword > 9) return conn.sendButton(m.chat, `✅ *${rpg.emoticon('sword')} Sword* kamu sudah level max!`, wm, 'Inventory', usedPrefix + 'inv', m);
                let _iron = sword * 25;
                let ___kayu = sword * 15;
                let ___money = sword * 10000;
                if (iron < _iron || kayu < ___kayu || money < ___money) {
                    return conn.sendButton(m.chat, `❌ Material kamu kurang!!\n${iron < _iron ? `⚔️ Iron kamu kurang: *${_iron - iron}*` : ''}${kayu < ___kayu ? `\n🔨 Kayu kamu kurang: *${___kayu - kayu}*` : ''}${money < ___money ? `\n💰 Uang kamu kurang: *${___money - money}*` : ''}`, wm, 'Cek Inventory', usedPrefix + 'inv', m);
                }
                user.sword += 1;
                user.iron -= _iron;
                user.kayu -= ___kayu;
                user.money -= ___money;
                user.sworddurability = sword * 50; 
                conn.sendButton(m.chat, `🎉 Succes mengupgrade *${rpg.emoticon('sword')} Sword*`, wm, 'Inventory', usedPrefix + 'inv', m);
                break;
            default:
                return conn.sendMessage(m.chat, buttonMessage1, { quoted: m });
        }
    } catch (e) {
        console.log(e);
        throw e; // Fixed typo from `eror` to `e`
    }
};

handler.help = ['upgrade'];
handler.tags = ['rpg'];
handler.command = /^(up(grade)?)$/i;
handler.fail = null;
handler.register = true

export default handler;