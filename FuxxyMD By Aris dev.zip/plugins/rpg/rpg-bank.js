/**
@credit Tio
@Tixo MD
@Whatsapp Bot
@Support dengan Donasi ✨
wa.me/6282285357346
**/

let Tio = async (m, { conn, command, args }) => {
    let user = global.db.data.users[m.sender]
    let name = conn.getName(m.sender)
    user.bankLevel = user.bankLevel ? user.bankLevel : 0
    user.bankLimit = user.bankLimit ? user.bankLimit : 0

    switch (command) {
        case 'bank':
            if (user.bankLevel < 1) return conn.reply(m.chat, `Kamu belum memiliki rekening bank. Buat dengan cara *\.createbank*`, m)
            showBank(m, conn, user, name)
            break

        case 'createbank':
            if (user.bankLevel > 0) {
                conn.reply(m.chat, `Kamu sudah memiliki rekening bank!`, m)
            } else {
                user.bankLevel = 1
                user.bankLimit = 1000000 // Limit awal Rp 1.000.000
                conn.reply(m.chat, `Rekening bank berhasil dibuat dengan limit awal Rp ${toRupiah(user.bankLimit)}!`, m)
            }
            break

        case 'hapusbank':
            if (user.bankLevel === 0) {
                conn.reply(m.chat, `Kamu belum memiliki rekening bank untuk dihapus.`, m)
            } else {
                user.bankLevel = 0
                user.bankLimit = 0
                user.bank = 0
                conn.reply(m.chat, `Rekening bank kamu telah dihapus.`, m)
            }
            break

        case 'nabung':
            if (user.bankLevel === 0) {
                conn.reply(m.chat, `Kamu belum memiliki rekening bank. Gunakan perintah *createbank* untuk membuat.`, m)
            } else if (!args[0] || isNaN(args[0]) || parseInt(args[0]) <= 0) {
                conn.reply(m.chat, `Gunakan format *nabung <jumlah>* untuk menabung.`, m)
            } else {
                let amount = parseInt(args[0])
                if (user.money < amount) {
                    conn.reply(m.chat, `Uang kamu tidak cukup untuk menabung Rp ${toRupiah(amount)}.`, m)
                } else if (user.bank + amount > user.bankLimit) {
                    conn.reply(
                        m.chat,
                        `Saldo bank kamu akan melebihi limit. Upgrade bank terlebih dahulu untuk meningkatkan limit.`,
                        m
                    )
                } else {
                    user.money -= amount
                    user.bank += amount
                    conn.reply(
                        m.chat,
                        `Berhasil menabung Rp ${toRupiah(amount)}. Saldo bank saat ini: Rp ${toRupiah(
                            user.bank
                        )}.`,
                        m
                    )
                }
            }
            break

        case 'tarik':
            if (user.bankLevel === 0) {
                conn.reply(m.chat, `Kamu belum memiliki rekening bank. Gunakan perintah *createbank* untuk membuat.`, m)
            } else if (!args[0] || isNaN(args[0]) || parseInt(args[0]) <= 0) {
                conn.reply(m.chat, `Gunakan format *tarik <jumlah>* untuk menarik uang.`, m)
            } else {
                let amount = parseInt(args[0])
                if (user.bank < amount) {
                    conn.reply(m.chat, `Saldo bank tidak cukup untuk menarik Rp ${toRupiah(amount)}.`, m)
                } else {
                    user.bank -= amount
                    user.money += amount
                    conn.reply(
                        m.chat,
                        `Berhasil menarik Rp ${toRupiah(amount)}. Sisa saldo bank: Rp ${toRupiah(user.bank)}.`,
                        m
                    )
                }
            }
            break

        case 'upgradebank':
            if (user.bankLevel === 0) {
                conn.reply(m.chat, `Kamu belum memiliki rekening bank. Gunakan perintah *createbank* untuk membuat.`, m)
            } else if (user.money < 1000000) {
                conn.reply(m.chat, `Uang kamu tidak cukup untuk upgrade bank. Dibutuhkan Rp 1.000.000.`, m)
            } else {
                user.money -= 1000000
                user.bankLevel += 1
                user.bankLimit *= 2 
                conn.reply(
                    m.chat,
                    `Berhasil meng-upgrade bank ke level ${user.bankLevel}. Limit saldo sekarang: Rp ${toRupiah(
                        user.bankLimit
                    )}.`,
                    m
                )
            }
            break

        default:
            conn.reply(m.chat, `Perintah tidak ditemukan.`, m)
            break
    }
}

Tio.help = ['bank', 'createbank', 'hapusbank', 'nabung <jumlah>', 'tarik <jumlah>', 'upgradebank']
Tio.tags = ['rpg']
Tio.command = /^(bank|createbank|hapusbank|nabung|tarik|upgradebank)$/i

Tio.register = false
export default Tio

function showBank(m, conn, user, name) {
    let bank = user.bank
    let caption = `「 *BANK USER* 」
- *Name:* ${user.registered ? user.name : name}
- *Level Bank:* ${user.bankLevel > 0 ? 'Level ' + user.bankLevel : 'Tidak Punya'}
- *Saldo Bank:* Rp ${toRupiah(user.bank)}
- *Limit Saldo:* Rp ${toRupiah(user.bankLimit)}
- *Uang Tunai:* Rp ${toRupiah(user.money)}
└─────────────────────···
`.trim()

      conn.sendMessage(m.chat, {
    text: caption,
    contextInfo: {
      externalAdReply: {
        title: 'B A N K',
        thumbnailUrl: 'https://telegra.ph/file/9bb25df62f06b289bf31f.jpg',
        mediaType: 1,
        renderLargerThumbnail: true
      }
    }
  }, { quoted: m });
}

function toRupiah(angka) {
    let reverse = angka.toString().split('').reverse().join('')
    let ribuan = reverse.match(/\d{1,3}/g)
    ribuan = ribuan.join('.').split('').reverse().join('')
    return ribuan
}