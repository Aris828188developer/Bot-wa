/**
@credit Angga
@Kagenou MD
@Whatsapp Bot
wa.me/6285895954504
**/

let handler = async (m, { conn }) => {
    const user = global.db.data.users[m.sender];
    const today = new Date().toISOString().slice(0, 10);

    if (user.lastDaily === today) {
        return conn.reply(m.chat, `🌟 Kamu sudah menyelesaikan misi harian hari ini!\nTunggu besok untuk mendapatkan misi baru.`, m);
    }

    let rewardExp = Math.floor(Math.random() * 5000) + 1000;
    let rewardMoney = Math.floor(Math.random() * 5000) + 1000;
    let rewardItem = ['Potion', 'Common crate', 'Uncommon crate', 'Legendary crate'][Math.floor(Math.random() * 4)];

    user.lastDaily = today; 
    user.exp += rewardExp;
    user.money += rewardMoney;

    conn.reply(
        m.chat,
        `
🎯 *MISI HARIAN!*
📋 Selesaikan misi sederhana dan dapatkan hadiah!

✅ Misi: Berpetualang di satu lokasi.
🎁 Hadiah:
- 🗡️ *Exp*: +${rewardExp}
- 💰 *Uang*: +${rewardMoney}
- 🎁 *Hadiah*: ${rewardItem}

🌟 Kamu telah berhasil menyelesaikan misi harian hari ini!
`.trim(),
        m
    );
};

handler.command = /^(task)$/i;
handler.tags = ["rpg"]
handler.group = true;
export default handler;