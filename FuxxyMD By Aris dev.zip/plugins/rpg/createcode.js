/**
@credit Tio
@Tixo MD
@Whatsapp Bot
wa.me/6282285357346
**/

import fs from 'fs';

let Tio = async (m, { conn, text }) => {
    let bybu = generateRandomCode(8);
    
    let hadiah = parseHadiah(text.split(', '));
    if (!hadiah) return m.reply('Format hadiah tidak valid! Gunakan format seperti: createcode 1 -limit, 2 -money');

    const codes = JSON.parse(await fs.readFileSync("./system/json/redeem/code.json"));
    
    const expiredTime = Date.now() + 86400000;
    codes.push({ code: bybu, hadiah, expired: expiredTime });
    
    fs.writeFileSync("./system/json/redeem/code.json", JSON.stringify(codes, null, 2));

    m.reply(`Success!!\nCodenya Adalah: ${bybu}\nHadiah:\n${await cap(hadiah)}\nExpired: ${await timer(expiredTime)}`);
};

Tio.help = ['buatkode'];
Tio.tags = ['rpg'];
Tio.command = /^(buatkode|createreedem)$/i;
Tio.rowner = true
export default Tio;

function generateRandomCode(length) {
    const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let result = '';
    const charactersLength = characters.length;
    for (let i = 0; i < length; i++) {
        result += characters.charAt(Math.floor(Math.random() * charactersLength));
    }
    return result;
}

function parseHadiah(args) {
    const hadiah = {};
    for (let i = 0; i < args.length; i++) {
        const [jumlah, jenis] = args[i].trim().split(' -');
        const jumlahInt = parseInt(jumlah);
        
        if (isNaN(jumlahInt) || !jenis) return null;
        hadiah[jenis] = jumlahInt;
    }
    return hadiah;
}

function cap(hadiah) {
    let caption = '';
    for (const [jenis, jumlah] of Object.entries(hadiah)) {
        caption += `- ${jenis}: ${jumlah}\n`;
    }
    return caption.trim();
}
function timer(expired) {
    const remaining = expired - Date.now();

    if (remaining <= 0) {
        return "sudah kedaluwarsa";
    }

    const hours = Math.floor(remaining / (1000 * 60 * 60));
    const minutes = Math.floor((remaining % (1000 * 60 * 60)) / (1000 * 60));

    if (hours > 0) {
        return `${hours} jam lagi`;
    } else if (minutes > 0) {
        return `${minutes} menit lagi`;
    } else {
        return "sebentar lagi";
    }
}