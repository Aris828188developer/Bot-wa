import axios from 'axios';
import cheerio from 'cheerio';
const handler = async (m, { conn, args }) => {
    if (!args.length) {
        return conn.reply(m.chat, '_Mau cari berita apa?_', m);
    }

    const query = args.join(" ");
    const searchUrl = `https://www.inews.id/find?q=${encodeURIComponent(query)}`;

    try {
        const { data } = await axios.get(searchUrl);
        const $ = cheerio.load(data);
        const results = [];
        $('article.cardArticle').each((i, element) => {
            const title = $(element).find('h3.cardTitle').text().trim() || 'Tidak ada judul';
            const url = $(element).find('a').attr('href') || '#';
            const date = $(element).find('div.postTime').text().trim() || 'Tidak ada tanggal';
            if (title && url && date) {
                results.push({ title, url, date });
            }
        });
        if (results.length === 0) {
            return conn.reply(m.chat, 'Tidak ada hasil ditemukan.', m);
        } else {
            let message = 'Hasil pencarian berita iNews:\n\n';
            results.forEach((result, index) => {
                const resultTitle = result.title || 'Tidak ada judul';
                const resultDate = result.date || 'Tidak ada tanggal';
                const resultUrl = result.url || '#';

                message += `${index + 1}. *${resultTitle}*\n`;
                message += `📅 ${resultDate}\n`;
                message += `🔗 [Baca lebih lanjut](${resultUrl})\n`;
                message += `\n`;
            });
            await conn.reply(m.chat, message, m);
        }
    } catch (error) {
        console.error("Error:", error);
        await conn.reply(m.chat, 'Terjadi kesalahan saat mengambil berita.', m);
    }
};
handler.help = ['inews <query>'];
handler.tags = ['news'];
handler.command = /^inews$/i;
export default handler;