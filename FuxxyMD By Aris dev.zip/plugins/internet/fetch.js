import axios from 'axios';
import { format } from 'util';

const regex = /(?:https?:\/\/)?(?:[a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}(?:\/[^\s'"`]*)?/i;

let handler = async (m, { text, args, conn }) => {
  if (!regex.test(text) && !regex.test(m.quoted?.text)) {
    return await m.reply('Reply Or Type *URL!*');
  }

  let __url;
  if (m.quoted?.text) {
    let link = m.quoted.text.match(regex);
    link = link.map(url => (/^https?:\/\//.test(url) ? url : `https://${url}`));
    __url = link.length > 1 ? link[Number(text) - 1] : link[0];
  } else {
    __url = text.startsWith('http') ? args[0] : `https://${args[0]}`;
  }

  let post;
  let payload;

  if (text.includes('--post')) {
    let param = text.match(/{.*}/);
    if (!param) return await m.reply('No payload detected.');
    post = true;

    try {
      const jsonString = param[0].replace(/([a-zA-Z0-9_]+):/g, '"$1":');
      payload = JSON.parse(jsonString);
    } catch (e) {
      throw `Invalid Payload: ${param[0]}`;
    }
  }

  let pl = { method: 'POST', ...payload };
  await m.reply(`*Fetching* ${__url} ...\nMethod: \`${post ? `Post\`\n${format(pl)}` : 'Get'}\``);

  let _url = new URL(__url);
  let url = global.API(
    _url.origin,
    _url.pathname,
    Object.fromEntries(_url.searchParams.entries()),
    'APIKEY'
  );

  const headers = {
    'User-Agent': 'Mozilla/5.0 (Linux; Android 10; SM-G973F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.114 Mobile Safari/537.36'
  };

  try {
    let res;
    if (post) {
      res = await axios.post(url, payload, { headers });
    } else {
      res = await axios.get(url, { headers });
    }

    const contentType = res.headers['content-type'];
    const contentLength = res.headers['content-length'];

    if (contentLength > 100 * 1024 * 1024 * 1024) {
      throw `Content-Length: ${contentLength}`;
    }

    if (!/text|json/.test(contentType)) {
      return conn.sendFile(m.chat, url, 'file', __url, m);
    }

    let txt;
    try {
      txt = format(res.data);
    } catch (e) {
      txt = res.data.toString();
    }

    m.reply(txt.slice(0, 65536) + '');
  } catch (error) {
    throw error.response?.data;
  }
};

handler.help = ['fetch', 'get'].map(v => v + ' *[url]*');
handler.tags = ['internet'];
handler.command = /^(fetch|get)$/i;

export default handler;