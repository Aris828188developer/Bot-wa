// * Code By Nazand Code
// * Fitur Info New Anime Baru Rilis (Dibuat Krn Gabut)
// * Hapus Wm Denda 500k Rupiah
// * https://whatsapp.com/channel/0029Vaio4dYC1FuGr5kxfy2l

import axios from 'axios';
import cheerio from 'cheerio';

const handler = async (m, { conn }) => {
  try {
    const malUrl = 'https://myanimelist.net/anime/season';
    const response = await axios.get(malUrl);
    const $ = cheerio.load(response.data);
    const latestAnime = [];
    $('.seasonal-anime').each((index, element) => {
      const title = $(element).find('.title').text().trim();
      const image = $(element).find('img').attr('data-src') || $(element).find('img').attr('src');
      const link = $(element).find('a').attr('href');
      const synopsis = $(element).find('.synopsis').text().trim();
      const studio = $(element).find('.studio').text().trim() || 'Studio tidak tersedia';
      const rating = $(element).find('.score').text().trim() || 'Rating tidak tersedia';

      if (title && image && link) {
        latestAnime.push({ title, image, link, synopsis, studio, rating });
      }
    });
    if (latestAnime.length === 0) {
      return await conn.sendMessage(
        m.chat,
        { text: "❗ Tidak ada anime baru yang ditemukan." },
        { quoted: m }
      );
    }
    const randomAnimeIndex = Math.floor(Math.random() * latestAnime.length);
    const randomAnimeTitle = latestAnime[randomAnimeIndex].title;
    const randomAnime = latestAnime[randomAnimeIndex];
    
    let message = `✨ *Anime Baru Rilis: ${randomAnimeTitle}* ✨\n\n`;
    message += `🔗 *Link*: [Klik di sini](${randomAnime.link})\n`;
    message += `🖼️ *Gambar*: ${randomAnime.image}\n\n`;
    message += `📝 *Deskripsi*: ${randomAnime.synopsis}\n\n`;
    message += `🏢 *Studio*: ${randomAnime.studio}\n`;
    message += `⭐ *Rating*: ${randomAnime.rating}\n`;
    message += `\n🔍 *Selamat menonton! Enjoy!* 🎉`;
    await conn.sendMessage(m.chat, { text: message }, { quoted: m });
  } catch (error) {
    console.error('Emror Fetching:', error);
    await conn.sendMessage(
      m.chat,
      { text: "❗ Terjadi kesalahan saat mengambil informasi anime baru." },
      { quoted: m }
    );
  }
};
handler.command = /^(newanime)$/i;
handler.tags = ['internet'];
handler.help = ['newanime'];
export default handler;