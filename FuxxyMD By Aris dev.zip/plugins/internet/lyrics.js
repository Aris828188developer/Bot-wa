import kontol from "../../scrape/genius.cjs"

const code = async(m, { conn, text, usedPrefix, command }) => {
	if (!text) return m.reply(`\`Input Query\`\nEx: ${usedPrefix+command} Where we are`);
	try {
		let lyrics = await kontol.search(text);
		lyrics = lyrics[0].link
		lyrics = await kontol.lyric(lyrics);
		
		await conn.sendMessage(m.chat, { text: lyrics.songPage.lyricsData.body.html.replace(/<[^>]+>/g, '').replace(/&amp;/g, '&') }, { quoted: m })
	} catch (_) {
		throw "Lyrics not found or something wen't wrong\n" + _
	}
}

export default {
	code,
	limit: true,
	command: ["lyrics", "lirik", "lyric"],
	help: ["lirik"]
}