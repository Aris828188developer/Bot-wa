import axios from "axios";
import { mlStalk } from "../../lib/mlstalk.js";

let handler = async(m, { conn, text, command }) => {
	global.db.data.users[m.sender].akunml = global.db.data.users[m.sender].akunml || ""
	global.db.data.users[m.sender].idml = global.db.data.users[m.sender].idml || []
	global.db.data.users[m.sender].regionml = global.db.data.users[m.sender].regionml || ""
	switch (command) {
		case "addakun":  {
			conn.addakun = conn.addakun || {}
			await conn.sendMessage(m.chat, { text: "Silahkan ketik id kamu contoh:\n1234567890 (12345)" }, { quoted: m });
			conn.addakun[m.sender] = {
				step: 1
			}
		}
		break;
		/*case "cekakun": {
			if (!text) throw "Masukkan nama akun atau id akun\nContoh: .cekakun plertod";
			let input = parseInt(args[0]) || args[0]
			let input2 = parseInt(args[1].replace(/[()]/g, ""));
			if (typeof input == "number") {
				let Object.entries(global.db.data.users).find(([key, value]) => value.filter)
		break;*/
	}
}
handler.command = ["addakun"]
handler.before = async(m, { conn }) => {
	if (!conn.addakun) return;
	if (!(m.sender in conn.addakun)) return;
	
	let { step } = conn.addakun[m.sender]
	if (step == 1) {
		var id = m.text.match(/\d+/g);
		if (id.length !== 2) return m.reply(`Masukkan id dengan benar.\nContoh:\n1234567890 (12345)`);
		id = id.map(Number);
		let [userid, serverid] = id;
		let v = await conn.sendMessage(m.chat, { text: "`Loading...`", }, { quoted: m });
		var data = await mlStalk(userid, serverid);
		conn.addakun[m.sender].username = data.username;
		conn.addakun[m.sender].region = data.region;
		conn.addakun[m.sender].id = id
		conn.addakun[m.sender].wait = v.key
		if (!data.success) return m.reply(data.message);
		conn.addakun[m.sender].step += 1;
		await conn.sendMessage(m.chat, { text: `Silahkan Ketik Role Yang Kamu Kuasai (Bisa lebih dari 1 role)\nMidlaner/Jungler/Midlaner/Explaner/Roamer/Allrole`, edit: v.key }, { quoted: m });
	} else if (step == 2) {
		global.db.data.users[m.sender].roleml = m.text
		global.db.data.users[m.sender].akunml = conn.addakun[m.sender].username
	    let [userid, serverid] = conn.addakun[m.sender].id
	    global.db.data.users[m.sender].idml = userid
	    global.db.data.users[m.sender].idserver = serverid
    	global.db.data.users[m.sender].regionml = conn.addakun[m.sender].region
		await conn.sendMessage(m.chat, { text:`Berhasil Menambahkan Akunmu ✅\n\nUsername: ${conn.addakun[m.sender].username}\nUserId: ${userid + ` (${serverid})`}\nRegion: ${conn.addakun[m.sender].region}\nRole: ${m.text}`, edit: conn.addakun[m.sender].wait }, { quoted: m });
		delete conn.addakun[m.sender]
	}
}
export default handler;