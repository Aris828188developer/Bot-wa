/*
wa.me/6289687537657
github: https://github.com/Phmiuuu
Instagram: https://instagram.com/basrenggood
ini wm gw cok jan di hapus
*/

let handler = async (m, { conn, command, text }) => {
let hasil = `◦ *Pertanyaan:* ${command} ${text}
◦ *Jawaban:* ${['Ya', 'Mungkin Saja', 'Mungkin', 'Mungkin Tidak', 'Tidak', 'Tidak Mungkin'].getRandom()}`.trim()
let who = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.fromMe ? conn.user.jid : m.sender
await conn.reply(m.chat, hasil, m)
}
handler.help = ['apakah']
handler.tags = ['fun']
handler.command = /^apakah$/i

export default handler