const WSF = require('wa-sticker-formatter');
const axios = require('axios');

let handler = async (m, { conn, args }) => {
    await m.react('⌛'); // Menandakan proses sedang berlangsung

    let text;
    if (args.length >= 1) {
        text = args.join(" ");
    } else if (m.quoted && m.quoted.text) {
        text = m.quoted.text;
    } else {
        await m.react('❌'); // Jika gagal, beri tanda silang
        return m.reply("Input teks atau reply teks yang ingin dijadikan quote!");
    }
    
    let who = m.quoted ? m.quoted.sender : m.sender;
    let name = m.quoted ? m.quoted.name : m.name;

    if (text.length > 100) {
        await m.react('❌');
        return m.reply("Maksimal 100 teks!");
    }

    let pp = await conn.profilePictureUrl(who, 'image').catch(_ => 'https://telegra.ph/file/320b066dc81928b782c7b.png');

    const createImageBuffer = async (backgroundColor) => {
        const obj = {
            "type": "quote",
            "format": "png",
            "backgroundColor": backgroundColor,
            "width": 512,
            "height": 768,
            "scale": 2,
            "messages": [{
                "entities": [],
                "avatar": true,
                "from": {
                    "id": 1,
                    "name": name,
                    "photo": {
                        "url": pp
                    }
                },
                "text": text,
                "replyMessage": {}
            }]
        };

        const response = await axios.post('https://qc.botcahx.eu.org/generate', obj, {
            headers: {
                'Content-Type': 'application/json'
            }
        });

        return Buffer.from(response.data.result.image, 'base64');
    };

    try {
        const whiteBuffer = await createImageBuffer("#ffffff");
        const blackBuffer = await createImageBuffer("#000000");

        let whiteSticker = await sticker5(whiteBuffer, false, global.packname, global.author);
        let blackSticker = await sticker5(blackBuffer, false, global.packname, global.author);

        if (whiteSticker) await conn.sendFile(m.chat, whiteSticker, 'QuoteWhite.webp', '', m);
        if (blackSticker) await conn.sendFile(m.chat, blackSticker, 'QuoteBlack.webp', '', m);

        await m.react('✅'); // Jika berhasil, beri tanda centang hijau
    } catch (error) {
        console.error(error);
        await m.react('❌');
        m.reply('Terjadi kesalahan saat memproses permintaan.');
    }
};

handler.help = ['qc'];
handler.tags = ['sticker'];
handler.command = /^(qc|quotely)$/i;
handler.register = true;
handler.limit = true;

module.exports = handler;

async function sticker5(img, url, packname, author, categories = ['']) {
    const stickerMetadata = {
        type: 'full',
        pack: packname,
        author,
        categories,
    };
    return await new WSF.Sticker(img ? img : url, stickerMetadata).build();
}