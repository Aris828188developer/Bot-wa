import pkg from "akiraa-wb"
let Ezgif = pkg.Ezgif
let handler = async (m, { conn, usedPrefix, command }) => {
  if (!m.quoted)
    return m.reply(`*• Example :* ${usedPrefix + command} *[reply sticker]*`);
  let mime = m.quoted.mimetype || "";
  if (!/webp/.test(mime))
    return m.reply(`*• Example :* ${usedPrefix + command} *[reply sticker]*`)
   m.reply(wait);
  try {
    let media = await m.quoted.download();
    let out = Buffer.alloc(0);
    if (/webp/.test(mime)) {
      out = await Ezgif.webp2mp4(media);
    }
    conn.sendMessage(
      m.chat,
      {
        video: {
          url: out,
        },
      },
      {
        quoted: m,
      },
    );
  } catch (e) {
    throw e
  }
};
handler.help = ["tovideo", "tovid"].map((a) => a + " *[reply sticker]*");
handler.tags = ["tools"];
handler.command = ["tovideo", "tovid"];

export default handler