/**
@credit Tio
@Tixo MD
@Whatsapp Bot
wa.me/6282285357346
**/

import func from "akiraa-wb";
import axios from 'axios';
import fetch from 'node-fetch';
const { Ezgif, Uploader } = func;

let Tio = async (m, { conn, text }) => {
  let q = m.quoted ? m.quoted : m;
  let mime = (q.msg || q).mimetype || '';
  const { mtype } = m;

  if (!text) return m.reply('Teksnya mana, Sayang?');
  if (text.length > 500) return m.reply('Maksimal 500 karakter untuk teks!');

  let args = text.split('--');
  let quoteText = args[0].trim();
  let bgColor = args[1] ? args[1].trim().toLowerCase() : '#ffffff';

  // Validasi warna
  const colors = {
    "merah": "#FF0000",
    "hijau": "#008000",
    "biru": "#0000FF",
    "kuning": "#FFFF00",
    "putih": "#FFFFFF",
    "hitam": "#000000",
    "orange": "#FFA500",
    "pink": "#FFC0CB",
    "biru_muda": "#ADD8E6",
    "ungu": "#800080",
    "coklat": "#964B00",
    "abu_abu": "#808080",
    "coklat_muda": "#F5DEB3",
    "default": "#ffffff"
  };
  const scale = 3;
  bgColor = colors[bgColor] || colors['default'];

  let pp = await conn.profilePictureUrl(m.sender, 'image').catch(_ => "https://telegra.ph/file/320b066dc81928b782c7b.png");

  if (q.mtype === 'extendedTextMessage' || q.mtype === 'stickerMessage' || q.mtype === 'imageMessage') {
    conn.sendMessage(m.chat, {
      react: {
        text: "🕛",
        key: m.key,
      },
    });

    let img;
    if (q.mtype === 'stickerMessage' || q.mtype === 'imageMessage') {
      img = await q.download();
    }

    let up;
    if (img && /webp/g.test(mime)) {
      up = await Ezgif.webp2png(img);
    } else if (img && /image/g.test(mime)) {
      up = await Uploader.tmpfiles(img);
    }

    let obj = {
      "type": "image",
      "format": "png",
      "backgroundColor": bgColor,
      "width": 512,
      "height": 768,
      scale,
      "messages": [{
        "entities": [],
        "media": up ? { "url": up } : undefined,
        "avatar": true,
        "from": {
          "id": 2,
          "name": m.name,
          "photo": { "url": pp }
        },
        "text": quoteText,
        "replyMessage": {
          "name": m.quoted ? await conn.getName(m.quoted.sender) : undefined,
          "text": m.quoted?.text || '',
          "chatId": m.chat.split('@')[0],
        }
      }]
    };

    const buffer = await Quotly(obj);

    const sticker = await conn.sendFile(m.chat, buffer, 'Quotly.webp', '', m);
    if (sticker) return;
    conn.sendMessage(m.chat, {
      react: {
        text: "✅",
        key: m.key,
      },
    });
  }
};

Tio.help = ['qc'];
Tio.tags = ['sticker'];
Tio.command = /^(qc|quoted|quotly)$/i;
Tio.limit = true;
Tio.register = true;

export default Tio;

async function Quotly(obj) {
  try {
    const json = await axios.post(
      "https://qc.botcahx.eu.org/generate",
      obj,
      {
        headers: {
          "Content-Type": "application/json",
        },
      },
    );
    const results = json.data.result.image;
    return Buffer.from(results, "base64");
  } catch (e) {
    console.error("Error generating quotly:", e);
    throw e;
  }
}