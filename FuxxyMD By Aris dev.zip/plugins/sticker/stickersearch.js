/*
   * COZY MD
   * Credit Nzx | wa.me/6282223537406
   * Dilarang share/menjual sc ini tanpa seizin saya
*/

import axios from "axios";
import * as cheerio from "cheerio";


const handler = async (m, { conn, text, usedPrefix, command }) => {
    
    if (!text) {
        return m.reply(`Contoh: ${usedPrefix + command} kucing atau ${usedPrefix + command} https://getstickerpack.com/stickers/`);
    }

    
    const input = text.split(' ');
    const lastInput = input[input.length - 1];
    const isURL = lastInput.startsWith('http'); 
    const queryOrURL = isURL ? lastInput : input.join(' '); 

    m.reply("Sedang mencari sticker...");

    try {
        
        const stickerData = isURL ? await getStickerFromURL(queryOrURL) : await stickersearch(queryOrURL);
        const stickers = stickerData.sticker; 

        if (stickers.length > 0) {
            
            await new Promise(resolve => setTimeout(resolve, 3000));

            for (let i = 0; i < stickers.length; i++) {
                try {
                    await conn.sendImageAsSticker(m.chat, stickers[i], m, {
                        packname: packname,
                        author: stickauth 
                    });
                } catch (error) {
                    console.error(`Error mengirim file: ${error.message}`);
                    await m.reply(`Gagal mengirim sticker *(${i + 1}/${stickers.length})*`);
                }
            }
        } else {
            m.reply("Tidak ada sticker yang ditemukan dalam pack yang dipilih.");
        }
    } catch (error) {
        console.error(error);
        m.reply(`Error: ${error.message}`);
    }
};


async function stickersearch(query) {
    return new Promise((resolve, reject) => {
        
        axios.get(`https://getstickerpack.com/stickers?query=${query}`)
            .then(({ data }) => {
                const $ = cheerio.load(data);
                const link = [];

                
                $('#stickerPacks > div > div:nth-child(3) > div > a').each(function (a, b) {
                    link.push($(b).attr('href'));
                });

                if (link.length === 0) {
                    return reject(new Error('Sticker pack tidak ditemukan untuk query yang diberikan.'));
                }

                
                let rand = link[Math.floor(Math.random() * link.length)];

                
                axios.get(rand)
                    .then(({ data }) => {
                        const $$ = cheerio.load(data);
                        const url = [];

                        
                        $$('#stickerPack > div > div.row > div > img').each(function (a, b) {
                            url.push($$(b).attr('src').split('&d=')[0]);
                        });

                        if (url.length === 0) {
                            return reject(new Error('Tidak ada sticker yang ditemukan dalam pack yang dipilih.'));
                        }

                        
                        resolve({
                            title: $$('#intro > div > div > h1').text(),
                            author: $$('#intro > div > div > h5 > a').text(),
                            author_link: $$('#intro > div > div > h5 > a').attr('href'),
                            sticker: url
                        });
                    })
                    .catch(err => reject(err));
            })
            .catch(err => reject(err));
    });
}


async function getStickerFromURL(url) {
    return new Promise((resolve, reject) => {
        
        axios.get(url)
            .then(({ data }) => {
                const $$ = cheerio.load(data);
                const stickers = [];

                
                $$('#stickerPack > div > div.row > div > img').each(function (a, b) {
                    stickers.push($$(b).attr('src').split('&d=')[0]);
                });

                if (stickers.length === 0) {
                    return reject(new Error('Tidak ada sticker yang ditemukan di URL yang diberikan.'));
                }

                
                resolve({
                    title: $$('#intro > div > div > h1').text(),
                    author: $$('#intro > div > div > h5 > a').text(),
                    author_link: $$('#intro > div > div > h5 > a').attr('href'),
                    sticker: stickers
                });
            })
            .catch(err => reject(err));
    });
} 


handler.help = ["stickersearch *[text]*"];
handler.tags = ["sticker"];
handler.command = /^stickersearch|stickers$/i;


export default handler