const axios = require("axios");
const { sticker } = require("../../lib/sticker");

const handler = async (m, { conn, text }) => {
  if (!text) return m.reply("Masukkan teks!");

  const apiUrl = `https://aqul-brat.hf.space/api/brat?text=${encodeURIComponent(text)}`;

  try {
    // Tampilkan emoji react 🕒 saat proses berlangsung
    await conn.sendMessage(m.chat, {
      react: {
        text: "🕒",
        key: m.key,
      },
    });

    // Ambil gambar dari API
    const response = await axios.get(apiUrl, { responseType: "arraybuffer" });
    const imgBuffer = Buffer.from(response.data);

    // Convert ke stiker
    const stiker = await sticker(imgBuffer, false, global.stickauth, global.wm);

    // Kirim hasil dalam bentuk stiker
    await conn.sendFile(m.chat, stiker, "brat.webp", "", m);

  } catch (error) {
    console.error(error);
    m.reply("Gagal membuat stiker! Coba lagi nanti.");
  }
};

handler.help = ["brat"];
handler.tags = ["sticker"];
handler.command = /^brat$/i;

module.exports = handler;