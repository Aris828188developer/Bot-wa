import axios from 'axios'
import { Sticker } from 'wa-sticker-formatter'
 
async function telestick(url) {
  let match = url.match(/https:\/\/t\.me\/addstickers\/([^\/\?#]+)/)
  if (!match) throw 'Invalid url'
  let { data: a } = await axios.get(`https://api.telegram.org/bot7935827856:AAGdbLXArulCigWyi6gqR07gi--ZPm7ewhc/getStickerSet?name=${match[1]}`)
  let stickers = await Promise.all(a.result.stickers.map(async v => {
    let { data: b } = await axios.get(`https://api.telegram.org/bot7935827856:AAGdbLXArulCigWyi6gqR07gi--ZPm7ewhc/getFile?file_id=${v.file_id}`)
    return {
      emoji: v.emoji,
      is_animated: v.is_animated,
      image_url: `https://api.telegram.org/file/bot7935827856:AAGdbLXArulCigWyi6gqR07gi--ZPm7ewhc/${b.result.file_path}`
    }
  }))
  return { name: a.result.name, title: a.result.title, sticker_type: a.result.sticker_type, stickers }
}
 
let handler = async (m, { conn, args }) => {
  try {
    if (!args[0]) return m.reply('Masukkan url sticker telegram')
    let res = await telestick(args[0])
    for (let v of res.stickers) {
      let { data } = await axios.get(v.image_url, { responseType: 'arraybuffer' })
      let sticker = new Sticker(data, { pack: res.title, author: 'Telegram', type: v.is_animated ? 'full' : 'default' })
      await conn.sendMessage(m.chat, await sticker.toMessage(), { quoted: m })
    }
  } catch (e) {
    m.reply(e.message)
  }
}
 
handler.help = ['telestick']
handler.command = ['telestick']
handler.tags = ['tools']
 
export default handler