import { sticker } from '../../lib/sticker.js'
import uploadFile from '../../lib/uploadFile.js'

let handler = async (m, { conn, args, usedPrefix, command }) => {
  try {
    await conn.sendMessage(m.chat, {
      react: {
        text: '🕒',
        key: m.key,
      },
    })

    let text = args.join(' ') || 'Teksnya mana woy? 🗿'
    let apiUrl = `https://skyzxu-brat.hf.space/brat-animated?text=${encodeURIComponent(text)}`

    let res = await fetch(apiUrl)
    if (!res.ok) throw new Error('Gagal mengambil video dari API!')
    let buffer = await res.arrayBuffer()

    // Konversi ArrayBuffer ke Buffer Node.js
    let nodeBuffer = Buffer.from(buffer)

    let videoUrl = await uploadFile(nodeBuffer)
    if (!videoUrl) throw new Error('Gagal mengunggah video!')

    let stiker = await sticker(false, videoUrl, packname, stickauth)
    if (stiker) {
      await conn.sendFile(m.chat, stiker, 'sticker.webp', '', m, false, { asSticker: true })
    } else {
      throw new Error('Gagal membuat stiker!')
    }
  } catch (e) {
    m.reply('Gagal mengambil stiker.')
    console.error(e)
  }
}

handler.help = ['bratvid *<text>*']
handler.tags = ['sticker']
handler.command = /^bratvid$/i
handler.limit = 1

export default handler