const fs = require('fs'); // Modul untuk membaca file
const { promises: fsPromises } = fs;
const path = require('path'); // Modul untuk mengatur path file
const { join, dirname } = require('path');

let handler = async (m, { conn }) => {
  // Menentukan path file package.json
  const packageJsonPath = path.join(__dirname, '../../package.json');
  
  let packageJsonObj;
  
  // Membaca file package.json
  try {
    const packageJsonData = await fsPromises.readFile(packageJsonPath, 'utf-8');
    packageJsonObj = JSON.parse(packageJsonData);
  } catch (err) {
    console.error('Gagal membaca package.json:', err.message);
    packageJsonObj = { name: 'Unknown', version: 'Unknown', description: 'Unknown' };
  }

  // Fungsi untuk menghitung total folder dan file
async function getTotalFoldersAndFiles(folderPath) {
  try {
    const files = await fsPromises.readdir(folderPath);
    let folders = 0;
    let filesCount = 0;

    for (const file of files) {
      const filePath = join(folderPath, file);
      const stat = await fsPromises.stat(filePath);
      if (stat.isDirectory()) {
        folders++;
      } else {
        filesCount++;
      }
    }

    return { folders, files: filesCount };
  } catch (err) {
    console.error('Gagal membaca folder', err.message);
    return { folders: 0, files: 0 };
  }
}
  // Menyiapkan pesan yang akan dikirim 
  const versionMessage =  `*I N F O R M A T I O N*\n\n` +
                          `┌  ◦ *ɴᴀᴍᴇ*: ${packageJsonObj.name}\n` +
                          `│  ◦ *ᴠᴇʀѕɪᴏɴ*: ${packageJsonObj.version}\n` +
                          `│  ◦ *ᴛᴏᴛᴀʟ ᴘʟᴜɢɪɴѕ*: ${Object.keys(global.plugins).length} Plugins\n` +
                          `└  ◦ *ᴅᴇѕᴄʀɪᴘᴛɪᴏɴ*: ${packageJsonObj.description}`;

  // Mengirim pesan menggunakan contextInfo dan externalAdReply
  conn.sendMessage(m.chat, {
    text: versionMessage,
    contextInfo: {
      externalAdReply: {
        title: `ʙ ᴏ ᴛ ѕ ᴄ ʀ ɪ ᴘ ᴛ - ɪ ɴ ꜰ ᴏ ʀ ᴍ ᴀ ᴛ ɪ ᴏ ɴ`, // Judul
        body: global.wm, // Body, bisa disesuaikan
        thumbnailUrl: global.gfx, // Gambar thumbnail
        sourceUrl: global.sgc,
        renderLargerThumbnail: true,
        mediaType: 1, // Jenis media (1 untuk gambar)
      }
    }
  }, { quoted: m });
}

handler.help = ['version'];
handler.tags = ['info'];
handler.command = /^(version|ver)$/i;

module.exports = handler;
