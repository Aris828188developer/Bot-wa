let cp = require ('child_process')
let { promisify } = require ('util')
let exec = promisify(cp.exec).bind(cp)
let handler = async (m, { conn}) => {
	await m.reply("Wait..");
    let o
    try {
        o = await exec('python3 speed.py --share --secure')
    } catch (e) {
        o = e
    } finally {
        let { stdout, stderr } = o
        let img = stdout.split('\n').find(line => line.startsWith('Share results:'))
        let image = img.split(': ')[1]
        if (stdout.trim()) 
conn.sendMessage(m.chat, {
text: stdout,
contextInfo: {
externalAdReply: {
title: namebot,
body: wm,
thumbnailUrl: image,
sourceUrl: "https://www.speedtest.net",
mediaType: 1,
renderLargerThumbnail: true
}}})
//await conn.sendMessage(m.chat, { react: { text: 'âœ…', key: m.key }})
        if (stderr.trim()) 
           m.reply(stderr)
    }
}
handler.help = ['speedtest']
handler.tags = ['info']
handler.command = /^(speedtest|ookla)$/i
handler.premium = false
module.exports = handler