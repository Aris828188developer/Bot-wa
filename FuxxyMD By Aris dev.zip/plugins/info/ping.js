import speed from "performance-now"

var handler = async (m, { 
conn 
}) => {
         let timestamp = speed();
         let latensi = speed() - timestamp;
           conn.sendMessage(m.chat, { text:`${latensi.toFixed(4)} ms` }, {quoted: m});
}
handler.command = handler.help = ['ping'];
handler.tags = ['main'];
export default handler