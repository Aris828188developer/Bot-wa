let fetch = require("node-fetch");
let canvafy = require ('canvafy')
let levelling = require('../lib/levelling')

let handler = async (m, { conn, command }) => {
  try {
    let who;
    if (m.isGroup) who = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted.sender;
    else who = m.quoted.sender ? m.quoted.sender : m.sender;

    let ppUrl = await conn.profilePictureUrl(who, 'image').catch((_) => "https://telegra.ph/file/1dff1788814dd281170f8.jpg");
    let pp = await (await fetch(ppUrl)).buffer();

    let user = global.db.data.users[who];
    let targetNumber = m.sender;
    let username = user.name;
    let { min, xp, max } = levelling.xpRange(user.level, global.multiplier)
    let curr = user.exp - min
    let limit = user.premium ? '∞' : user.limit; // Mengubah limit user premium menjadi 'Infinity' jika pengguna adalah premium
    let balance = user.money > 9999999999 ? '4̶0̶4̶ N̶o̶t̶ F̶o̶u̶n̶d̶' : user.money;
    let saldo = user.saldo; // Mengubah balance user yang lebih dari 999999999 menjadi 'Infinity'
    let level = user.level > 9999 ? '4̶0̶4̶ N̶o̶t̶ F̶o̶u̶n̶d̶' : user.level; // Mengubah level pengguna yang lebih dari 9999 menjadi 'Infinity'
    let role = user.role;
    let agama = user.agama;
    let gender = user.gender;
    let money = user.money;
    let bank = user.bank;
    let channel = user.youtube_account;
    let subs = user.subscribers;
    let viewer = user.viewers;
    let like = user.like;
    let warn = user.warn;
    let job = user.job;
    let city = user.city;
    let registered = user.registered ? true : false;
    let skill = user.skill;
    let rank = user.owner ? 'Immortality' : user.premium ? 'Sepuh' : 'Kroco'; // Menambahkan 'Not Found' jika rank tidak terdefinisi
    let point = user.point
    let age = user.age > 4000 ? 'Unknown' : user.age;
    let isPremium = user.premium ? "√" : "×";
    let isVip = user.vip ? "√" : "×";
    let premiumExpired = user.premium ? new Date(user.premiumDate).toDateString() : "Not Found";
    let vipExpired = user.vip ? new Date(user.vipDate).toDateString() : "Not Found";
    let pasangan = user.pasangan ? global.db.data.users[user.pasangan].name : 'Not Have'; // Mengambil nama pasangan dari database
    let banned = user.banned ? true : false;
    let block = user.block ? true : false;
    let sahabat = user.sahabat ? '' + global.db.data.users[user.sahabat].name : 'Not Have';
    // Tiktok account
    let akuntt = user.tiktok_account;
    let fanstt = user.fans;
    let likestt = user.likestt;
    let viewstt = user.viewerstt;
    const formattedFanstt = formatNumber(user.fans || 0);
    const formattedViewstt = formatNumber(user.viewerstt || 0);
    const formattedLikestt = formatNumber(user.likestt || 0);

    const targetUser = global.db.data.users[targetNumber];
    const formattedSubscribers = formatNumber(targetUser.subscribers || 0);
    const formattedViewers = formatNumber(targetUser.viewers || 0);
    const formattedLike = formatNumber(targetUser.like || 0);
    
    
    let caption = '*I N F O - U S E R*\n\n'
    caption += '┌─── ᴜѕᴇʀ ɪɴꜰᴏ\n'
    caption += '│ • *Nama :*' + ` ${username}\n`
    caption += '│ • *Limit :*' + ` ${limit}\n` 
    caption += '│ • *Gender :*' + ` ${gender}\n`
    caption += '│ • *Kota :*' + ` ${city}\n`
    caption += '│ • *Religion :*' + ` ${agama}\n`
    caption += '│ • *Age :*' + ` ${age}\n`
    caption += '│ • *Lovers :*' + ` ${pasangan.split`@`[0]}\n`
    caption += '│ • *Friends :*' + ` ${sahabat}\n`
    caption += '│ • *Pekerjaan :* ' + ` ${job}\n`
    caption += '└───────────\n'
    caption += '┌─── ʀᴘɢ ɪɴꜰᴏ\n'
    caption += '│ • *Role :*' + ` ${role}\n`
    caption += '│ • *Skill :*' + ` ${skill}\n`
    caption += '│ • *Rank :*' + ` ${rank}\n`
    caption += '│ • *Level :*' + ` ${level}\n`
    caption += '│ • *Money :*' + ` ${money}\n`
    caption += '│ • *Bank :*' + ` ${bank}\n`
    caption += '│ • *Saldo :*' + ` ${formatRupiah(saldo)}\n`
    caption += '│ • *Point :*' + ` ${toRupiah(point)}\n` 
    caption += '└───────────\n'
    caption += '┌─── ᴜѕᴇʀ ѕᴛᴀᴛᴜѕ\n'
    caption += '│ • *Banned :*' + ` ${banned ? '√' : '×'}\n`
    caption += '│ • *Blocked :*' + ` ${block ? '√' : '×'}\n`
    caption += '│ • *Verified :*' + ` ${registered ? '√' : '×'}\n`
    caption += '│ • *Warn :*' + ` ${warn} / 5\n`
    caption += '│ • *Premium :*' + ` ${isPremium}\n`
    caption += '│ • *Expired :*' + ` ${premiumExpired}\n`
    caption += '└───────────\n'
    caption += '┌─── ʏᴏᴜᴛᴜʙᴇ ѕᴛᴀᴛѕ\n'
    caption += '│ • *Channel :*' + ` ${channel}\n`
    caption += '│ • *Subscribers :*' + ` ${formattedSubscribers}\n`
    caption += '│ • *Viewers :*' + ` ${formattedViewers}\n`
    caption += '│ • *Likes :*' + ` ${formattedLike}\n`
    caption += '└───────────\n'
    caption += '┌─── ᴛɪᴋᴛᴏᴋ ѕᴛᴀᴛѕ\n'
    caption += '│ • *Akun :*' + ` ${akuntt}\n`
    caption += '│ • *Fans :*' + ` ${formattedFanstt}\n`
    caption += '│ • *Viewers :*' + ` ${formattedViewstt}\n`
    caption += '│ • *Likes :*' + ` ${formattedLikestt}\n`
    caption += '└───────────\n'
    conn.sendMessage(m.chat, {
    text: caption, 
    contextInfo: {
    mentionedJid: [m.sender],
    externalAdReply: {
    title: 'P R O F I L E',
    thumbnailUrl: ppUrl,
    mediaType: 1,
    renderLargerThumbnail: true
    }}}, {quoted: m})
  } catch {
    let sender = m.sender;;
    let ppUrl = await conn.profilePictureUrl(sender, 'image').catch((_) => "https://telegra.ph/file/1dff1788814dd281170f8.jpg");
    let pp = await (await fetch(ppUrl)).buffer();

    let user = global.db.data.users[sender];
    let targetNumber = m.sender;
    let username = user.name;
    let { min, xp, max } = levelling.xpRange(user.level, global.multiplier)
    let curr = user.exp - min
    let limit = user.premium ? '∞' : user.limit; // Mengubah limit user premium menjadi 'Infinity' jika pengguna adalah premium
    let balance = user.money > 9999999999 ? '4̶0̶4̶ N̶o̶t̶ F̶o̶u̶n̶d̶' : user.money; // Mengubah balance user yang lebih dari 999999999 menjadi 'Infinity'
    let saldo = user.saldo; 
    let level = user.level > 9999 ? '4̶0̶4̶ N̶o̶t̶ F̶o̶u̶n̶d̶' : user.level; // Mengubah level pengguna yang lebih dari 9999 menjadi 'Infinity'
    let role = user.role;
    let agama = user.agama;
    let gender = user.gender;
    let job = user.job;
    let city = user.city;
    let money = user.money;
    let channel = user.youtube_account;
    let subs = user.subscribers;
    let viewer = user.viewers;
    let like = user.like;
    let stamina = user.stamina;
    let bank = user.bank;
    let skill = user.skill;
    let warn = user.warn;
    let registered = user.registered ? true : false;
    let rank = user.owner ? 'Immortality' : user.premium ? 'Sepuh' : 'Kroco'; // Menambahkan 'Not Found' jika rank tidak terdefinisi
    let point = user.point
    let age = user.age > 4000 ? '-' : user.age;
    let isPremium = user.premium ? "√" : "×";
    let isVip = user.vip ? "√" : "×";
    let premiumExpired = user.premium ? new Date(user.premiumDate).toDateString() : "Not Found";
    let vipExpired = user.vip ? new Date(user.vipDate).toDateString() : "-";
    let pasangan = user.pasangan ? global.db.data.users[user.pasangan].name : 'Not Have'; // Mengambil nama pasangan dari database
    let banned = user.banned ? true : false;
    let block = user.block ? true : false;
    let sahabat = user.sahabat ? '' + global.db.data.users[user.sahabat].name : 'Not Have';
    // Tiktok account
    let akuntt = user.tiktok_account;
    let fanstt = user.fans;
    let likestt = user.likestt;
    let viewstt = user.viewerstt;
    const formattedFanstt = formatNumber(user.fans || 0);
    const formattedViewstt = formatNumber(user.viewerstt || 0);
    const formattedLikestt = formatNumber(user.likestt || 0);

    const targetUser = global.db.data.users[targetNumber];
    const formattedSubscribers = formatNumber(targetUser.subscribers || 0);
    const formattedViewers = formatNumber(targetUser.viewers || 0);
    const formattedLike = formatNumber(targetUser.like || 0);

    let caption = '*I N F O - U S E R*\n\n'
    caption += '┌─── ᴜѕᴇʀ ɪɴꜰᴏ\n'
    caption += '│ • *Nama :*' + ` ${username}\n`
    caption += '│ • *Limit :*' + ` ${limit}\n` 
    caption += '│ • *Gender :*' + ` ${gender}\n`
    caption += '│ • *Kota :*' + ` ${city}\n`
    caption += '│ • *Religion :*' + ` ${agama}\n`
    caption += '│ • *Age :*' + ` ${age}\n`
    caption += '│ • *Lovers :*' + ` ${pasangan.split`@`[0]}\n`
    caption += '│ • *Friends :*' + ` ${sahabat}\n`
    caption += '│ • *Pekerjaan :* ' + ` ${job}\n`
    caption += '└───────────\n'
    caption += '┌─── ʀᴘɢ ɪɴꜰᴏ\n'
    caption += '│ • *Role :*' + ` ${role}\n`
    caption += '│ • *Skill :*' + ` ${skill}\n`
    caption += '│ • *Rank :*' + ` ${rank}\n`
    caption += '│ • *Level :*' + ` ${level}\n`
    caption += '│ • *Money :*' + ` ${money}\n`
    caption += '│ • *Bank :*' + ` ${bank}\n`
    caption += '│ • *Saldo :*' + ` ${formatRupiah(saldo)}\n`
    caption += '│ • *Point :*' + ` ${toRupiah(point)}\n` 
    caption += '└───────────\n'
    caption += '┌─── ᴜѕᴇʀ ѕᴛᴀᴛᴜѕ\n'
    caption += '│ • *Banned :*' + ` ${banned ? '√' : '×'}\n`
    caption += '│ • *Blocked :*' + ` ${block ? '√' : '×'}\n`
    caption += '│ • *Verified :*' + ` ${registered ? '√' : '×'}\n`
    caption += '│ • *Warn :*' + ` ${warn} / 5\n`
    caption += '│ • *Premium :*' + ` ${isPremium}\n`
    caption += '│ • *Expired :*' + ` ${premiumExpired}\n`
    caption += '└───────────\n'
    caption += '┌─── ʏᴏᴜᴛᴜʙᴇ ѕᴛᴀᴛѕ\n'
    caption += '│ • *Channel :*' + ` ${channel}\n`
    caption += '│ • *Subscribers :*' + ` ${formattedSubscribers}\n`
    caption += '│ • *Viewers :*' + ` ${formattedViewers}\n`
    caption += '│ • *Likes :*' + ` ${formattedLike}\n`
    caption += '└───────────\n'
    caption += '┌─── ᴛɪᴋᴛᴏᴋ ѕᴛᴀᴛѕ\n'
    caption += '│ • *Akun :*' + ` ${akuntt}\n`
    caption += '│ • *Fans :*' + ` ${formattedFanstt}\n`
    caption += '│ • *Viewers :*' + ` ${formattedViewstt}\n`
    caption += '│ • *Likes :*' + ` ${formattedLikestt}\n`
    caption += '└───────────\n'
    conn.sendMessage(m.chat, {
    text: caption, 
    contextInfo: {
    mentionedJid: [m.sender],
    externalAdReply: {
    title: 'P R O F I L E',
    thumbnailUrl: ppUrl,
    mediaType: 1,
    renderLargerThumbnail: true
    }}}, {quoted: m})
}
};

handler.command = /^(profile|me2)$/i
handler.help = ['profile *@user*'];
handler.tags = ['start'];
handler.register = true;

module.exports = handler;

function formatNumber(number) {
  if (number >= 1000000) {
      return (number / 1000000).toFixed(1) + 'Jt';
  } else if (number >= 1000) {
      return (number / 1000).toFixed(1) + 'K';
  } else {
      return number;
  }
}

function toRupiah(angka) {
var saldo = '';
var angkarev = angka.toString().split('').reverse().join('');
for (var i = 0; i < angkarev.length; i++)
if (i % 3 == 0) saldo += angkarev.substr(i, 3) + '.';
return '' + saldo.split('', saldo.length - 1).reverse().join('');
}

function formatRupiah(number) {
  const formatter = new Intl.NumberFormat('id-ID', {
    style: 'currency',
    currency: 'IDR',
    minimumFractionDigits: 0,
  });

  return formatter.format(number);
}