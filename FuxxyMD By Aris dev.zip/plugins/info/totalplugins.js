/*
   * COZY MD
   * Credit Nzx | wa.me/6282223537406
   * Dilarang share/menjual sc ini tanpa seizin saya
*/

let code = async(m, { conn }) => {
	let text = `*[ T O T A L   F E A T U R E S ]*\n\n`
	text += `_Esm_ : ${Object.keys(global.plugins).filter(v => v.endsWith(".js")).length}\n`
	text += `_Cjs_ : ${Object.keys(global.plugins).filter(v => v.endsWith(".cjs")).length}\n---------======----------\n`
	let plugin = ""
	const data = Object.keys(global.plugins).reduce((acc, path) => {
		const category = path.split("/")[0]
		acc[category] = (acc[category] || 0) + 1
		return acc
	}, {});
	
	for (const [category, total] of Object.entries(data)) {
		text += `${category.charAt(0).toUpperCase() + category.slice(1)}: ${total}\n`
	}
	text += `\n*Total: ${Object.keys(global.plugins).length}*`
	m.reply(text)
}
export default {
	code,
	tags: ["info"],
	help: ["totalfitur"],
	command: ["totalfitur", "ttf", "totalplugins"]
}