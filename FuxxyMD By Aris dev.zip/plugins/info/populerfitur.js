//© Nahida - BOT 2023-2024
// • Credits : wa.me/6289687537657 [ Fanzz ]
// • Owner: 6289687537657,62882021236704,628817057468

/*
• untuk siapa pun yang ketahuan menjual script ini tanpa sepengetahuan developer mohon untuk dilaporkan !
*/

let handler = async (m, {
    conn
}) => {
    let populer = await populerPlugins().map((v, i) => {
        return `${i + 1}. ${v.Nama}\n* Digunakan: ${v.Hit}x\n* Terakhir Digunakan: ${v.Terakhir}`;
    }).join("\n")
    m.reply(populer)
}
handler.command = ['populerfitur']
export default handler

function parseMs(ms) {
    if (typeof ms !== 'number') throw 'Parameter harus berisi angka!'
    return {
        days: Math.floor(ms / 86400000),
        hours: Math.floor((ms % 86400000) / 3600000),
        minutes: Math.floor((ms % 3600000) / 60000),
        seconds: Math.floor((ms % 60000) / 1000),
        milliseconds: Math.floor(ms % 1000),
        microseconds: Math.floor(ms * 1000) % 1000,
        nanoseconds: Math.floor(ms * 1e6) % 1000
    }
}

function getTime(ms) {
    let now = parseMs(+new Date() - ms)
    if (now.days) return `${now.days} hari yang lalu`
    else if (now.hours) return `${now.hours} jam yang lalu`
    else if (now.minutes) return `${now.minutes} menit yang lalu`
    else return `beberapa detik yang lalu`
}

function populerPlugins() {
    let stats = Object.entries(db.data.stats).map(([key, val]) => {
        let name = Array.isArray(plugins[key]?.help) ? plugins[key]?.help?.join(' & ') : plugins[key]?.help || key
        if (/(=>|~>|sf|sfp|save|saveplugins|exec)/i.test(name)) return
        return {
            name,
            ...val
        }
    })
    stats = stats.sort((a, b) => b.total - a.total)
    let txt = stats.slice(0, 5).map(({
        name,
        total,
        last
    }, idx) => {
        if (name.includes('-') && name.endsWith('.js')) name = name.split('-')[1].replace('.js', '')
        return {
            Nama: name,
            Hit: total,
            Terakhir: getTime(last)
        }
    })
    return txt
}