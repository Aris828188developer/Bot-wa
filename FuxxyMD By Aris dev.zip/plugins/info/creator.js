export default {
	code: async(m, { conn }) => {
		let isOwn
		let vcard = `BEGIN:VCARD\nVERSION:3.0\nN:WhatsApp; ${nameown}\nORG:${nameown}\nTITLE:soft\nitem1.TEL;waid=${nomorown}:${nomorown}\nitem1.X-ABLabel:Ponsel\nitem2.URL:http://github.com/VynzzDev\nitem2.X-ABLabel:ðŸ’¬ More\nitem4.ADR:;;Indonesia;;;;\nitem4.X-ABADR:ðŸ’¬ More\nitem4.X-ABLabel:Lokasi\nEND:VCARD`
		if (m.isGroup) {
			await conn.groupMetadata(m.chat).then(({ participants }) => {
				for (let i of participants) {
					if (i.id == nomorown + "@s.whatsapp.net") {
						isOwn = true;
						break;
					}
				}
			})
			if (isOwn) {
				await m.reply(`Haloo kak @${m.sender.split("@")[0]} 👋. Ownerku ada disini 😊\n@${nomorown}`)
			} else {
				await conn.sendMessage(m.chat, { contacts: { displayName: nameown, contacts: [{ vcard }] }, contextInfo: { externalAdReply: { title: namebot, body: wm, thumbnailUrl: "https://files.catbox.moe/qyw0po.jpg", showAdAttribution: false, renderLargerThumbnail: true }}}, { quoted: m })
			}
		} else {
			await conn.sendMessage(m.chat, { contacts: { displayName: nameown, contacts: [{ vcard }] }, contextInfo: { externalAdReply: { title: namebot, body: wm, thumbnailUrl: "https://files.catbox.moe/qyw0po.jpg", showAdAttribution: false, renderLargerThumbnail: true, mediaType: 1 }}}, { quoted: m })
		}
	},
	
	tags: ["info", "main"],
	command: ["creator", "owner"],
	help: ["creator", "owner"]
}