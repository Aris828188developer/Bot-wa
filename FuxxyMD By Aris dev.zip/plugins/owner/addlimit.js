let handler = async (m, { conn, command, text, args }) => {
    if (!text) throw 'Harus ada nomor/tag!'

    let t1 = text.split(' ')
    let who
    if (m.isGroup) {
        who = m.mentionedJid[0] ? m.mentionedJid[0] : t1[0] + '@s.whatsapp.net'
    } else {
        who = m.sender
    }

    let users = db.data.users
    let jumlah = t1[1] ? parseInt(t1[1]) : 250

    if (isNaN(jumlah) || jumlah <= 0) throw 'Jumlah harus angka deck!'

    if (!users[who]) {
        users[who] = { limit: 0 } 
    }

    // Pastikan limit di-update dengan benar
    users[who].limit += jumlah
    await conn.reply(m.chat, `Sukses nambah limit sebanyak ${jumlah}! Sekarang limit lu jadi ${users[who].limit}.`, m)
}

handler.help = ['addlimit']
handler.tags = ['owner']
handler.command = /^addlimit(user)?$/i
handler.owner = true

export default handler