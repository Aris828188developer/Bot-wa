const v3 = {
  key: { participant: '0@s.whatsapp.net', remoteJid: '0@s.whatsapp.net' },
  message: { conversation: "Mengubah Tampilan *Menu*" }
}

let handler = async (m, { conn, text, isOwner }) => {
  if (!isOwner) return m.reply('Akses ditolak. Hanya pemilik bot yang dapat menggunakan perintah ini.');

  const mode = text?.toLowerCase();
  const valid = ['image', 'imagepp', 'button', 'payment', 'fullbutton'];
  if (!valid.includes(mode)) {
    return m.reply(`Tampilan tidak dikenal.\n\nSilakan pilih salah satu:\n• image\n• imagepp\n• button\n• payment\n• fullbutton`);
  }

  const setting = global.db.data.settings[conn.user.jid] || {};
  setting.menu = mode;
  global.db.data.settings[conn.user.jid] = setting;

  await conn.sendMessage(m.chat, {
    text: 'Tampilan berhasil diperbarui.',
    mentions: [m.sender],
    contextInfo: {
      mentionedJid: [m.sender],
      isForwarded: true,
      forwardingScore: 1000,
      forwardedNewsletterMessageInfo: {
        newsletterJid: global.newsid,
        newsletterName: global.newsname,
        serverMessageId: '1'
      },
      externalAdReply: {
        title: 'S U C C E S !',
        body: 'Tampilan Menu di Perbarui!',
        thumbnailUrl: global.mediamsg,
        sourceUrl: "https://fuxxy.com",
        mediaType: 1,
        renderLargerThumbnail: false,
        showAdAttribution: true
      }
    }
  }, { quoted: v3 });
};

handler.help = ['menuset <image|imagepp|button|payment|fullbutton>'];
handler.tags = ['owner'];
handler.command = ['menuset'];
handler.owner = true;

export default handler;