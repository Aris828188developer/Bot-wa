const linkRegex = /chat.whatsapp.com\/([0-9A-Za-z]{20,24})( [0-9]{1,3})?/i;
const audio = [
  "https://files.catbox.moe/02gahe.opus"
];

const handler = async (m, { conn, text, isOwner }) => {
  const [_, code, expired] = text.match(linkRegex) || [];
  if (!code) return m.reply("Link tidak valid. Harap pastikan Anda mengirimkan link grup yang benar.");

  try {
    const res = await conn.groupAcceptInvite(code);
    const expiration = Math.floor(
      Math.min(
        9999,
        Math.max(1, isOwner ? (isNumber(expired) ? parseInt(expired) : 0) : 3)
      )
    );
    await m.reply(
      `Berhasil join grup ${res}${expiration ? ` selama ${expiration} hari` : ""}`
    );
    await conn.reply(
      res,
      `Terima kasih sudah menyewa ${global.wm}, Aku akan di sini selama ${expiration} hari`
    );
    await conn.sendFile(res, `${audio}`, "thanks.mp3", null, m, true, {
      type: "audioMessage",
      ptt: true,
  });

    let chats = global.db.data.chats[res];
    if (!chats) chats = global.db.data.chats[res] = {};
    const jumlahHari = expiration * 1000 * 60 * 60 * 24;
    const now = new Date() * 1;
    if (now < chats.expired) chats.expired += jumlahHari;
    else chats.expired = now + jumlahHari;
  } catch (err) {
    console.error("Error saat mencoba join grup:", err);

    // Tangani kesalahan berdasarkan kode error
    if (err.data === 410) {
      return m.reply("Gagal join grup. Link grup sudah kadaluarsa atau tidak valid.");
    } else {
      return m.reply("Terjadi kesalahan saat mencoba join grup. Silakan coba lagi nanti.");
    }
  }
};

handler.help = ["ojoin"];
handler.tags = ["owner"];
handler.command = /^ojoin$/i;
handler.owner = true;

module.exports = handler;

const isNumber = (x) => ((x = parseInt(x)), typeof x === "number" && !isNaN(x));