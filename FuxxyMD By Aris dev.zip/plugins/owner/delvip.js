let handler = async (m, { conn, text, usedPrefix, command }) => {
  function no(number){
    return number.replace(/\s/g,'').replace(/([@+-])/g,'')
  }
  
  if (!text && !m.quoted) return conn.reply(m.chat, `🚩 *Example :* ${usedPrefix}${command} [mention/reply]`, m)
  let who = text ? await conn.parseMention(text)[0] : m.quoted.sender
  delete global.db.data.users[who].vip
  delete global.db.data.users[who].vipTime
  conn.reply(m.chat,`🚩 *Successfully removed VIP access for @${who.split('@')[0]}.*`,m,{ contextInfo: { mentionedJid: [who] } })

}
handler.help = ['delvip *[tag|reply]*']
handler.tags = ['owner']
handler.command = /^(delvip)$/i
handler.mods = true
handler.fail = null

export default handler