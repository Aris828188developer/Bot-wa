let handler = async (m, { isROwner }) => {
  const { exec } = require('child_process');
  const fs = require('fs');

  if (!isROwner) throw 'Perintah ini hanya dapat dijalankan oleh pemilik bot!';

  // Deteksi lingkungan
  let environment;
  if (process.env.PTERODACTYL || fs.existsSync('/.dockerenv')) {
    environment = 'pterodactyl';
  } else {
    environment = 'vps';
  }

  // Kirim pesan pemberitahuan
  if (environment === 'pterodactyl') {
    await m.reply('Terdeteksi bot berjalan dalam Pterodactyl,\nMelakukan protocol restart pterodactyl.\nMohon tunggu 3 detik...');
    
    // Menunggu 3 detik sebelum melakukan restart
    setTimeout(() => {
      exec('npm start', (err, stdout, stderr) => {
        if (err) {
          console.error(`Error: ${stderr}`);
          return m.reply(`Terjadi kesalahan saat restart bot:\n\n${stderr}`);
        }
        console.log(`Output: ${stdout}`);
        m.reply('Bot berhasil direstart!');
      });

      // Setelah restart, keluar proses
      process.exit(0);
    }, 3000); // 3 detik
  } else {
    await m.reply('Terdeteksi bot berjalan di VPS,\nMelakukan protocol restart vps.\nMohon tunggu 3 detik...');
    
    // Menunggu 3 detik sebelum melakukan restart
    setTimeout(() => {
      exec('python3 restart_vps.py', (err, stdout, stderr) => {
        if (err) {
          console.error(`Error: ${stderr}`);
          return m.reply(`Terjadi kesalahan saat restart bot:\n\n${stderr}`);
        }
        console.log(`Output: ${stdout}`);
        m.reply('Proses VPS berhasil direstart!');
      });
    }, 3000); // 3 detik
  }
};

handler.help = ['restart'];
handler.tags = ['owner'];
handler.command = /^(res(tart)?)$/i;

handler.owner = true;

module.exports = handler;