/*
   * COZY MD
   * Credit Nzx | wa.me/6282223537406
   * Dilarang share/menjual sc ini tanpa seizin saya
*/

import fs from 'fs';

export default {
    code: async function handler(m, { conn, args, text, usedPrefix, command }) {
        let input = `[❗] *Reply atau ketik nomor orangnya*\n\nEx: ${usedPrefix + command} index.js [reply]`;
        if (!text && !m.quoted) return m.reply(input);

        let who;
        if (m.quoted) {
        	who = m.quoted.sender;
        } else {
        	who = parseInt(args[0]) ? args[0] + "@s.whatsapp.net" : null
        }

        if (!who) return m.reply(`Tag/nomor nya banh`);
        let path = args[1] ? args[1] : args[0]
        if (!path) return m.reply(`Nama filenya apa banh?`);

        const isValid = await conn.onWhatsApp(who);
        if (isValid.length == 0) {
            return m.reply("Number not in WhatsApp!");
        }
        if (!path.includes(".")) return m.reply("Invalid Format ext")

        try {
            const user_bot = await fs.readFileSync(`./${path}`);
            await conn.sendFile(who, user_bot, path.split("/").reverse()[0], null, m);
            conn.reply(m.chat, 'Success sending file to @' + who.split('@')[0], m, {
                contextInfo: { mentionedJid: [who] },
            });
        } catch (err) {
            m.reply(`Error: ${err.message}`);
        }
    },
    help: ['sendfile *[number/path] [path]*'],
    tags: ['owner'],
    command: /^(sendfile)$/i,
    owner: true,
};