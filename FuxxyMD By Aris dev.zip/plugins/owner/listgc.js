/**
 * ┌─「 Tixo Bot 」
 * │
 * ├ Creator: Tio × Tixo MD
 * ├ Platform: WhatsApp Bot
 * ├ Support us with a donation!
 * └─ wa.me/6282285357346 ✨
 */

/**
@credit Tio
@Tixo MD
@Whatsapp Bot
@Support dengan Donasi ✨
wa.me/6282285357346
**/

let Tio = async (m, { conn, args }) => {
    let now = new Date() * 1;
    let allGroups = await conn.groupFetchAllParticipating();
    let groups = Object.entries(allGroups).map(([jid, data], index) => ({
        index: index + 1,
        jid,
        name: data.subject,
        participants: data.participants,
        desc: data.desc,
    }));

    if (!args[0]) {
        let txt = groups.map((group, i) => `${i + 1}. Name: ${group.name}\n- Member: ${group.participants.length} \n- Sewa: ${(global.db.data.chats[group.jid] || {}).expired ? "✅" : "❌"}${(global.db.data.chats[group.jid] || {}).expired ? `\n- Durasi Sewa: ${msToDate((global.db.data.chats[group.jid] || {}).expired - now)}` : ""}`).join('\n\n');
        m.reply(`乂 *L i s t  G r o u p* :

Total Group: ${groups.length}

${txt}`.trim());
    } else if (args[0] === 'sewa') {
        let sewaGroups = groups.filter(group => {
            let groupData = db.data.chats[group.jid] || {};
            return groupData.expired && groupData.expired > now;
        });

        if (sewaGroups.length === 0) {
            return m.reply('Tidak ada grup yang sedang disewa.');
        }

        let sewaTxt = sewaGroups.map((group, i) => {
            let groupData = db.data.chats[group.jid] || {};
            let sewaStatus = msToDate(groupData.expired - now);
            return `${i + 1}. Name: ${group.name}\n- ID: ${group.jid}\n- Sewa Berakhir: ${sewaStatus}`;
        }).join('\n\n');

        m.reply(`乂 *L i s t  S e w a* :

Total Grup Sewa: ${sewaGroups.length}

${sewaTxt}`.trim());
    } else {
        let index = parseInt(args[0]) - 1;

        if (isNaN(index) || index < 0 || index >= groups.length) {
            return m.reply('Nomor grup tidak valid.');
        }

        let { jid, name, participants, desc } = groups[index];

        if (args[1] === '--id') {
            m.reply(`ID Grup: ${jid}`);
        } else {
            let adminList = participants
                .filter(p => p.admin)
                .map(p => `@${p.id.split('@')[0]}`)
                .join(', ');

            let groupData = db.data.chats[jid] || {
                isBanned: false,
                welcome: false,
                antilink: false,
                antispam: true,
                delete: false,
                expired: null,
            };

            let sewaStatus = groupData.expired
                ? msToDate(groupData.expired - now)
                : 'Tidak diatur';

            let detail = `- Nama Grup: ${name}
- ID Grup: ${jid}
- Deskripsi: ${desc || 'Tidak ada deskripsi'}
- Total Member: ${participants.length}
- Admin Grup: ${adminList || 'Tidak ada admin'}
- Status Sewa: ${sewaStatus}
- Grup Diblokir: ${groupData.isBanned ? '✅ Ya' : '❌ Tidak'}
- Auto Welcome: ${groupData.welcome ? '✅ Ya' : '❌ Tidak'}
- Anti Link: ${groupData.antilink ? '✅ Ya' : '❌ Tidak'}
- Anti Spam: ${groupData.antispam ? '✅ Ya' : '❌ Tidak'}
`.trim();

            m.reply(detail, null, {
                mentions: participants.map(p => p.id),
            });
        }
    }
};

Tio.help = ['listgrup', 'listsewa'];
Tio.tags = ['group'];
Tio.command = /^(listgroup|listgc|listgrup|listsewa)$/i;

export default Tio;

function msToDate(ms) {
    let days = Math.floor(ms / (24 * 60 * 60 * 1000));
    let daysms = ms % (24 * 60 * 60 * 1000);
    let hours = Math.floor((daysms) / (60 * 60 * 1000));
    let hoursms = ms % (60 * 60 * 1000);
    let minutes = Math.floor((hoursms) / (60 * 1000));
    let minutesms = ms % (60 * 1000);
    let sec = Math.floor((minutesms) / (1000 ));
    return `${days} Hari ${hours} Jam ${minutes} Menit`;
}