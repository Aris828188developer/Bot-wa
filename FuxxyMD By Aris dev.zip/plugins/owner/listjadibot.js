let handler = async(m, { conn }) => {
	let user = Object.keys(global.conns).map((o, n) => `*${n+1}. ${o.split("@")[0]} [${db.data.users[o].name}]*`).join("\n");
	m.reply(`*LIST JADIBOT*\n\n` + user);
}
handler.tags = ["owner"]
handler.help = handler.command = ["listjadibot"]

export default handler