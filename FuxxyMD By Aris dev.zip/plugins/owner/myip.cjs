const axios = require('axios');

let handler = async (m, { usedPrefix, command }) => {
  try {
    // Reaksi saat memulai proses
    conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

    // Memanggil API untuk mendapatkan IP publik
    const apiUrl = 'https://api.ipify.org?format=json';
    const response = await axios.get(apiUrl);

    if (response.status === 200) {
      const { ip } = response.data;

      // Reaksi saat proses berhasil
      await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

      // Kirim hasil ke pengguna
      await m.reply(`🌐 *Informasi IP Publik*\n\n➲ *IP*: ${ip}`);
    } else {
      // Reaksi jika gagal
      conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });

      m.reply('❌ Gagal mendapatkan informasi IP. Silakan coba lagi nanti.');
    }
  } catch (error) {
    console.error(error);

    // Reaksi jika terjadi kesalahan
    conn.sendMessage(m.chat, { react: { text: '⚠️', key: m.key } });

    m.reply('❌ Terjadi kesalahan saat memproses permintaan. Pastikan server memiliki akses internet.');
  }
};

handler.help = ['myip'];
handler.tags = ['tools'];
handler.command = /^myip$/i; // Perintah untuk memanggil plugin

handler.rowner = true

module.exports = handler;