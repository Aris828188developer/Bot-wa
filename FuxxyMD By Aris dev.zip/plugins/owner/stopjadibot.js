import fs from "fs";

let handler = async(m, { conn }) => {
	if (!(m.sender in global.conns)) throw "Kamu sedang tidak jadibot";
	if (conn.user.jid == m.sender) return;
	if (fs.existsSync(`./plugins/jadibot/${m.sender.split("@")[0]}`)) {
		fs.rmdirSync(`./plugins/jadibot/${m.sender.split("@")[0]}`, {
			recursive: true
		})
	}
	conn = global.conns[m.sender];
	conn.ev.off('messages.upsert', conn.handler);
	conn.ev.off('group-participants.update', conn.participantsUpdate);
	conn.ev.off('message.update', conn.pollUpdate);
	conn.ev.off('groups.update', conn.groupsUpdate);
	conn.ev.off('connection.update', conn.connectionUpdate);
	conn.ev.off('creds.update', conn.credsUpdate);
	
	delete global.conns[m.sender];
	m.reply("*Sukses Menghapus Sesi Jadibot. Silahkan Log-Out Perangkat Dari Perangkat Tertaut*");
}

handler.tags = ["owner"];
handler.command = handler.help = ["stopjadibot"];

export default handler;