import moment from "moment-timezone";
import PhoneNumber from "awesome-phonenumber";
const { generateWAMessageFromContent, proto, prepareWAMessageMedia } = (await import('baileys-fuxxy')).default
import fetch from "node-fetch";
import os from "os";

let code = async (m, { conn, usedPrefix, command, args, isOwner }) => {
  let more = String.fromCharCode(8206)
  let readMore = more.repeat(4001)
  let perintah = args[0] || "tags";
  let tagCount = {};
  let tagHelpMapping = {};
  let user = global.db.data.users[m.sender];

  Object.keys(global.plugins)
    .filter((plugin) => !global.plugins[plugin].disabled) // Memastikan untuk memeriksa status disabled pada plugin
    .forEach((plugin) => {
      const tagsArray = Array.isArray(global.plugins[plugin].tags) ? global.plugins[plugin].tags : [];
      if (tagsArray.length > 0) {
        let helpArray = Array.isArray(global.plugins[plugin].help)
          ? global.plugins[plugin].help
          : [global.plugins[plugin].help];
        helpArray = helpArray.map((v) =>
          (global.plugins[plugin].premium ? `${v} 🄿` : v) +
          (global.plugins[plugin].vip ? ` 🅅` : "") +
          (global.plugins[plugin].limit ? ` 🄻` : "")
        );

        tagsArray.forEach((tag) => {
          if (tag) {
            if (tagCount[tag]) {
              tagCount[tag]++;
              tagHelpMapping[tag].push(...helpArray);
            } else {
              tagCount[tag] = 1;
              tagHelpMapping[tag] = [...helpArray];
            }
          }
        });
      }
    });

  const generateDashboard = () => 
`I am an automated system (WhatsApp Bot) that can help to do something, search and get data / information only through WhatsApp.\n\n◦ *Database* : Mongodb\n◦ *Developer* : ${global.author}\n◦ *Nama:* ${user.name}\n◦ *Limit* : ${user.limit || ""}\n◦ *Status* : ${!user.registered ? "Not Registered" : global.owner.map(i => i[0]).includes(m.sender.split("@")[0]) ? "Developer" : user.vip ? "VIP User" : user.premium ? "Premium User" : "Free User"}\n\nIf you find an error or want to upgrade premium plan contact the owner.\n‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎`.trimStart();

  const sendAudio = async () => {
    await conn.sendMessage(m.chat, {
      audio: { url: "https://files.catbox.moe/kao2tr.mp3" }, // Ganti dengan URL audio yang valid
      mimetype: 'audio/mp4',
      ptt: true
    }, { quoted: m });
  };

  if (perintah === "tags") {
    const tagslist = Object.keys(tagCount)
      .sort()
      .map((tag) => `◦ ${usedPrefix}${command} ${tag}`)
      .join("\n");
    const teks = `
*M E N U*  

Hii *@${m.sender.split("@")[0]}*! 👋  

${generateDashboard()}

〔 *Available Tags* 〕
${tagslist}

 Enjoy using the bot!  
`;
    /*conn.sendMessage(
      m.chat,
      {
        image: { url: "https://files.catbox.moe/pa1rmt.jpg" },
        gifPlayback: true,
        mentions: [m.sender],
        caption: teks,
      },
      { quoted: m }
    );*/
    await sendAudio();
    /*const messageContent = {
    image: { url: "https://files.catbox.moe/pa1rmt.jpg" },
    gifPlayback: true,
    mentions: [m.sender],
    caption: teks,
    footer: "FANNY MULTI DEVICE",
    buttons: [
      {
        buttonId: `.owner`,
        buttonText: { 
          displayText: "Owner" 
        }
      },
      {
        buttonId: `.menu all`,
        buttonText: {
          displayText: "All Menu"
        }
      },
      {
        buttonId: `.menu game`,
        buttonText: {
          displayText: "Game Menu"
        }
      }
     /* {
        buttonId: `.menu group`,
        buttonText: {
          displayText: "GROUP MENU"
        }
      }
    ],*/
    let sections = [{
		title: 'All Menu Bot ( All )', 
		highlight_label: 'Populer Plugins',
		rows: [{
	    title: 'All Menu',
    	description: `Displays the entire Bot menu ( All )`, 
    	id: '.menu all'
	    }]
	    }, 
    	{
	    title: 'Populer Menu ( List Menu )', 
		highlight_label: 'Populer Plugins',
		rows: [{
	    title: 'Download Feature',
    	description: `Displays menu Download ( List Menu )`, 
    	id: '.menu downloader'
    	},
    	{
		title: 'Rpg Feature', 
		description: "Displays menu Rpg ( List Menu )", 
		id: '.menu rpg'
		},
		{
		title: 'Ai Feature', 
		description: "Displays menu Ai ( List Menu )", 
		id: '.menu ai'
		},
		{
		title: 'Game Feature', 
		description: "Displays menu Game ( List Menu )", 
		id: '.menu game'
		},
		{
		title: 'Music Feature', 
		description: "Displays menu Music ( List Menu )", 
		id: '.menu music'
	    }]
	    },
	    {
	    title: 'System Information ( info )', 
		highlight_label: 'Populer Plugins',
		rows: [{
	    title: 'Creator Bot',
    	description: `Bot owner info, who created it ( information )`, 
    	id: '.owner'
    	},
    	{
    	title: 'Sewa & Premium', 
		description: "Displays Rental and Premium List  ( Information )", 
		id: '.sewa'
		}]
     }]
let listMessage = {
    title: 'List Menu', 
    sections
};

const msg = generateWAMessageFromContent(m.chat, {
scheduledTimestampMs:  Date.now(),
  viewOnceMessage: {
    message: {
        "messageContextInfo": {
          "deviceListMetadata": {},
          "deviceListMetadataVersion": 2
        },
        interactiveMessage: proto.Message.InteractiveMessage.create({
        contextInfo: {
        	mentionedJid: [m.sender], 
        	isForwarded: true, 
	        forwardedNewsletterMessageInfo: {
			newsletterJid: '120363301873496216@newsletter',
			newsletterName: 'Powered by lertod', 
			serverMessageId: -1
	    	},
            externalAdReply: {
            title: "menu", 
            body: namebot,
            thumbnailUrl: gfx,
            mediaType: 1,
            renderLargerThumbnail: true
            },
          }, 
          body: proto.Message.InteractiveMessage.Body.create({
            text: teks
          }),
          footer: proto.Message.InteractiveMessage.Footer.create({
            text: 'ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴡᴀʙᴏᴛ ᴍᴀᴅᴇ ʙʏ ʟᴇʀᴛᴏᴅ'
          }),
          header: proto.Message.InteractiveMessage.Header.create({
            title: `*Hello, @${m.sender.replace(/@.+/g, '')} 🍥*`,
            subtitle: "Lertod",
            hasMediaAttachment: true,...(await prepareWAMessageMedia({ image: { url: 'https://files.catbox.moe/qe833m.jpg' } }, { upload: conn.waUploadToServer }))
          }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
            buttons: [              
              {
                "name": "single_select",
                "buttonParamsJson": JSON.stringify(listMessage) 
              },
              {

              "name": "cta_url",

              "buttonParamsJson": "{\"display_text\":\"Owner\",\"url\":\"https://wa.me/qr/UOTJGUQ7RFGUM1\",\"merchant_url\":\"https://wa.me/qr/UOTJGUQ7RFGUM1\"}"

              },
              {
        buttonId: `${usedPrefix}menu all`,
        buttonText: {
          displayText: "All Menu"
        }
      },
      {
        buttonId: `${usedPrefix}menu group`,
        buttonText: {
          displayText: "Group Menu"
        }
      }
           ],
          })
        })
    }
  }
})

  
  await conn.sendMessage(m.chat, msg, { quoted: m });
  
  } else if (tagCount[perintah]) {
    const helplist = tagHelpMapping[perintah]
      .map((helpItem) => `◦ ${usedPrefix}${helpItem}`)
      .join("\n");
    const teks = `
 *M E N U*
   
Hi *@${m.sender.split("@")[0]}*! 👋  

${generateDashboard()}
 ┌─〔 *${perintah.toUpperCase()}* 〕
 └──────────
              
${helplist}

 Let me assist you!   
`;
    /*conn.sendMessage(
      m.chat,
      {
        image: { url: "https://files.catbox.moe/pa1rmt.jpg" },
        gifPlayback: true,
        mentions: [m.sender],
        caption: teks,
      },
      { quoted: m }
    );*/
    await sendAudio();
       /* const messageContent = {
    image: { url: "https://files.catbox.moe/pa1rmt.jpg" },
    gifPlayback: true,
    mentions: [m.sender],
    caption: teks,
    footer: "FANNY MULTI DEVICE",
    buttons: [
      {
        buttonId: `${usedPrefix}owner`,
        buttonText: { 
          displayText: "Owner" 
        }
      },
      {
        buttonId: `${usedPrefix}menu all`,
        buttonText: {
          displayText: "All Menu"
        }
      },
      {
        buttonId: `${usedPrefix}menu game`,
        buttonText: {
          displayText: "Game Menu"
        }
      }
     /* {
        buttonId: `.menu group`,
        buttonText: {
          displayText: "GROUP MENU"
        }
      }
    ],*/
    
    const msg = generateWAMessageFromContent(m.chat, {
  scheduledTimestampMs:  Date.now(),
  viewOnceMessage: {
    message: {
        "messageContextInfo": {
          "deviceListMetadata": {},
          "deviceListMetadataVersion": 2
        },
        interactiveMessage: proto.Message.InteractiveMessage.create({
        contextInfo: {
        	mentionedJid: [m.sender], 
        	isForwarded: true, 
	        forwardedNewsletterMessageInfo: {
			newsletterJid: '120363301873496216@newsletter',
			newsletterName: 'Powered by lertod', 
			serverMessageId: -1
	    	},
            externalAdReply: {
            title: "menu", 
            body: namebot,
            thumbnailUrl: gfx,
            mediaType: 1,
            renderLargerThumbnail: true
            },
          }, 
          body: proto.Message.InteractiveMessage.Body.create({
            text: teks
          }),
          footer: proto.Message.InteractiveMessage.Footer.create({
            text: 'ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴡᴀʙᴏᴛ ᴍᴀᴅᴇ ʙʏ ʟᴇʀᴛᴏᴅ'
          }),
          header: proto.Message.InteractiveMessage.Header.create({
            title: `*Hello, @${m.sender.replace(/@.+/g, '')} 🍥*`,
            subtitle: "Lertod",
            hasMediaAttachment: true,...(await prepareWAMessageMedia({ image: { url: 'https://files.catbox.moe/qe833m.jpg' } }, { upload: conn.waUploadToServer }))
          }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
            buttons: [              
              {
                "name": "single_select",
                "buttonParamsJson": JSON.stringify(listMessage) 
              },
              {

              "name": "cta_url",

              "buttonParamsJson": "{\"display_text\":\"Owner\",\"url\":\"https://wa.me/qr/UOTJGUQ7RFGUM1\",\"merchant_url\":\"https://wa.me/qr/UOTJGUQ7RFGUM1\"}"

              },
              {
        buttonId: `${usedPrefix}menu all`,
        buttonText: {
          displayText: "All Menu"
        }
      },
      {
        buttonId: `${usedPrefix}menu group`,
        buttonText: {
          displayText: "Group Menu"
        }
      }
           ],
          })
        })
    }
  }
})
  
  await conn.sendMessage(m.chat, msg, { quoted: m });

  } else if (perintah === "all") {
    const allTagsAndHelp = Object.keys(tagCount)
      .map((tag) => {
        const helplist = tagHelpMapping[tag]
          .map((helpItem) => `◦ ${usedPrefix}${helpItem}`)
          .join("\n");
        return `┌─ *〔Tag: ${tag.toUpperCase()}〕*\n└──────────\n${helplist}\n`;
      })
      .join("\n");

    const teks = `
 *All Commands*   
Hi *@${m.sender.split("@")[0]}*! 👋  

${generateDashboard()}

*Features Available:*

${allTagsAndHelp}

 Feel free to explore!   
`;
   const msg = generateWAMessageFromContent(m.chat, {
  scheduledTimestampMs:  Date.now(),
  viewOnceMessage: {
    message: {
        "messageContextInfo": {
          "deviceListMetadata": {},
          "deviceListMetadataVersion": 2
        },
        interactiveMessage: proto.Message.InteractiveMessage.create({
        contextInfo: {
        	mentionedJid: [m.sender], 
        	isForwarded: true, 
	        forwardedNewsletterMessageInfo: {
			newsletterJid: '120363301873496216@newsletter',
			newsletterName: 'Powered by lertod', 
			serverMessageId: -1
	    	},
            externalAdReply: {
            title: "menu", 
            body: namebot,
            thumbnailUrl: gfx,
            mediaType: 1,
            renderLargerThumbnail: true
            },
          }, 
          body: proto.Message.InteractiveMessage.Body.create({
            text: teks
          }),
          footer: proto.Message.InteractiveMessage.Footer.create({
            text: 'ʟɪɢʜᴛᴡᴇɪɢʜᴛ ᴡᴀʙᴏᴛ ᴍᴀᴅᴇ ʙʏ ʟᴇʀᴛᴏᴅ'
          }),
          header: proto.Message.InteractiveMessage.Header.create({
            title: `*Hello, @${m.sender.replace(/@.+/g, '')} 🍥*`,
            subtitle: "Lertod",
            hasMediaAttachment: true,...(await prepareWAMessageMedia({ image: { url: 'https://files.catbox.moe/qe833m.jpg' } }, { upload: conn.waUploadToServer }))
          }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
            buttons: [              
              {
                "name": "single_select",
                "buttonParamsJson": JSON.stringify(listMessage) 
              },
              {

              "name": "cta_url",

              "buttonParamsJson": "{\"display_text\":\"Owner\",\"url\":\"https://wa.me/qr/UOTJGUQ7RFGUM1\",\"merchant_url\":\"https://wa.me/qr/UOTJGUQ7RFGUM1\"}"

              },
              {
        buttonId: `${usedPrefix}menu all`,
        buttonText: {
          displayText: "All Menu"
        }
      },
      {
        buttonId: `${usedPrefix}menu group`,
        buttonText: {
          displayText: "Group Menu"
        }
      }
           ],
          })
        })
    }
  }
})
     /*const messageContent = {
    image: { url: "https://files.catbox.moe/pa1rmt.jpg" },
    gifPlayback: true,
    mentions: [m.sender],
    caption: teks,
    footer: "FANNY MULTI DEVICE",
    buttons: [
      {
        buttonId: `${usedPrefix}owner`,
        buttonText: { 
          displayText: "Owner" 
        }
      },
      {
        buttonId: `${usedPrefix}menu`,
        buttonText: {
          displayText: "List Menu"
        }
      },
      {
        buttonId: `${usedPrefix}menu group`,
        buttonText: {
          displayText: "Group Menu"
        }
      }
     /* {
        buttonId: `.menu group`,
        buttonText: {
          displayText: "GROUP MENU"
        }
      }
    ],*/

  await conn.relayMessage(msg.key.remoteJid, msg.message, { messageId: msg.key.id })
  
    /*conn.sendMessage(
      m.chat,
      {
        text: teks,
        contextInfo: {
          mentionedJid: [m.sender],
          externalAdReply: {
            title: namebot,
            mediaType: 1,
            thumbnailUrl: gfx,
            renderLargerThumbnail: true,
          },
        },
      },
      { quoted: m }
    );*/
    await sendAudio();
  }
};


export default {
  code,
  tags: ["main"],
  help: ["menu"],
  command: ["menu2", "help2"],
  register: true,
};
function clockString(ms) {
  let h = Math.floor(ms / 3600000);
  let m = Math.floor(ms / 60000) % 60;
  let s = Math.floor(ms / 1000) % 60;
  return [h, m, s].map((v) => v.toString().padStart(2, "0")).join(":");
}