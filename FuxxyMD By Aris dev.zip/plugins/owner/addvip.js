/*
   * COZY MD
   * Credit Nzx | wa.me/6282223537406
   * Dilarang share/menjual sc ini tanpa seizin saya
*/

let handler = async (m, { conn, text, usedPrefix }) => {
  if (conn.user.jid !== global.conn.user.jid) return
  function no(number){
    return number.replace(/\s/g,'').replace(/([@+-])/g,'')
  }

  var hl = []
  hl[0] = text.split('|')[0]
  hl[0] = no(hl[0]) + "@s.whatsapp.net"
  hl[1] = text.split('|')[1]
  
  if (!text) return conn.reply(m.chat, `🚩 *Example :* .addvip 6282223537406|10`, m)
  if (typeof db.data.users[hl[0]] == 'undefined') return conn.reply(m.chat,  '🚩 User does not exist in the database', m)
  var jumlahHari = 86400000 * hl[1]
  var now = new Date() * 1
  if (isNaN(jumlahHari)) {
    global.db.data.users[hl[0]].vip = true;
    global.db.data.users[hl[0]].vipTime = Infinity;
  } else {
    global.db.data.users[hl[0]].vip = true;
    if (now < global.db.data.users[hl[0]].vipTime)
      global.db.data.users[hl[0]].vipTime += jumlahHari;
    global.db.data.users[hl[0]].vipTime = now + jumlahHari;
  }

  let vipTime =
    global.db.data.users[hl[0]].vipTime === Infinity
      ? "Unlimited"
      : msToDate(global.db.data.users[hl[0]].vipTime - now);
  conn.reply(m.chat,`*🚩 UPGRADE VIP 👑*\n\nBerhasil menambahkan akses VIP kepada *@${hl[0].split('@')[0]}* selama *${hl[1]} hari*.\n\n*VIP : ${msToDate(global.db.data.users[hl[0]].vipTime - now)}*`,m,{ contextInfo: { mentionedJid: [hl[0]] } })
  conn.reply(hl[0],`* 🚩 UPGRADE VIP 👑*\n\nBerhasil menambahkan akses VIP kepada *Anda* selama *${hl[1]} hari*.\n\n*VIP : ${msToDate(global.db.data.users[hl[0]].vipTime - now)}*`,m,{ contextInfo: { mentionedJid: [hl[0]] } }) 

}
handler.help = ['addvip *[@tag|days]*']
handler.tags = ['owner']
handler.command = /^(addvip)$/i
handler.mods = true
handler.fail = null

export default handler

function msToDate(ms) {
  let days = Math.floor(ms / (24*60*60*1000));
  let daysms = ms % (24*60*60*1000);
  let hours = Math.floor((daysms)/(60*60*1000));
  let hoursms = ms % (60*60*1000);
  let minutes = Math.floor((hoursms)/(60*1000));
  let minutesms = ms % (60*1000);
  let sec = Math.floor((minutesms)/(1000));
  return days+":"+hours+":"+ minutes + "";
}