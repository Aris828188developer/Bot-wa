const handler = async (m, { conn, text, args }) => {
    let time = global.db.data.users[m.sender].lastjoin + 86400000;
    let linkRegex = /chat.whatsapp.com\/([0-9A-Za-z]{20,24})/i;
    let delay = time => new Promise(res => setTimeout(res, time));

    let name = m.sender;
    let fkonn = {
        key: {
            fromMe: false,
            participant: `0@s.whatsapp.net`,
            ...(m.chat ? {
                remoteJid: m.sender
            } : {})
        },
        message: {
            contactMessage: {
                displayName: `${await conn.getName(name)}`,
                vcard: `BEGIN:VCARD\nVERSION:3.0\nN:;a,;;;\nFN:${name}\nitem1.TEL;waid=${m.sender.split('@')[0]}:${m.sender.split('@')[0]}\nitem1.X-ABLabel:Ponsel\nEND:VCARD`
            }
        }
    };

    let [_, code] = text.match(linkRegex) || [];
    if (!args[0]) throw `Link nya mana?`;
    if (!code) throw `Link tidak valid!`;
    if (!args[1]) throw `Angkanya mana?`;
    if (isNaN(args[1])) throw `Hanya angka, mewakili hari!`;

    let anubot = nomorown
    m.reply(`Tunggu 3 detik bot akan join`);
    await delay(3000);

        let res = await conn.groupAcceptInvite(code);
        let b = await conn.groupMetadata(res);
        let d = b.participants.map(v => v.id);
        let member = d.toString();
        let jumlahHari = 86400000 * args[1];
        let now = new Date() * 1;

        if (now < global.db.data.chats[res].expired) global.db.data.chats[res].expired += jumlahHari;
        else global.db.data.chats[res].expired = now + jumlahHari;

        await m.reply(`Sukses invite bot ke group\n\n${await conn.getName(res)}\n\nBot akan keluar secara otomatis setelah\n${msToDate(global.db.data.chats[res].expired - now)}`);
        
        await conn.reply(anubot + '@s.whatsapp.net', `*INVITING!*\n\n@${m.sender.split('@')[0]} telah mengundang ${conn.user.name} ke grup\n\n${await conn.getName(res)}\n\n${res}\n\nPesan : ${args[0]}\n\nBot akan keluar otomatis setelah\n${msToDate(global.db.data.chats[res].expired - now)}`, null, {
            mentions: [m.sender]
        });

        //await m.reply(`Sukses invite bot ke group\n\n${await conn.getName(res)}\n\nBot akan keluar secara otomatis setelah *${msToDate(global.db.data.chats[res].expired - now)}*`).then(async () => {
            let mes = `Hello Everyone👋🏻\n*${conn.user.name}* adalah salah satu Bot WhatsApp Multi-Device yang di bangun dengan Node.js, *${conn.user.name}* Baru aja di invite oleh *${m.name}*\nUntuk menggunakan *${conn.user.name}* silahkan ketik\n.menu\n@${conn.user.jid.split('@')[0]} akan keluar secara otomatis setelah\n${msToDate(global.db.data.chats[res].expired - now)}`;
            await conn.reply(res, mes, fkonn, {
                mentions: d
            });
};

handler.help = ['join *[chat.whatsapp.com] [day]*'];
handler.tags = ['owner'];
handler.command = /^join(sewa)?$/i;
handler.owner = true;

module.exports = handler;

function msToDate(ms) {
    let d = isNaN(ms) ? '--' : Math.floor(ms / 86400000)
    let h = isNaN(ms) ? '--' : Math.floor(ms / 3600000) % 24
    let m = isNaN(ms) ? '--' : Math.floor(ms / 60000) % 60
    let s = isNaN(ms) ? '--' : Math.floor(ms / 1000) % 60
    return [d, ' *Days ☀️*\n ', h, ' *Hours 🕐*\n ', m, ' *Minute ⏰*\n ', s, ' *Second ⏱️* '].map(v => v.toString().padStart(2, 0)).join('')
}