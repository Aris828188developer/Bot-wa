/**
@credit Angga
@Kagenou - MD
@Whatsapp Bot
@Support dengan Donasi ✨
wa.me/6285895954504
**/

let Tio = async (m, { conn, text, command }) => {
    let who = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text ? text.replace(/[^0-9]/g, '') + '@s.whatsapp.net' : false;

    let bl = db.data.chats[m.chat].blacklist || [];
    let peserta = await conn.groupMetadata(m.chat);

    switch (command) {
        case 'blacklist':
            if (!text) return conn.reply(m.chat, 'Masukkan kata yang ingin diblacklist', m);

            const wordToAdd = text.toLowerCase();
            if (bl.includes(wordToAdd)) {
                return conn.reply(m.chat, `Kata '${wordToAdd}' sudah ada di dalam daftar blacklist.`, m);
            }

            bl.push(wordToAdd);
            db.data.chats[m.chat].blacklist = bl;
            await conn.reply(m.chat, `Kata '${wordToAdd}' berhasil ditambahkan ke dalam daftar blacklist.`, m);
            break;

        case 'unblacklist':
            if (!text) return conn.reply(m.chat, 'Masukkan kata yang ingin dihapus dari blacklist', m);

            const wordToRemove = text.toLowerCase();
            const index = bl.indexOf(wordToRemove);
            if (index === -1) {
                return conn.reply(m.chat, `Kata '${wordToRemove}' tidak ditemukan dalam daftar blacklist.`, m);
            }

            bl.splice(index, 1);
            db.data.chats[m.chat].blacklist = bl;
            await conn.reply(m.chat, `Kata '${wordToRemove}' berhasil dihapus dari daftar blacklist.`, m);
            break;

        case 'listblacklist':
        case 'listbl':
            let txt = `*「 Daftar Kata Blacklist 」*\n\n*Total:* ${bl.length}\n\n┌─[ *BlackList* ]\n`;

            for (let i of bl) {
                txt += `├ ${i}\n`;
            }
            txt += "└─•";

            return conn.reply(m.chat, txt, m);
            break;
    }
};

Tio.help = ['unblacklist', 'blacklist', 'listblacklist'];
Tio.tags = ['group'];
Tio.command = ['unblacklist', 'blacklist', 'listbl', 'listblacklist'];
Tio.admin = Tio.group = true;

Tio.before = async function(m, { conn, isAdmin, isOwner }) {
    if (!m.isGroup) return;
    if (m.fromMe) return;

    let bl = db.data.chats[m.chat].blacklist || [];
    const lowerCaseMessage = m.text?.toLowerCase();
    const isSenderAdmin = isAdmin || isOwner || m.sender === conn.user.jid;

    if (!isSenderAdmin && lowerCaseMessage) {
        for (const word of bl) {
            if (lowerCaseMessage.includes(word)) {
                await conn.sendMessage(
                    m.chat,
                    {
                        text: `Pesan dari @${m.sender.split('@')[0]} telah dihapus karena mengandung kata yang diblacklist: *${word}*`,
                    },
                    { mentions: [m.sender] }
                );

                try {
                    await conn.sendMessage(m.chat, { delete: m.key });
                } catch (error) {
                    console.error("Gagal menghapus pesan:", error.message);
                }
                return true;
            }
        }
    }

    return false;
};

export default Tio;