let handler = async (m, { conn, text, usedPrefix, command }) => {
  function no(number){
    return number.replace(/\s/g,'').replace(/([@+-])/g,'')
  }
  
  if (!text && !m.quoted) return conn.reply(m.chat, `🚩 *Example :* ${usedPrefix}${command} [mention/reply]`, m)
  let who = text ? await conn.parseMention(text)[0] : m.quoted.sender
  delete global.db.data.users[who].premium 
  delete global.db.data.users[who].premiumTime
  conn.reply(m.chat,`🚩 *Successfully removed premium access for @${who.split('@')[0]}.*`,m,{ contextInfo: { mentionedJid: [who] } })

}
handler.help = ['delprem *[tag|reply]*']
handler.tags = ['owner']
handler.command = /^(delprem)$/i
handler.mods = true
handler.fail = null

export default handler