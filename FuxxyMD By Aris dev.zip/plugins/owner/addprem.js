/*
   * COZY MD
   * Credit Nzx | wa.me/6282223537406
   * Dilarang share/menjual sc ini tanpa seizin saya
*/

let handler = async (m, { conn, text, usedPrefix }) => {
  if (conn.user.jid !== global.conn.user.jid) return
  function no(number){
    return number.replace(/\s/g,'').replace(/([@+-])/g,'')
  }

  var hl = []
  hl[0] = text.split('|')[0]
  hl[0] = no(hl[0]) + "@s.whatsapp.net"
  hl[1] = text.split('|')[1]
  
  if (!text) return conn.reply(m.chat, `🚩 *Example :* .addprem 6282223537406|100`, m)
  if (typeof db.data.users[hl[0]] == 'undefined') return conn.reply(m.chat,  '🚩 User does not exist in the database', m)
  var jumlahHari = 86400000 * hl[1]
  var now = new Date() * 1
  if (isNaN(jumlahHari)) {
    global.db.data.users[hl[0]].premium = true;
    global.db.data.users[hl[0]].premiumTime = Infinity;
  } else {
    global.db.data.users[hl[0]].premium = true;
    if (now < global.db.data.users[hl[0]].premiumTime)
      global.db.data.users[hl[0]].premiumTime += jumlahHari;
    global.db.data.users[hl[0]].premiumTime = now + jumlahHari;
  }

  let premiumTime =
    global.db.data.users[hl[0]].premiumTime === Infinity
      ? "Unlimited"
      : msToDate(global.db.data.users[hl[0]].premiumTime - now);
  conn.reply(m.chat,`*🚩 UPGRADE PREMIUM*\n\nBerhasil menambahkan akses premium kepada *@${hl[0].split('@')[0]}* selama *${hl[1]} hari*.\n\n*Premium : ${msToDate(global.db.data.users[hl[0]].premiumTime - now)}*`,m,{ contextInfo: { mentionedJid: [hl[0]] } })
  conn.reply(hl[0],`* 🚩UPGRADE PREMIUM*\n\nBerhasil menambahkan akses premium kepada *Anda* selama *${hl[1]} hari*.\n\n*Premium : ${msToDate(global.db.data.users[hl[0]].premiumTime - now)}*`,m,{ contextInfo: { mentionedJid: [hl[0]] } }) 

}
handler.help = ['addprem *[@tag|days]*']
handler.tags = ['owner']
handler.command = /^(addprem)$/i
handler.mods = true
handler.fail = null

export default handler

function msToDate(ms) {
  let days = Math.floor(ms / (24*60*60*1000));
  let daysms = ms % (24*60*60*1000);
  let hours = Math.floor((daysms)/(60*60*1000));
  let hoursms = ms % (60*60*1000);
  let minutes = Math.floor((hoursms)/(60*1000));
  let minutesms = ms % (60*1000);
  let sec = Math.floor((minutesms)/(1000));
  return days+":"+hours+":"+ minutes + "";
}