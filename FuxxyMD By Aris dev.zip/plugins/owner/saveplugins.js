/*
   * COZY MD
   * Credit Nzx | wa.me/6282223537406
   * Dilarang share/menjual sc ini tanpa seizin saya
*/

import fs from 'fs';
import syntaxError from "syntax-error"

let handler = async (m, { text, usedPrefix, command }) => {
    if (command == "sp") return m.reply("`Gunakan format:`\n     .spesm\n     .spcjs")
    if (!text) return conn.reply(m.chat, `🚩 *Example :* ${usedPrefix + command} main/menu`, m)
    if (!m.quoted) return conn.reply(m.chat, `📚 Reply Code Message!`, m)
    if (command == "spesm") {
        let path = `plugins/${text}.js`
        const err = await syntaxError(m.quoted.text, `${text}.js`, {
        	sourceType: 'module',
            allowReturnOutsideFunction: true,
            allowAwaitOutsideFunction: true
        })
        if (err) throw err
        await fs.writeFileSync(path, m.quoted.text)
        conn.reply(m.chat, `📮 Saved in ${path}`, m)
    } else if (command == "spcjs") {
    	let path = `plugins/${text}.cjs`
        const err = await syntaxError(m.quoted.text, `${text}.cjs`, {
        	sourceType: 'script',
            allowReturnOutsideFunction: true,
            allowAwaitOutsideFunction: true
        })
        if (err) throw err
        await fs.writeFileSync(path, m.quoted.text)
        conn.reply(m.chat, `📮 Saved in ${path}`, m)
    }
}
handler.help = ['sp'].map(v => v + ' *[text]*')
handler.tags = ['owner']
handler.command = /^sp(esm|cjs)?$/i

handler.owner = true
export default handler