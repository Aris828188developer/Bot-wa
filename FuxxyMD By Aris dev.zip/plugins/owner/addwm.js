export default {
command: "addwm",
code: async function code(m, { text }) {
conn.sendMessage(m.chat, { text: "/*\n   * COZY MD\n   * Credit Nzx | wa.me/6282223537406\n   * Dilarang share/menjual sc ini tanpa seizin saya\n*/\n\n" + m.quoted.text })
},
}