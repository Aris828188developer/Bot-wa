/*
   * COZY MD
   * Credit Nzx | wa.me/6282223537406
   * Dilarang share/menjual sc ini tanpa seizin saya
*/

import cp, { exec as _exec } from 'child_process';
import { promisify } from 'util';

let exec = promisify(_exec).bind(cp);

let handler = async (m, { conn, isROwner, usedPrefix, command, text }) => {

    if (!isROwner) return;

    let ar = Object.keys(plugins);
    let ar1 = ar.map(v => v.replace('.js', ''));

    if (!text) {
        throw `🚀 *Gunakan Perintah dengan Benar!*\n\n🔍 Contoh: \n*${usedPrefix + command} main*`;
    }
    await m.reply('*Mencari Plugins.....*');

    let keyword = text.toLowerCase();

   
    let foundPlugins = ar1.filter(v => v.toLowerCase().includes(keyword) || keyword.includes(v.toLowerCase()));

    if (foundPlugins.length === 0) {
        return m.reply(`❌ *Plugin Tidak Ditemukan!*\n\n🔍 *Coba dengan kata kunci lain.*\n📂 *Total Plugin:* ${ar1.length}`);
    }

    let result = `🔍 *Plugin Ditemukan!*\n\n📂 *Total Plugin yang Cocok:* ${foundPlugins.length}\n\n${foundPlugins.map((v, i) => `✨ *${i + 1}.* ${v}`).join('\n')}`;

    await conn.sendMessage(m.chat, { text: result, contextInfo: {
        forwardingScore: 2025,
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
            newsletterJid: global.newsname,
            serverMessageId: null,
            newsletterName: global.newsid,
        }
    }}, { quoted: m });
};

handler.help = ['searchplugin'].map(v => v + ' *[text]*');
handler.tags = ['owner'];
handler.command = /^(searchplugins?)$/i;
handler.owner = true;

export default handler;