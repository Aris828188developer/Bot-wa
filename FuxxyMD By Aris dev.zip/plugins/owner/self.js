let handler = async(m, { conn, command }) => {
  let isPublic = command === "public";
  let self = global.db.data.settings[conn.user.jid].self

  if(self === !isPublic) return m.reply(`Dah ${!isPublic ? "Self" : "Public"} dari tadi ${m.sender.split("@")[0] === global.owner[1] ? "Mbak" : "Bang"} :v`)

  global.db.data.settings[conn.user.jid].self = !isPublic

  m.reply(`Berhasil ${!isPublic ? "Self" : "Public"} bot!`)
}

handler.help = ["self", "public"]
handler.tags = ["owner"]

handler.rowner = false
handler.owner = true

handler.command = /^(self|public)/i

export default handler