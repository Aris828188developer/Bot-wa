import fetch from 'node-fetch';
import Button from '../system/Button.js';

const handler = async (m, { conn }) => {
  const thumbUrl = `${global.gfx}`;
  let buffer;
  try {
    const res = await fetch(thumbUrl);
    buffer = await res.buffer();
  } catch {
    return m.reply('Gagal mengambil thumbnail. Silakan coba lagi nanti.');
  }

  const btn = new Button()
    .setImage(buffer)
    .setTitle('Pengaturan Tampilan Menu')
    .setBody('Pilih salah satu tampilan berikut untuk mengubah gaya menu utama bot.')
    .setFooter('Pengaturan Sistem')
    .addSelection('Tampilan Menu')
    .makeSections('Pilih Gaya Tampilan', 'Fast Respon')
    .makeRow('Tampilan Gambar', 'Image', 'Menu dengan latar gambar penuh.', '.menuset image')
    .makeRow('Gambar & Profil', 'ImagePP', 'Latar menu disertai foto profil bot.', '.menuset imagepp')
    .makeRow('Tampilan Tombol', 'Button', 'Menu dengan tombol sederhana, dan cepat.', '.menuset button')
    .makeRow('Tampilan Tombol', 'Full Button', 'Menu dengan tombol lengkap, sederhana, dan cepat.', '.menuset fullbutton')
    .makeRow('Simulasi Pembayaran', 'Payment', 'Tampilan menyerupai menu pembayaran.', '.menuset payment');

  await btn.run(m.chat, conn, m);
};

handler.help = ['setmenu'];
handler.tags = ['menu'];
handler.command = ['setmenu'];

export default handler;