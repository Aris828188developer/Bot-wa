/*
   * COZY MD
   * Credit Nzx | wa.me/6282223537406
   * Dilarang share/menjual sc ini tanpa seizin saya
*/

import { readFileSync, existsSync } from "fs"

let handler = async (m, { usedPrefix, command, text, conn }) => {
    let ar = Object.keys(plugins);
    let ar1 = ar.map(v => v.replace(/\/plugins\/|\.c?js$/g, ''));

    if (!text) {
       throw `• *Example :* ${usedPrefix + command} main/menu`
    }
    let keyword = text.toLowerCase();
    let foundPlugins = ar1.filter(v => v.toLowerCase().includes(keyword) || keyword.includes(v.toLowerCase()));

    if (!ar1.includes(text)) {
       return conn.reply(
           m.chat, 
           `'${text}' tidak ditemukan!. Mungkin yang kamu maksud adalah\n\n${foundPlugins.map((v, i) => `✨ *${i + 1}.* ${v}`).join('\n')}`, 
           m
       );
    }

    let filePath = `./plugins/${text}`;
    if (existsSync(filePath + '.js')) {
        filePath += '.js';
    } else {
        filePath += '.cjs';
    }
    
    let teks = readFileSync(filePath, 'utf-8');
    await conn.sendMessage(m.chat, { text: teks }, { quoted: m });
}
handler.help = ['getplugin'].map(v => v + ' *[text]*')
handler.tags = ['owner']
handler.command = /^(getplugin|gp)$/i

handler.owner = true

export default handler;