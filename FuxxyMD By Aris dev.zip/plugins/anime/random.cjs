/*Simple WhatsApp bot
 * Credits : Bang_syaii
 * RestAPI : https://api.botwa.space
 * Community : https://api.botwa.space/s/gcbot
 */

let handler = async (m, {
    conn,
    text,
    usedPrefix,
    command
}) => {
    let res = await (
        await fetch(
            `https://raw.githubusercontent.com/KazukoGans/database/main/anime/${command}.json`,
        )
    ).json();
    let cita = res[Math.floor(Math.random() * res.length)];
    conn.sendMessage(m.chat, {
        image: {
            url: cita
        },
        caption: `– Select Options :
1. Next Image 
2. Back to menu`
    , buttons: [{
        buttonId: usedPrefix + command ,
        buttonText: { displayText: "1" },
        type: 1
    }, {
         buttonId: ".menu",
         buttonText: { displayText: "2" },
         type: 1
    }]}, { quited: m });
};
handler.help = [
    "akira",
    "akiyama",
    "asuna",
    "ayuzawa",
    "boruto",
    "chitanda",
    "chitoge",
    "deidara",
    "doraemon",
    "elaina",
    "emilia",
    "asuna",
    "erza",
    "gremory",
    "hestia",
    "hinata",
    "inori",
    "itachi",
    "isuzu",
    "itori",
    "kaga",
    "kagura",
    "kakasih",
    "kaori",
    "kaneki",
    "kosaki",
    "kotori",
    "kuriyama",
    "kuroha",
    "kurumi",
    "madara",
    "mikasa",
    "miku",
    "minato",
    "naruto",
    "natsukawa",
    "nekohime",
    "nezuko",
    "nishimiya",
    "onepiece",
    "pokemon",
    "rem",
    "rize",
    "sagiri",
    "sakura",
    "sasuke",
    "shina",
    "shinka",
    "shizuka",
    "shota",
    "tomori",
    "toukachan",
    "tsunade",
    "yatogami",
    "yuki",
]
handler.tags = ["anime"];
handler.command = [
    "akira",
    "akiyama",
    "asuna",
    "ayuzawa",
    "boruto",
    "chitanda",
    "chitoge",
    "deidara",
    "doraemon",
    "elaina",
    "emilia",
    "asuna",
    "erza",
    "gremory",
    "hestia",
    "hinata",
    "inori",
    "itachi",
    "isuzu",
    "itori",
    "kaga",
    "kagura",
    "kakasih",
    "kaori",
    "kaneki",
    "kosaki",
    "kotori",
    "kuriyama",
    "kuroha",
    "kurumi",
    "madara",
    "mikasa",
    "miku",
    "minato",
    "naruto",
    "natsukawa",
    "nekohime",
    "nezuko",
    "nishimiya",
    "onepiece",
    "pokemon",
    "rem",
    "rize",
    "sagiri",
    "sakura",
    "sasuke",
    "shina",
    "shinka",
    "shizuka",
    "shota",
    "tomori",
    "toukachan",
    "tsunade",
    "yatogami",
    "yuki",
];
handler.limit = true;

module.exports = handler;