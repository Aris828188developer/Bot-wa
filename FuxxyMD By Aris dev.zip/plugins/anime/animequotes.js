/*
Jangan Hapus Wm Bang 

*Quote Anime  Plugins Esm*

Wel Lebaran Kapan Yah Besok atau Senin 
Cjs Dah Ku Taroh Di Ch 

*[Sumber]*
https://whatsapp.com/channel/0029Vb3u2awADTOCXVsvia28

*[Sumber Scrape]*

https://whatsapp.com/channel/0029VbB0oUvBlHpYbmFDsb3E
*/

import axios from "axios";
import * as cheerio from "cheerio";

async function randomQuotesAnimes() {
   let { data } = await axios.get(`https://otakotaku.com/quote/feed`);
   let $ = cheerio.load(data);
   
   let quotes = [];

   $(".kotodama-list").each((i, el) => {
      let character = $(el).find(".char-name").text().trim();
      let anime = $(el).find(".anime-title").text().trim();
      let episode = $(el).find(".meta").text().trim();
      let quote = $(el).find(".quote").text().trim();
      let image = $(el).find(".char-img img").attr("data-src");
      let link = $(el).find("a.kuroi").attr("href");

      quotes.push({
         character,
         anime,
         episode,
         quote,
         image,
         link: `https://otakotaku.com${link}`
      });
   });

   return quotes.length > 0 ? quotes[Math.floor(Math.random() * quotes.length)] : null;
}

let handler = async (m, { conn }) => {
   m.reply('*Mencari Quotes Anime...*')
   
   try {
      const result = await randomQuotesAnimes()
      
      if (!result) return m.reply('Quotes Not Found')
      
      const bell = `
*Character :* ${result.character}
*Anime :* ${result.anime}
*Episode :* ${result.episode}\n\n
*Quote :* "${result.quote}"
`.trim()
      
      await conn.sendMessage(m.chat, { 
         image: { url: result.image },
         caption: bell
      }, { quoted: m })
      
   } catch (error) {
      console.error(error)
      m.reply('Error😭')
   }
}

handler.help = ['animequote']
handler.tags = ['anime']
handler.command = /^(animequote|quoteanime|aniquote)$/i

export default handler