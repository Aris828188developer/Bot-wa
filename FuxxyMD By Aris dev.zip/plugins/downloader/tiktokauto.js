const axios = require('axios');
const cheerio = require("cheerio");
const baileys = require("baileys-fuxxy");
const { proto, generateWAMessageFromContent } = baileys;

exports.before = async function(m) {
    const tiktokRegex = /https:\/\/(?:www\.tiktok\.com|vt\.tiktok\.com|vm\.tiktok\.com)\/(?:@[\w.-]+\/video\/\d+|v\/\d+|.*\/[\w.-]+\/video\/\d+|[\w.-]+)\b/g;
    const matches = m.text.trim().match(tiktokRegex);
    if (!matches) return false;

    await conn.sendMessage(m.chat, { react: { text: '⏱️', key: m.key } });

    try {
        const media = await getTikTokMedia(matches[0]);

        if (!media) {
            await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
            return conn.reply(m.chat, 'Gagal mengunduh media, coba lagi nanti.', m);
        }

        await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

        let caption = `*TikTok Downloader*\n> By : ` + global.namebot;

        if (Array.isArray(media.images) && media.images.length > 0) {
            const cards = await Promise.all(media.images.map(async (url, index) => ({
                header: proto.Message.InteractiveMessage.Header.fromObject({
                    title: `Image ${index + 1} / ${media.images.length}`,
                    hasMediaAttachment: true,
                    imageMessage: await createImage(url)
                }),
                nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                    buttons: []
                })
            })));

            const msg = baileys.generateWAMessageFromContent(m.chat, {
                viewOnceMessage: {
                    message: {
                        messageContextInfo: {
                            deviceListMetadata: {},
                            deviceListMetadataVersion: 2
                        },
                        interactiveMessage: proto.Message.InteractiveMessage.fromObject({
                            body: proto.Message.InteractiveMessage.Body.fromObject({
                                text: caption
                            }),
                            carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
                                cards
                            })
                        })
                    }
                }
            }, {});

            await conn.relayMessage(msg.key.remoteJid, msg.message, {
                messageId: msg.key.id
            });

        } else {
            await conn.sendFile(m.chat, media.no_watermark, "tiktok.mp4", caption, m);
        }

        if (media.music) {
            await conn.sendMessage(m.chat, {
                audio: {
                    url: media.music
                },
                mimetype: 'audio/mp4',
                fileName: `${media.title}.mp3`
            }, { quoted: m });
        }

    } catch (e) {
        await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        console.error('Error saat sedang memproses:', e);
        return conn.reply(m.chat, 'Sedang Error', m);
    }
}

exports.disabled = false;

async function getTikTokMedia(url) {
    if (url.includes('vt.tiktok.com')) {
        // Menggunakan axios untuk follow redirect vt.tiktok.com
        try {
            const response = await axios.get(url, {
                maxRedirects: 0,
                validateStatus: status => status >= 200 && status < 400
            });

            if (response.status === 301 || response.status === 302) {
                url = response.headers.location;
            } else {
                throw new Error('Tidak dapat mengikuti redirect URL.');
            }
        } catch (error) {
            if (error.response && (error.response.status === 301 || error.response.status === 302)) {
                url = error.response.headers.location;
            } else {
                throw new Error('Tidak dapat mengurai URL dari vt.tiktok.com');
            }
        }
    }

    const encodedParams = new URLSearchParams({ url: url }).toString();
    const response = await axios.post('https://tikwm.com/api/', encodedParams, {
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
            'Cookie': 'current_language=en',
            'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36'
        }
    });
    const videos = response.data.data;

    if (videos.images && videos.images.length > 0) {
        return {
            title: videos.title,
            images: videos.images,
            music: videos.music
        };
    }

    return {
        title: videos.title,
        no_watermark: videos.play,
        music: videos.music,
        images: []
    };
}

async function createImage(url) {
    const { imageMessage } = await baileys.generateWAMessageContent({
        image: {
            url
        }
    }, {
        upload: conn.waUploadToServer
    });
    return imageMessage;
}