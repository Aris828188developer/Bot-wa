/* 
- Fitur By Maki, Downloader Terabox
- Type Plugins Cjs
- https://whatsapp.com/channel/0029VakSf6V5K3zaOcozHU2J

- TqTo Penyedia Api
*/
import axios from "axios"
import { fileTypeFromBuffer } from "file-type"

let handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) return m.reply(`Masukkan link Terabox!\n\nContoh: ${usedPrefix + command} <link>`);

  try {
    let url = `https://exonity.tech/api/dl/terabox?url=${encodeURIComponent(text)}`;
    let { data } = await axios.get(url);

    if (data.status !== 200 || !data.result || data.result.length === 0) {
      return m.reply("Gagal mengambil data. Pastikan link Terabox benar.");
    }

    let message = `*📂 Daftar File Terabox:*\n\n`;
    conn.fileList = conn.fileList || {};
    conn.fileList[m.chat] = {};

    data.result.forEach((file, index) => {
      let fileSize = (file.size / (1024 * 1024)).toFixed(2) + " MB";
      message += `📌 *${index + 1}. ${file.filename}*\n📏 Ukuran: ${fileSize}\n\n`;
      conn.fileList[m.chat][index + 1] = file;
    });

    message += "Silakan balas pesan ini dengan nomor file yang ingin diunduh.";
    m.reply(message);
  } catch (error) {
    console.error(error);
    m.reply("Terjadi kesalahan saat mengambil data.");
  }
};

handler.help = ["terabox *[url]*"];
handler.tags = ["downloader"];
handler.command = ["terabox"];

export default handler


let replyHandler = async (m, { conn }) => {
  if (!conn.fileList || !conn.fileList[m.chat]) return;
  if (!m.quoted.isBaileys) return

  let num = parseInt(m.text.trim());
  if (isNaN(num) || !conn.fileList[m.chat][num]) return;

  let selectedFile = conn.fileList[m.chat][num];

  await conn.sendMessage(m.chat, {
    document: { url: selectedFile.downloadUrl },
    mimetype: await getMimetype(selectedFile.downloadUrl),
    fileName: selectedFile.filename,
  });
};

handler.before = replyHandler;

async function getMimetype(url) {
	const { data } = await axios.get(url, {
		responseType: "arraybuffer"
	})
	const { mime } = await fileTypeFromBuffer(data)
	return mime
}