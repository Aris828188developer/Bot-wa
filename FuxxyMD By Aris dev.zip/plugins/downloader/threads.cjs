const axios = require('axios');

const threads = {
    dl: async (link) => {
        if (!link?.includes('threads.net')) {
            throw new Error('urlnya\n\nexample:\n- https://www.threads.net/...');
        }
        const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms));

        const submit = async (attempt = 1) => {
            try {
                console.log(`Percobaan ke-${attempt} untuk mengambil data...`);
                const { data } = await axios.get('https://threads.snapsave.app/api/action', {
                    params: { url: link },
                    headers: {
                        'accept': 'application/json, text/plain, */*',
                        'referer': 'https://threads.snapsave.app/',
                        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36'
                    },
                    timeout: 10000 // 10 detik timeout
                });

                if (data.status_code !== 0 || !data.items?.length) {
                    throw new Error('gdk bisa di undh');
                }

                return data;
            } catch (error) {
                if (error.response?.status === 500 && attempt < 3) {
                    console.warn(`Server error (500). Percobaan ulang ke-${attempt + 1} dalam 2 detik...`);
                    await delay(2000);
                    return submit(attempt + 1);
                }

                if (attempt >= 3) {
                    throw new Error('gagal 3 percobaan');
                }

                throw error;
            }
        };

        try {
            const data = await submit();

            const type = (type) => ({
                GraphImage: 'Photo',
                GraphVideo: 'Video',
                GraphSidecar: 'Gallery'
            }[type] || type);

            return {
                postInfo: {
                    id: data.postinfo.id,
                    username: data.postinfo.username,
                    avatarUrl: data.postinfo.avatar_url,
                    mediaTitle: data.postinfo.media_title,
                    type: type(data.postinfo.__type)
                },
                media: data.items.map(item => ({
                    type: type(item.__type),
                    id: item.id,
                    url: item.url,
                    width: item.width,
                    height: item.height,
                    ...(item.__type === 'GraphVideo' && {
                        thumbnailUrl: item.display_url,
                        videoUrl: item.video_url,
                        duration: item.video_duration
                    })
                }))
            };
        } catch (error) {
            console.error(`${error.message}`);
            throw new Error(error.message);
        }
    }
};

const handler = async (m, { text, conn }) => {
    if (!text) {
        return conn.sendMessage(m.chat, {
            text: 'amana url yg valdi.',
        }, { quoted: m });
    }
    try {
        const data = await threads.dl(text);
        const { postInfo, media } = data;

        for (const item of media) {
            const caption = `📥 *Informasi Post*\n👤 Username: ${postInfo.username}\n📄 Judul: ${postInfo.mediaTitle || 'Tidak ada judul'}\n📂 Tipe: ${postInfo.type}`;
            
            if (item.type === 'Photo') {
                await conn.sendMessage(m.chat, {
                    image: { url: item.url },
                    caption
                }, { quoted: m });
            } else if (item.type === 'Video') {
                await conn.sendMessage(m.chat, {
                    video: { url: item.videoUrl },
                    caption
                }, { quoted: m });
            }
        }
    } catch (error) {
        return conn.sendMessage(m.chat, {
            text: `${error.message}`,
        }, { quoted: m });
    }
};

handler.command = ['threads'];
handler.tags = ['downloader'];
handler.help = ['threads *[url]*'];
handler.limit = true;

module.exports = handler;