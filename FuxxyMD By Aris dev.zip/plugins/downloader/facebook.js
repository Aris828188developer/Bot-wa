/* fb downloader
Cjs
*/
import fetch from 'node-fetch';

const handler = async (m, { text, conn }) => {
    if (!text) {
        return m.reply('Masukkan url facebooknya');
    }

    try {
        const response = await fetch(`https://api.vreden.web.id/api/fbdl?url=${encodeURIComponent(text)}`);
        const result = await response.json();

        if (!result || !result.data || (!result.data.hd_url && !result.data.sd_url)) {
            return m.reply('Terjadi kesalahan saat mendownload video. Cek URL atau coba lagi nanti.');
        }

        const { hd_url, sd_url, title, durasi } = result.data;
        const videoUrl = sd_url;
        
        await conn.sendFile(m.sender, videoUrl, "", `🎥 *Judul:* ${title}\n⏳ *Durasi:* ${durasi}`, m).then((v) => {
        	if (m.isGroup) {
					conn.sendMessage(m.chat, { text: `Download Selesai 🎟️\nSilahkan cek private chat: @${conn.user.jid.split("@")[0]}`, contextInfo: { mentionedJid: [conn.user.jid] }}, { quoted: v })
				}
			})

    } catch (error) {
        console.error(error);
        m.reply('Terjadi kesalahan.\n' + error?.message);
    }
};

handler.help = ['fb', 'facebook'].map(_ => _ + " *[url]*")
handler.tags = ['downloader'];
handler.command = /^(fb|facebook)$/i;

export default handler;