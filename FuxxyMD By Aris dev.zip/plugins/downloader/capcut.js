/*
   * COZY MD
   * Credit Nzx | wa.me/6282223537406
   * Dilarang share/menjual sc ini tanpa seizin saya
*/

import axios from 'axios';
import cheerio from 'cheerio';

let handler = async (m, { conn, text }) => {
    if (!text) return m.reply('Masukkan URL CapCut\nContoh: .capcut https://www.capcut.com/templates/7445547192938450229');
    
    try {
        m.reply(wait);
        const result = await CapCut(text);
        
        if (!result.url) throw new Error('Video tidak ditemukan');
        
        await conn.sendMessage(m.sender, { 
            video: { url: result.url },
            caption: `*${result.description}*`
        }, {
        	quoted: m
        }).then((v) => {
        	if (m.isGroup) {
				conn.sendMessage(m.chat, { text: `Download Selesai 🎟️\nSilahkan cek private chat: @${conn.user.jid.split("@")[0]}`, contextInfo: { mentionedJid: [conn.user.jid] }}, { quoted: v })
			}
		})

    } catch (error) {
        console.error('Error:', error);
        m.reply('Terjadi kesalahan saat mengunduh template CapCut');
    }
}

handler.help = ['capcut *[url]*'];
handler.tags = ['downloader'];
handler.command = /^(capcut|cc)$/i;
handler.limit = true

export default handler;

async function CapCut(url) {
    if (!url) throw new Error('URL cannot be empty');
    
    const response = await axios.get(url);
    const data = response.data;
    const $ = cheerio.load(data);
    
    return {
        url: $("video").attr("src") || null,
        description: $('meta[name="keywords"]').attr("content") || null
    };
}