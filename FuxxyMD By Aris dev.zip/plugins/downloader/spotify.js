import axios from "axios";

let handler = async(m, { conn, args }) => {
	if (!args[0]) throw "Masukkan Url Nya";
	await m.reply(wait);
	if (!(/(open\.)?spotify\.com/).test(args[0])) throw "Invalid URL!";
	try {
		let { data } = await axios.get(`https://api.imnezzx.biz.id/downloader/spotify?url=${args[0]}`);
		let caption = `   🎶 *${data.result.title}* 🎶\n\n`;
		caption += `Album: ${data.result.album}\n`;
		caption += `Artists: ${data.result.artists.join(", ")}\n`;
		caption += `Duration: ${format(data.result.duration)}`;
		await conn.sendMessage(m.chat, {
			image: {
				url: data.result.thumbnail[0].url
			},
			caption,
		}, {
			quoted: m
		});
		await conn.sendMessage(m.chat, { audio: { url: data.result.url }, mimetype: "audio/mpeg" }, { quoted: m });
	} catch (e) {
		throw `Terjadi Kesalahan\n` + e?.message
	}
}
handler.help = ["spotify"];
handler.command = /^(spo(tify)?)$/i;
handler.tags = ["downloader"];

export default handler;

function format(milliseconds) {
  const seconds = Math.floor((milliseconds / 1000) % 60);
  const minutes = Math.floor((milliseconds / (1000 * 60)));

  return `${minutes}:${seconds}`;
}