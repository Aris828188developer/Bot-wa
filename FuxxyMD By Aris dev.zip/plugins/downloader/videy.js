let handler = async(m, { conn, usedPrefix, command, args }) => {
	if (!args[0]) throw "Mana URL!?";
	let result = await videy(args[0])
	await conn.sendMessage(m.chat, {
		video: {
			url: result
		},
		caption: done
	}, {
		quoted: m
	})
}

handler.help = ["videy *[url]*"]
handler.command = /^videy$/i;
handler.tags = ["downloader"];
handler.vip = true;

export default handler

async function videy(url) {
  try {
    let id = url.split("id=")[1]
    let typ = '.mp4'
    if (id.length === 9 && id[8] === '2') {
      typ = '.mov';
    }
    return `https://cdn.videy.co/${id + typ}`
  } catch (error) {
    console.error(`Error fetching the URL: ${error.message}`);
  }
}