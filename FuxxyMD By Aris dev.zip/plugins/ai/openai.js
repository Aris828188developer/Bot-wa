import axios from 'axios';
import { generateMessageIDV2 } from "baileys-fuxxy"

const handler = async (m, { text, conn, usedPrefix, command }) => {
    if (!text) return m.reply(`Example: ${usedPrefix + command} siapa Presiden Indonesia saat ini`); 
    m.reply(wait)   
    try {
        const response = await getAIResponse(
            'You are a detailed and structured assistant. Provide responses in a clean and well-organized format for scientific and geographical questions.',
            text
        );
        const formattedResponse = formatResponse(response);
        
        if (m.isGroup) {
        await conn.sendMessage(m.chat, {
            text: formattedResponse,
            contextInfo: {
            forwardingScore: 2025,
                  isForwarded: true,
                   forwardedNewsletterMessageInfo: {
                   newsletterJid: global.newsid,
                   serverMessageId: null,
                   newsletterName: "Chat GPT",
                   },
                externalAdReply: {
                    title: "Chat GPT",
                    thumbnailUrl: "https://files.catbox.moe/tfs89s.jpg",
                    sourceUrl: "https://chatgpt.com",
                    mediaType: 1,
                    renderLargerThumbnail: true,
                }
            }
        }, { quoted: m });
        } else {
        	await conn.relayMessage(m.chat, {
        	conversation: formattedResponse
           }, {
           	messageId: generateMessageIDV2(conn.user?.id),
               additionalNodes: [{
               	attrs: { biz_bot: "1" },
                   tag: "bot"
               }]
          })
        }
    } catch (err) {
        m.reply(` Error: ${err.message}`);
    }
};

handler.help = ["chatgpt"];
handler.tags = ["ai"];
handler.register = true
handler.limit = true
handler.command = ["ai", "chatgpt", "openai"]

export default handler;

const getAIResponse = async (prompt, text) => {
    const url = "https://api.yanzgpt.my.id/v1/chat";
    const headers = {
        Authorization: "Bearer yzgpt-sc4tlKsMRdNMecNy",
        'Content-Type': 'application/json'
    };

    const payload = {
        messages: [
            { role: 'system', content: prompt },
            { role: 'user', content: text }
        ],
        model: "yanzgpt-legacy-72b-v3.0"
    };

    const { data } = await axios.post(url, payload, { headers });
    return data?.choices?.[0]?.message?.content?.trim() || 'No response from AI';
};

const formatResponse = (text) => {
    let cleanText = text
        .replace(/!\[.*?\]\(.*?\)/g, '') // Remove image markdown syntax
        .replace(/\[.*?\]\(.*?\)/g, '')  // Remove link markdown syntax
        .replace(/[\*\_]{2}/g, '')      // Remove bold/italic markdown
        .replace(/[\[\]\d+]/g, '')      // Remove numbered references
        .trim();

    cleanText = cleanText.replace(/\n+/g, '\n'); // Collapse multiple newlines into one

    const sections = cleanText.split('\n\n');
    const formatted = sections.map(section => {
        const [title, ...content] = section.split('\n');
        return `*${title.trim()}*\n${content.join('\n').trim()}`;
    });

    return formatted.join('\n\n');
};