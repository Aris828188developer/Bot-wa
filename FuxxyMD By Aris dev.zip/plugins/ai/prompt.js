import axios from 'axios';
import uploadImage from "../../lib/uploadImage.js";

let handler = async (m, { conn, usedPrefix, command }) => {
    let q = m.quoted ? m.quoted : m;
    let mime = (q.msg || q).mimetype || "";

    if (!/^image\/(jpeg|png|gif|webp|bmp|tiff)$/i.test(mime)) {
        return m.reply(`Kirim atau balas gambar dengan caption *${usedPrefix + command}*`);
    }

    await conn.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });

    try {
        let media = await q.download();
        let imageUrl = await uploadImage(media);

        if (!imageUrl) {
            return m.reply("gagal mengunggah gambar.");
        }

        let { data } = await axios.get(`https://api.imnezzx.biz.id/ai/prompt?url=${encodeURIComponent(imageUrl)}&translate=true`);
        let result = data.message || data.result;

        if (typeof result === "object") {
            result = result.message || JSON.stringify(result, null, 2);
        }

        if (typeof result === "object") {
            result = Object.entries(result)
                .map(([key, value]) => `*${key}*: ${value}`)
                .join("\n");
        }

        if (typeof result === "string") {
            result = result.replace(/\\n/g, "\n").replace(/\\/g, "");
        }

        m.reply(`${result}`);
    } catch (error) {
        console.error("error:", error.response?.data || error.message);
        m.reply("terjadi kesalahan.");
    }
};

handler.help = ['prompt'];
handler.tags = ['ai'];
handler.command = /^prompt$/i;

export default handler;