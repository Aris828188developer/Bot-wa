/*
SUMBER CJS
https://whatsapp.com/channel/0029Vb80Q9Q9Bb5wOAXZDQ3i

SUMBER ESM
https://whatsapp.com/channel/0029Vb2qri6JkK72MIrI8F1Z

/*👤: sesuai janji ya sayang
*/
const fetch = require('node-fetch')

const lilychan = async (text) => {
    try {
        const apiUrl = `https://archive-ui.tanakadomp.biz.id/ai/lilychan?text=${encodeURIComponent(text)}`;
        const response = await fetch(apiUrl);
        const result = await response.json();

        if (result.status && result.result) {
            return {
                text: result.result.message,
                image: result.result.image
            };
        }
        return { text: 'Gagal mendapatkan respons AI.', image: null };
    } catch (error) {
        console.error('Error fetching AI LilyChan response:', error);
        return { text: 'Terjadi kesalahan saat memproses permintaan.', image: null };
    }
};

const handler = async (m, { text, conn }) => {
    if (!text) return m.reply('Masukkan teks untuk diproses oleh LilyChan AI.');

    
    const loadingMsg = await m.reply('ʟ ᴏ ᴀ ᴅ ɪ ɴ ɢ. . . .');

    
    const response = await lilychan(text);

    
    await conn.sendMessage(m.chat, { delete: loadingMsg.key });

    if (response.image) {
        await conn.sendFile(m.chat, response.image, 'lilychan.jpg', response.text, m);
    } else {
        m.reply(response.text);
    }
};

handler.command = ['lilychan'];
handler.tags = ['ai'];
handler.help = ['lilychan *[teks]*'];

module.exports = handler;