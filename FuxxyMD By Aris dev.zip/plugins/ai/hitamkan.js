import axios from 'axios'
import FormData from 'form-data'
 
async function Uguu(buffer, filename) {
  const form = new FormData()
  form.append('files[]', buffer, { filename })
 
  const { data } = await axios.post('https://uguu.se/upload.php', form, {
    headers: form.getHeaders(),
  })
 
  if (data.files && data.files[0]) {
    return data.files[0].url
  } else {
    throw new Error('Gagal upload ke uguu.se, cb lagi nanti')
  }
}
 
let handler = async (m, { conn }) => {
  try {
    const q = m.quoted ? m.quoted : m
    const mime = (q.msg || q).mimetype || ''
 
    if (!mime.startsWith('image/')) {
      return m.reply('Silakan kirim atau reply gambar yang ingin dihitamkan.')
    }
 
    await m.reply('wettt')
 
    const media = await q.download()
    const filename = `image_${Date.now()}.jpg`
 
    const imageUrl = await Uguu(media, filename)
 
    const response = await axios.get(`https://zenzxz.dpdns.org/tools/hitamkan?imageUrl=${encodeURIComponent(imageUrl)}`, {
      responseType: 'arraybuffer'
    })
 
    await conn.sendMessage(m.chat, {
      image: Buffer.from(response.data),
      caption: '😹'
    }, { quoted: m })
 
  } catch (err) {
    m.reply(typeof err === 'string' ? err : (err.message || 'terjadi kesalahn saat memproses gmbar'))
  }
}
 
handler.command = ['hitamkan']
handler.tags = ['tools']
handler.help = ['hitamkan']
 
export default handler