import axios from "axios";

let handler = async(m, { conn, usedPrefix, command, text }) => {
	if (!text) throw `Masukkan Pertanyaan\nContoh: \`${usedPrefix+command}\` *[text]*`;
	//await m.reply(wait);
	let { data } = await axios.get(`https://fastrestapis.fasturl.cloud/aillm/copilot?ask=${encodeURIComponent(text)}&style=Jawab%20dengan%20perasaan%20ceria%20dan%20bahagia&sessionId=${m.sender.split("@")[0]}`);
	let { text: teks, images } = data.result;
	if (images.length >= 1) {
		await conn.sendFile(m.chat, images[0], "", teks, m);
	} else {
		await m.reply(teks);
	}
}
handler.help = ["copilot *[text]*"];
handler.command = ["copilot"];
handler.tags = ["ai"];
handler.limit = true;

export default handler;