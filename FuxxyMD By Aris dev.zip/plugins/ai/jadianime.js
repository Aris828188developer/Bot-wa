import uploadImage from '../../lib/uploadImage.js'
import fetch from "node-fetch"

let handler = async (m, { conn, usedPrefix, command }) => {
  var q = m.quoted ? m.quoted : m;
  var mime = (q.msg || q).mimetype || q.mediaType || '';
  
  if (/image/g.test(mime) && !/webp/g.test(mime)) {
    await m.reply(global.wait); 
    try {
      const img = await q.download?.();
      let out = await uploadImage(img);
      
      
      await conn.sendMessage(
        m.chat, 
        { image: { url: `https://indragpt.my.id/command/ai/toanime?url=${out}` }, caption: global.done }, 
        { quoted: m }
      );
    } catch (e) {
      console.log(e);
      m.reply(`[ ! ] Identifikasi Gagal.`);
    }
  } else {
    m.reply(`Kirim gambar dengan caption *${usedPrefix + command}* atau tag gambar yang sudah dikirim`);
  }
};

handler.help = ['jadianime *[reply/send image]*'];
handler.command = ['toanime', 'jadianime'];
handler.tags = ['tools', 'ai'];
handler.premium = true;
handler.limit = 5;

export default handler