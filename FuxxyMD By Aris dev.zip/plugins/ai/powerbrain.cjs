/* 
- Fitur By Maki
- Type Plugins Cjs
- https://whatsapp.com/channel/0029VakSf6V5K3zaOcozHU2J

- Scrape By 
- https://whatsapp.com/channel/0029Vb2mOzL1Hsq0lIEHoR0N/143
*/
const qs = require('qs');
const axios = require('axios');

async function powerbrain(question) {
    const data = qs.stringify({
        'message': question,
        'messageCount': '1'
    });

    const config = {
        method: 'POST',
        url: 'https://powerbrainai.com/chat.php',
        headers: {
            'User-Agent': 'Mozilla/5.0 (Android 10; Mobile; rv:131.0) Gecko/131.0 Firefox/131.0',
            'Content-Type': 'application/x-www-form-urlencoded',
            'accept-language': 'id-ID',
            'referer': 'https://powerbrainai.com/chat.html',
            'origin': 'https://powerbrainai.com',
            'sec-fetch-dest': 'empty',
            'sec-fetch-mode': 'cors',
            'sec-fetch-site': 'same-origin',
            'priority': 'u=0',
            'te': 'trailers'
        },
        data: data
    };

    const api = await axios.request(config);
    return api.data;
}

let handler = async (m, { conn, text }) => {
    if (!text) {
        return conn.reply(m.chat, 'Tolong kirimkan pertanyaan Anda setelah perintah.', m);
    }

    try {
        const response = await powerbrain(text);
        const answer = response.response || "Jawaban tidak ditemukan.";
        conn.reply(m.chat, `${answer}`, m);
    } catch (error) {
        console.error('Error:', error);
        conn.reply(m.chat, 'Terjadi kesalahan saat menghubungi PowerBrain AI.', m);
    }
}

handler.help = ["powerbrain <pertanyaan>"];
handler.tags = ["ai"];
handler.command = ["powerbrain"];

module.exports = handler;