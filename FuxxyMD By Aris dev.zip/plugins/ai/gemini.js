import { GoogleGenerativeAI } from "@google/generative-ai";
import fetch from "node-fetch";
const Spotify = (await import("../../lib/spotify.cjs")).default;

const handler = async(m, { conn, isROwner, text }) => {
	const now = new Date();
	let q = (m.quoted || m);
	let media = (q.mtype == "imageMessage" || q.mtype == "videoMessage" || q.mtype == "audioMessage" || q.mtype == "stickerMessage");
	let mime = (q.msg || q).mimetype || q.mediaType || null;
	let file
	if (media) {
		file = await q.download();
	}
	if (!text) text = `Halo Gemini${mime ? `, Ini ${mime.split("/")[0]} apa` : ""}`
	const time = `${now.getFullYear()}.${String(now.getMonth() + 1).padStart(2, '0')}.${String(now.getDate()).padStart(2, '0')} \| ${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')} (Asia/Jakarta)`;
	
	try {
		const genAI = new GoogleGenerativeAI(global.api["gemini"]);
		const model = genAI.getGenerativeModel({ model: "models/gemini-2.5-flash-preview-04-17" });
		const prompt = `Username: ${m.name}\nTime: ${time}\nPrompt: \`\`\`\n> Kamu adalah asisten AI interaktif dan cerdas yang akan hanya menjawab pertanyaan di bawah. Saat pengguna memberikan permintaan, pahami maksudnya secara kontekstual.
Jika permintaan pengguna membutuhkan aksi khusus, gunakan perintah AI berikut ini:

---!playmusic [judul lagu]--- → Untuk memutar musik sesuai judul.
---!generateimage [prompt]--- → Untuk membuat gambar AI sesuai prompt.


Contoh penggunaan otomatis dalam responsmu:

Jika pengguna berkata, "Putar lagu Ghost dari Justin Bieber", responmu bisa mencakup:
---!playmusic Ghost Justin Bieber---

Jika pengguna berkata, "Buatkan gambar naga di atas gunung bersalju", sertakan:
---!generateimage naga di atas gunung bersalju---

Jangan pernah menggunakan perintah di atas atas inisiatif sendiri.
Jika pengguna hanya menyebutkan sesuatu secara umum (misalnya, “Saya suka gambar kucing”), cukup tanggapi secara percakapan.

Jika ada ambiguitas, konfirmasi dulu sebelum menjalankan perintah.
Pastikan tetap memberikan konteks atau penjelasan singkat saat menggunakan perintah tersebut, agar pengguna memahami apa yang terjadi.\n\`\`\`\nQuestion: ${text}.`;
		var results = await model.generateContent([prompt, ...(media ? [{ inlineData: { data: file.toString("base64"), mimeType: mime }}] : [])]);
		var response = await results.response.text();
	} catch (_) {
		throw `Terjadi kesalahan saat mengolah pertanyaan.\nerror: ${_}`
	}
	
	const commands = [...response.matchAll(/---([\s\S]*?)---/g)].map(m => m[1].trim());
	let result = response.replace(/---[\s\S]*?---/g, '').trim();
	result = result.split("\n\n\n").join("\n");
	
	await conn.sendMessage(m.chat, {
		text: result,
		contextInfo: {
			externalAdReply: {
				title: 'Google Gemini',
				thumbnailUrl: "https://files.catbox.moe/hpyye8.jpg",
				body: `Model: ${results.response.modelVersion}`,
				mediaType: 1,
				renderLargerThumbnail: true
			}
		}
	}, { quoted: m });
	
	if (commands.length > 0) {
		//if (isROwner) await m.reply(commands.join("\n"))
		for (let command of commands.slice(0, 3)) {
			let [cmd, ...teks] = command.split(" ");
			teks = teks.join(" ");
			switch (cmd) {
				case "!playmusic": {
					try {
						let res = await spotipay(teks);
						await conn.sendMessage(m.chat, {
							audio: { url: res.url },
							mimetype: "audio/mpeg",
							contextInfo: {
								externalAdReply: {
									title: `${res.title} - ${res.artists.join(", ")}`,
									thumbnailUrl: res.thumb,
									body: "By Spotify",
									mediaType: 1
								}
							}
						});
					} catch (e) {
						throw `Terjadi Kesalahan saat mendownload audio\nError: ${e}`
					}
				}
				break;
				case "!generateimage": {
					teks = await translate(teks)
					const img = await flux({ prompt: teks[0] });
					await conn.sendMessage(m.chat, { image: { url: img.images[0] }}, { quoted: m });
				}
				break;
			}
		}
	}
	
}

handler.help = ["gemini *[prompt]*"]
handler.command = ["gemini"]
handler.tags = ["ai"]
handler.limit = 2

export default handler;

async function spotipay(teks) {
	const SpotMate = new Spotify();
	const search = await SpotMate.search(teks);
	const res = await SpotMate.info(search[0].link);
	let track = await SpotMate.convert(search[0].link);
	if (track.error) throw "Error While Downloading Audio";
	let artists = []
	let artist = res.artists.forEach((i) => artists.push(i.name)) || null;
	return {
		title: res.name,
		thumb: res.album.images[0].url,
		url: track.url,
		artists: artists.filter(_ => _)
	}
}

async function flux(options) {
    try {
        options = {
            prompt: options?.prompt,
            seed: options?.seed || Math.floor(Math.random() * 2147483647) + 1,
            random_seed: options?.random_seed ?? true,
            width: options?.width ?? 512,
            height: options?.height ?? 512,
            steps: options?.steps ?? 8,
        };
        if (!options.prompt)
            return {
                status: false,
                message: "undefined reading prompt!",
            };
        const session_hash = string(11);
        const joinResponse = await fetch(
            "https://black-forest-labs-flux-1-schnell.hf.space/queue/join", {
                method: "POST",
                headers: {
                    authority: "black-forest-labs-flux-1-schnell.hf.space",
                    "Content-Type": "application/json",
                },
                body: JSON.stringify({
                    data: [
                        options.prompt,
                        options.seed,
                        options.random_seed,
                        options.width,
                        options.height,
                        options.steps,
                    ],
                    event_data: null,
                    fn_index: 2,
                    trigger_id: 5,
                    session_hash: session_hash,
                }),
            },
        );
        if (!joinResponse.ok) throw new Error("Failed to join queue");
        const dataResponse = await fetch(
            `https://black-forest-labs-flux-1-schnell.hf.space/queue/data?session_hash=${session_hash}`, {
                headers: {
                    authority: "black-forest-labs-flux-1-schnell.hf.space",
                },
            },
        );
        if (!dataResponse.ok) throw new Error("Failed to retrieve data");
        const rawData = await dataResponse.text();
        const lines = rawData.split("\n");
        const jsonObjects = [];
        lines.forEach((line) => {
            if (line.startsWith("data: ")) {
                try {
                    const jsonString = line.substring(6).trim();
                    const jsonObject = JSON.parse(jsonString);
                    jsonObjects.push(jsonObject);
                } catch (error) {
                    throw new Error("Failed to parse JSON");
                }
            }
        });
        const result = jsonObjects.find((d) => d.msg === "process_completed") || {};
        if (!result?.success)
            return result;
        const images = result.output.data
            .filter((d) => typeof d === "object")
            .map((d) => d.url);
        return {
                images: images
        };

        function string(length) {
            const characters =
                "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
            let result = "";
            for (let i = 0; i < length; i++) {
                result += characters.charAt(
                    Math.floor(Math.random() * characters.length),
                );
            }
            return result;
        }
    } catch (e) {
        return {
            message: e.message,
        };
    }
}

async function translate(query = "", lang) {
    if (!query.trim()) return "";
    const url = new URL("https://translate.googleapis.com/translate_a/single");
    url.searchParams.append("client", "gtx");
    url.searchParams.append("sl", "auto");
    url.searchParams.append("dt", "t");
    url.searchParams.append("tl", lang);
    url.searchParams.append("q", query);

    try {
        const response = await fetch(url.href);
        const data = await response.json();
        if (data) {
            return [data[0].map((item) => item[0].trim()).join("\n"), data[2]];
        } else {
            return "";
        }
    } catch (err) {
        throw err;
    }
}