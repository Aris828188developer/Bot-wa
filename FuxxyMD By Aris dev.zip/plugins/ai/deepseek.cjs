/*
- fitur ai deepseek 
- Jika ada typo mohon di perbaiki sendiri. 
- bukan original code saya. Saya cuman bantu bikin file plugin nya.

Kiyo•Editz™
CH: https://whatsapp.com/channel/0029ValggF79mrGXnImOmk1F
Bot: https://github.com/KiyoEditz/Elaina-MD
*/

const axios = require('axios');
const moment = require("moment-timezone");

// Inisialisasi waktu dan tanggal
const time = moment.tz('Asia/Jakarta').format('HH:mm:ss');
const date = moment.tz('Asia/Jakarta').format('DD/MM/YYYY');

// Handler utama
let handler = async (m, { conn, text, usedPrefix, command }) => {
    if (!text) {
        return conn.reply(
            m.chat,
            `Masukkan prompt!\n\nContoh: *${usedPrefix + command} Halo*`,
            m
        );
    }

    try {
        let res = await axios.post(
            'https://api.blackbox.ai/api/chat',
            {
                messages: [{ role: 'user', content: text }],
                userSelectedModel: 'deepseek-v3',
                validated: '10f37b34-a166-4efb-bce5-1312d87f2f94'
            },
            {
                headers: { 'Content-Type': 'application/json' }
            }
        );

        conn.reply(m.chat, res.data, m);
    } catch (error) {
        console.error(error);
        conn.reply(m.chat, `Terjadi kesalahan: ${error.response?.data?.message || error.message}`, m);
    }
};

// Metadata handler
handler.command = /^(deepseek(ai)?)$/i; // Regex untuk memanggil handler
handler.help = ["deepseek"].map(_ => _ + " *[prompt]*");
handler.tags = ["ai"];
handler.premium = true
handler.limit = true;

module.exports = handler;