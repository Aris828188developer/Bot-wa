import { felo } from "../../scrape/feloai.js";
import { generateMessageIDV2 } from "baileys-fuxxy"
import { format } from "util";

const code = async(m, { conn, text }) => {
	if (!text) return m.reply("Mau nanya apa??");
	m.isGroup ?
	m.reply(wait):
	await conn.relayMessage(m.chat, {
		conversation: wait
	}, {
		messageId: generateMessageIDV2(conn.user?.id),
		additionalNodes: [{
			attrs: { biz_bot: "1" },
			tag: "bot"
		}]
	});
	conn.feloai = conn.feloai ? conn.feloai : {}
	conn.feloai[m.sender] = conn.feloai[m.sender] ? conn.feloai[m.sender] : []
	if (conn.feloai[m.sender].length == 3) conn.feloai[m.sender].slice(1)
	
	let res
	try {
		const { answer } = await felo.ask(`question: ${text}\nsessions: ${format(conn.feloai[m.sender].reverse())}`);
		res = answer;
	} catch (_) {
		throw _
	}
	let user = m.sender.split("@")[0]
	user = user.slice(0, 9).padEnd(user.length, "×");
	let data = conn.feloai[m.sender]
	function create(quest, ans) {
		data.push({
			question: quest,
			response: ans
		})
	}
	create(text, res)
	
	m.isGroup ?
	m.reply(res):
	await conn.relayMessage(m.chat, {
		conversation: res
	}, {
		messageId: generateMessageIDV2(conn.user?.id),
		additionalNodes: [{
			attrs: { biz_bot: "1" },
			tag: "bot"
		}]
	});
	conn.feloai[m.sender] = data
}
export default {
	code,
	help: ["feloai"],
	tags: ["ai"],
	command: ["feloai"],
	vip: true,
	register: true
}