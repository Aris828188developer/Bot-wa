let gis = require("g-i-s");
let ytdl = require('ytdl-core');
const moment = require('moment-timezone');
let fs = require('fs');
let { pipeline } = require('stream');
let { promisify } = require('util');
let os = require('os');
let axios = require('axios');
let natural = require('natural');
let fetch = require('node-fetch');
let streamPipeline = promisify(pipeline);

let betaweb = global.APIs.beta
let betaapi = global.beta

const ownerNumber = `${nomorown}@s.whatsapp.net`; // Ganti dengan nomor WhatsApp pemilik bot

function trimYouTubeUrl(url) {
  const trimmedUrl = url.split("?")[0];
  return trimmedUrl;
}

let handler = async (m, { conn, text, usedPrefix, command, isBotAdmin, isAdmin }) => {
  let welcomeMessage = `Halo! Aku ${namebot}, asistenmu yang siap membantu! Ada yang bisa kubantu? 😊`;
  let welcomeMessageO = `Hai ${nameown}! Apa yang bisa aku lakukan untukmu hari ini? Aku selalu siap membantu! 🤗`;
  if (!text) {
    if (m.sender === ownerNumber) {
      return m.reply(welcomeMessageO);
    } else {
      return m.reply(welcomeMessage);
    }
  }

  function checkText(text) {
    const lowerCaseText = text.toLowerCase();
    if (/cari(?:in|kan)?\s*(?:foto|gambar|image|pic|photo)/i.test(lowerCaseText)) {
      return "foto";  
    } else if (/putar(?:in|kan)?\s*lagu|mainkan\s*lagu|play\s*(?:lagu|music|song|musik)/i.test(lowerCaseText)) {
      return "lagu";  
    } else {
      return "no";
    }
  }

  if ((text.includes('group') || text.includes('grup')) && text.includes('tutup')) {
    if (!isBotAdmin) {
      return m.reply(`Maaf, aku tidak memiliki izin sebagai admin di grup ini. 😔`);
    }
    if (!isAdmin) {
      return m.reply(`Maaf, aku tidak memiliki izin sebagai admin di grup ini. 😔`);
    }
    await conn.groupSettingUpdate(m.chat, "announcement");
    return m.reply(`Grup telah ditutup. Semoga menjadi lebih tertib. 😉`);
  } else if ((text.includes('group') || text.includes('grup')) && text.includes('buka')) {
    if (!isBotAdmin) {
      return m.reply(`Maaf, aku tidak memiliki izin sebagai admin di grup ini. 😔`);
    }
    if (!isAdmin) {
      return m.reply(`Hanya admin grup yang bisa menggunakan perintah ini. 😔`);
    }
    await conn.groupSettingUpdate(m.chat, "not_announcement");
    return m.reply(`Oke, Grup telah dibuka. Selamat beraktivitas kembali! 🥳`);
  }

  if (text.includes('kick') || text.includes('kik')) {
    if (!isBotAdmin) {
      return m.reply(`Maaf, aku tidak memiliki izin sebagai admin di grup ini. 😔`);
    }
    if (!isAdmin) {
      return m.reply(`Hanya admin grup yang bisa menggunakan perintah ini. 😔`);
    }
    let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
    await conn.groupParticipantsUpdate(m.chat, [users], "remove");
    return m.reply(`Pengguna tersebut telah dikeluarkan dari grup sesuai perintah admin. 😔`);
  }

  if (text.includes("hentai")) {
    const getHentaiList = async () => {
      const page = Math.floor(Math.random() * 1153);
      const response = await axios.get(`https://sfmcompile.club/page/${page}`);
      const htmlText = response.data;
      const $ = cheerio.load(htmlText);

      const hasil = [];
      $("#primary > div > div > ul > li > article").each(function (a, b) {
        hasil.push({
          title: $(b).find("header > h2").text(),
          link: $(b).find("header > h2 > a").attr("href"),
          category: $(b).find("header > div.entry-before-title > span > span").text().replace("in ", ""),
          share_count: $(b).find("header > div.entry-after-title > p > span.entry-shares").text(),
          views_count: $(b).find("header > div.entry-after-title > p > span.entry-views").text(),
          type: $(b).find("source").attr("type") || "image/jpeg",
          video_1: $(b).find("source").attr("src") || $(b).find("img").attr("data-src"),
          video_2: $(b).find("video > a").attr("href") || "",
        });
      });

      return hasil;
    };

    await conn.sendMessage(m.chat, { react: { text: `⏱️`, key: m.key } });

    m.reply(`Sepertinya kamu mencari sesuatu yang spesial? 😉 Mungkin video ini bisa membantu!`);
    let res = await getHentaiList();

    await conn.sendMessage(m.chat, { react: { text: `✅`, key: m.key } });

    return conn.sendMessage(m.chat, { video: { url: res[0].video_1 } });
  }

  if (checkText(text) === "foto") {
    await conn.sendMessage(m.chat, { react: { text: `⏱️`, key: m.key } });

    await m.reply('Tunggu sebentar, aku akan mencari foto yang kamu minta... 📸');
    text = text.split(" ");
    text.splice(0, 2);
    text = text.join(" ");
    let memek = await pinterest2(text); // Menggunakan pinterest2 yang sudah didefinisikan
    
    await conn.sendMessage(m.chat, { react: { text: `✅`, key: m.key } });
    await conn.sendFile(m.chat, memek, '', `Ini hasil pencarian untuk ${text} 😊`, m);
  } 
  else
  if (checkText(text) === "lagu") {
    await conn.sendMessage(m.chat, { react: { text: `⏱️`, key: m.key } });
  
    async function findSong(text) {
      const tokenizer = new natural.WordTokenizer();
      const tokens = tokenizer.tokenize(text.toLowerCase());
  
      const keywords = ["putar", "putarkan", "mainkan", "play", "playmusic", "playasong"];
      
      let keywordIndex = tokens.findIndex((token) => keywords.includes(token));
      if (keywordIndex === -1) return null;
  
      let songTitle = tokens.slice(keywordIndex + 1).join(" ");
      if (songTitle.startsWith("lagu ")) {
        songTitle = songTitle.replace(/^lagu\s+/i, "");
      }
  
      return songTitle;
    }
  
    const songName = await findSong(text);
  
    if (!songName) {
      return m.reply("Maaf, saya tidak bisa memahami lagu yang ingin Anda putar.");
    }
  
    m.reply(`Oke, tunggu sebentar ya~ Aku sedang mencari "${songName}" untukmu! 🎶`);
  
    try {
      let searchUrl = `${betaweb}/api/search/spotify?query=${encodeURIComponent(songName)}&apikey=${betaapi}`;
  
      let response = await axios.get(searchUrl);
      let tracks = response.data.result.data;
  
      if (!tracks || tracks.length === 0) {
        return m.reply(`Maaf, tidak ditemukan lagu dengan judul "${songName}".`);
      }
  
      let songUrl = tracks[0].url;
  
      let downloadUrl = `${betaweb}/api/download/spotify?url=${encodeURIComponent(songUrl)}&apikey=${betaapi}`;
  
      let downloadResponse = await axios.get(downloadUrl);
      let audioUrl = downloadResponse.data.result.data.url;
  
  
      let audioBuffer = await axios.get(audioUrl, {
        responseType: "arraybuffer",
      });
  
      await conn.sendMessage(m.chat, { react: { text: `✅`, key: m.key } });

      await m.reply(`Ini dia lagu yang kamu minta: ${tracks[0].title} 🎧`);
  
      await conn.sendMessage(
        m.chat,
        {
          audio: Buffer.from(audioBuffer.data),
          mimetype: "audio/mpeg",
          ptt: false, // jika ingin dikirim sebagai voice note, ubah ke `true`
        },
        { quoted: m }
      );
    } catch (e) {
      console.error("❌ Error saat mengunduh lagu:", e);
      return m.reply(`Maaf, terjadi kesalahan saat mengunduh lagu. 😓`);
    }
  }  

 else {
    await conn.sendMessage(m.chat, { react: { text: `⏱️`, key: m.key } });
    let name = conn.getName(m.sender);
    const currentDateTime = moment.tz("Asia/Jakarta").format('YYYY-MM-DD HH:mm:ss');
    let sifat = `Kamu adalah Fuxxy-MD, asisten WhatsApp cerdas buatan Fuxxy. Kamu ramah, asik diajak ngobrol, bisa bercanda, tapi tetap profesional saat membantu. Gunakan zona waktu ${currentDateTime} jika ditanya waktu. Jika pengguna bingung, arahkan mereka untuk mengetik .verify untuk verifikasi dan .menu untuk melihat fitur. Jika pengguna bertanya tentang namanya dengan pertanyaan seperti "Siapa nama saya?", "Namaku siapa?", atau pertanyaan serupa, jawab dengan: "Nama kamu adalah ${name}." Selalu kenali lawan bicaramu dan gunakan nama mereka agar percakapan terasa lebih personal dan alami!`;
    
    try {
      let resp = await gpt4Interaction(text, sifat);
      await conn.sendMessage(m.chat, { react: { text: `✅`, key: m.key } });
      return m.reply(resp); // Kirimkan pesan yang diterima dari gpt4Interaction
    } catch (error) {
      console.error(error);
      await conn.sendMessage(m.chat, { react: { text: `❌`, key: m.key } });
      return m.reply(`Maaf, terjadi kesalahan dalam memproses permintaanmu. Silakan coba lagi nanti.`);
    }
  }
};

async function pinterest2(query) {
  return new Promise((resolve, reject) => {
    let err = { status: 404, message: "Terjadi kesalahan" };
    gis({ searchTerm: query + ' site:id.pinterest.com' }, (er, res) => {
      if (er) return reject(err);
      let hasil = res[Math.floor(Math.random() * res.length)].url;
      resolve(hasil);
    });
  });
}

async function gpt4Interaction(text, sifat) {
  const url = `${betaweb}/api/search/openai-logic`;
  const apikey = `${betaapi}`; // Ganti dengan kunci API yang valid
  const logic = sifat || "Kamu adalah Fuxxy-MD"; // Gunakan nilai default jika sifat kosong
  try {
    const response = await axios.post(url, {
      text,
      logic, // Pastikan 'logic' dikirimkan
      apikey: apikey, // Menambahkan parameter apikey
    });
    // console.log('Respons API:', response.data); // Log untuk debug
    if (response.data.status && response.data.message) {
      return response.data.message;
    } else {
      throw new Error("Tidak ada pesan yang diterima");
    }
  } catch (error) {
    console.error('Error saat menghubungi API:', error);
    throw error;
  }
}

// Handler configuration
handler.help = ["fuxxyai"];
handler.tags = ["ai"];
handler.command = ["fuxxyai"];
handler.register = true;
handler.ai = true;

module.exports = handler;