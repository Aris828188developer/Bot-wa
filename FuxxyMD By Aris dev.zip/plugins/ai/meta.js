let handler = async (m, { conn, text }) => {    
    if (!text) return m.reply('Apa yang ingin kamu ajukan?');
    try {
        const apiUrl = `https://restapii.rioooxdzz.web.id/api/metaai?message=${encodeURIComponent(text)}`;
        const response = await fetch(apiUrl);
        const mark = await response.json();

        const ress = mark.result.meta || 'Maaf, saya tidak bisa memahami permintaan Anda.';
        await conn.sendMessage(m.chat, { 
            text: ress, 
            contextInfo: { 
                isForwarded: true, 
                businessMessageForwardInfo: { businessOwnerJid: "13135550002@s.whatsapp.net" }
            } 
        }, { quoted: m });
    } catch (error) {
        console.error("Terjadi kesalahan:", error.message);
    }
}

handler.help = ['aimeta', 'ai'];
handler.tags = ['ai'];
handler.limit = true
handler.register = true
handler.command = /^(aimeta|metaai)$/i;

export default handler;