const axios = require('axios');
const { prepareWAMessageMedia } = require("baileys-fuxxy");

let handler = async (m, { conn, command }) => {
  let query = `${command} jkt48`;
  m.react('🕒'); // Memberikan reaksi saat memproses

  try {
    let results = await pinterest(query);

    if (results.length === 0) {
      return conn.sendMessage(m.chat, { text: "❌ Tidak ditemukan hasil dari pencarian ini." }, { quoted: m });
    }

    let image = pickRandom(results); // Pilih gambar acak dari hasil pencarian

    await conn.sendMessage(m.chat, {
      image: { url: image.images_url },
      caption: `${image.grid_title}`,
    }, { quoted: m });

  } catch (e) {
    console.error(e);
    conn.reply(m.chat, `❌ Terjadi kesalahan, coba lagi nanti.`, m);
  }
};

handler.help = [
  'Alya', 'Anin', 'Anindya', 'Cathy', 'Elin', 'Eline', 'Chelsea', 'Cynthia', 'Danella', 'Daisy', 'Gendis', 'Michie', 
  'Aralie', 'Deline', 'Delynn', 'Delyn', 'Lana', 'Erin', 'Erine', 'Fritzy', 'Lily', 'Trisha', 'Kimi', 'Kimy', 'Nala', 
  'Ribka', 'Reggie', 'Regi', 'Oline', 'Nachia', 'Nayla', 'Levi', 'Kimmy', 'Moreen', 'Feni', 'Gracia', 'Gita', 'Christy', 
  'Zee', 'Olla', 'Freya', 'Eli', 'Jessi', 'Jeci', 'Muthe', 'Fiony', 'Cepio', 'Oniel', 'Flora', 'Lulu', 'Adel', 'Indah', 
  'Kathrina', 'Kathrin', 'Marsha', 'Amanda', 'Lia', 'Callie', 'Ella', 'Indira', 'Lyn', 'Raisha', 'Gracie', 'Greesel', 
  'Virgi', 'Maira', 'Kaela', 'Intan', 'Jemima', 'Eqin', 'Auwia', 'Rilli', 'Gia'
];

handler.tags = ['jkt48'];
handler.command = new RegExp(`^(${handler.help.join('|')})$`, 'i'); // Membuat regex otomatis dari daftar help

module.exports = handler;

function pickRandom(list) {
  return list[Math.floor(Math.random() * list.length)];
}

// Scraper Pinterest
async function pinterest(query) {
  const url = `https://id.pinterest.com/resource/BaseSearchResource/get/?source_url=%2Fsearch%2Fpins%2F%3Fq%3D${encodeURIComponent(query)}%26rs%3Dtyped&data=%7B%22options%22%3A%7B%22query%22%3A%22${encodeURIComponent(query)}%22%2C%22scope%22%3A%22pins%22%7D%2C%22context%22%3A%7B%7D%7D`;

  const headers = {
    'accept': 'application/json, text/javascript, */*; q=0.01',
    'accept-language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
    'priority': 'u=1, i',
    'referer': 'https://id.pinterest.com/',
    'screen-dpr': '1',
    'sec-ch-ua': '"Not(A:Brand";v="99", "Google Chrome";v="133", "Chromium";v="133")',
    'sec-ch-ua-full-version-list': '"Not(A:Brand";v="99.0.0.0", "Google Chrome";v="133.0.6943.142", "Chromium";v="133.0.6943.142")',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-model': '""',
    'sec-ch-ua-platform': '"Windows"',
    'sec-ch-ua-platform-version': '"10.0.0"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-origin',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36',
    'x-app-version': 'c056fb7',
    'x-pinterest-appstate': 'active',
    'x-pinterest-pws-handler': 'www/index.js',
    'x-pinterest-source-url': '/',
    'x-requested-with': 'XMLHttpRequest'
  };

  try {
    const res = await axios.get(url, { headers });

    if (res.data?.resource_response?.data?.results) {
      return res.data.resource_response.data.results.map(item => ({
        pin: `https://www.pinterest.com/pin/${item.id ?? ''}`,
        images_url: item.images?.['736x']?.url ?? '',
        grid_title: item.grid_title ?? 'Tanpa Judul'
      })).filter(img => img.images_url); // Hanya ambil hasil yang memiliki gambar
    }
    return [];
  } catch (error) {
    console.error('Pinterest Scraper Error:', error);
    return [];
  }
}