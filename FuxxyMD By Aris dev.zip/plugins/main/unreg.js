import PhoneNumber from 'awesome-phonenumber'
import {
    createHash
} from 'crypto'
import {
    promises
} from 'fs'
const limit = 50
const money = 50000
let handler = async function(m, {
    text,
    conn,
    command,
    usedPrefix,
    args
}) {
    const pp = await conn.profilePictureUrl(m.sender, "image").catch((_) => "https://i.ibb.co/3Fh9V6p/avatar-contact.png")
    let name = global.db.data.users[m.sender].name
    let sn = createHash('md5').update(m.sender).digest('hex')
    if (!args[0]) return await conn.appendTextMessage(m, `.unreg ${sn}`, m.chatUpdate);
    let nama = conn.getName(m.sender)
    let user = global.db.data.users[m.sender]
    let age = user.age
    let gender = user.gender
    let who = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : m.fromMe ? conn.user.jid : m.sender
    let cap = `

*『INFORMATION』*
  *Name:* ${nama}
° *Age:* ${age} Years
° *Gender:* ${gender}
° *Status:* _unRegistration_
° *Serial Number:* ${text}
`
    if (args[0] !== sn) throw 'Serial Nomor Salah'

    let key = await conn.sendMessage(
        m.chat, {
            image: {
                url: pp,
            },
            caption: "*[ PROCESS UNREGRISTATION.... ]*",
        }, {
            quoted: m
        },
    );
    await conn.delay(5000)
    await conn.sendMessage(
        m.chat, {
            image: {
                url: pp,
            },
            caption: `*[ UNREGRISTATION SUCCESS ]*\n\n` + cap,
            edit: key.key,
            contextInfo: {
                mentionedJid: [m.sender]
            },
        }, {
            quoted: m
        },
    );
    global.db.data.users[m.sender].money -= money
    global.db.data.users[m.sender].limit -= limit
    user.registered = false
    delete user.gender

}
handler.help = ['unreg']
handler.tags = ['main']

handler.command = /^unreg(ister)?$/i
handler.register = true

export default handler