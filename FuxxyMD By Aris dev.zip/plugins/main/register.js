/*
   * COZY MD
   * Credit Nzx | wa.me/6282223537406
   * Dilarang share/menjual sc ini tanpa seizin saya
*/

import moment from "moment-timezone";


async function handler(m, { conn, text, usedPrefix, command }) {
  conn.captcha = conn.captcha || {};
  const user = db.data.users[m.sender];

  if (user.registered) throw "*[ ⚠️ YOU ARE ALREADY REGISTERED! ]*";
  if (!text) throw `*[ ℹ️ Usage Example ]:* ${usedPrefix + command} *[name.age]*`;

  const [name, age] = text.split(".");
  if (!name || isNaN(age)) throw "*[ ⚠️ Please provide a valid name and age (e.g., John.25) ]*";
  if (age < 5) throw "*[ 🚫 Sorry, you are too young to register. ]*";
  if (age > 50) throw "*[ 🚫 Sorry, you exceed the age limit for registration. ]*";

  const registrationID = await Func.makeId(25);

  
    
    user.registered = true;
    user.name = name;
    user.age = age;
    user.regTime = Date.now();
    user.sn = `Cz#${registrationID}`;

    const registrationSuccessMessage = `*[ ✅ REGISTRATION SUCCESSFUL ]*
*• Name:* ${user.name} *(@${m.sender.split("@")[0]})*
*• Age:* ${user.age} years old
*• ID:* Cz#${registrationID}
*• Registration Time:* ${moment.tz(user.regTime, "Asia/Jakarta").format("YYYY-MM-DD HH:mm:ss")}

Thank you for registering with this bot! We assure you that your data will be securely stored in our database.`;

    await conn.sendMessage(
      m.chat,
      { text: registrationSuccessMessage, contextInfo: { mentionedJid: [m.sender] } },
      { quoted: m },
    );

    delete conn.captcha[m.sender];

}


async function captcha(m, { conn }) {
  if (!conn.captcha || !conn.captcha[m.sender]) return;

  const { code, name, age } = conn.captcha[m.sender];
  if (m.text.toLowerCase() === code.toLowerCase()) {
    await conn.appendTextMessage(m, `.daftar ${name}.${age}`, m.chatUpdate);
  }
}


export default {
  help: ["register", "daftar"].map((cmd) => `${cmd} *[name.age]*`),
  tags: ["info"],
  command: ["daftar", "register", "reg"],
  code: handler,
  before: captcha,
};