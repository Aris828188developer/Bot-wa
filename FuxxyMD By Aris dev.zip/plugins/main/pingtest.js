let handler = async(m, { conn, args }) => {
	let waiting = await conn.sendMessage(m.chat, { text: `_Wait..._` }, { quoted: m });
	let time = parseInt(args[0]) * 1000 || 1000
	const start = performance.now();
	let count = 0;
	while (performance.now() - start < time) {
		count++;
	}
	await conn.sendMessage(m.chat, { text: `_${format(count)} Loop in ${(time / 1000).toFixed(1)} sec!_`, edit: waiting.key }, { quoted: m });
}
handler.command = handler.help = ["pingtest"]
handler.tags = ["main"]

export default handler;

function format(num) {
  if (num >= 1_000_000_000) {
    return (num / 1_000_000_000).toFixed(1) + "B";
  } else if (num >= 1_000_000) {
    return (num / 1_000_000).toFixed(1) + "M";
  } else if (num >= 1_000) {
    return (num / 1_000).toFixed(1) + "K";
  } else {
    return num.toString(); 
  }
}