/*
   * COZY MD
   * Credit Nzx | wa.me/6282223537406
   * Dilarang share/menjual sc ini tanpa seizin saya
*/

export default {
  code: async (m) => {
    let who;
    if (m.isGroup) who = m.mentionedJid[0] ? m.mentionedJid[0] : m.sender;
    else who = m.sender;
    
    if (typeof db.data.users[who] == 'undefined') return conn.reply(m.chat, 'Pengguna tidak ditemukan dalam database sistem', m);
    
    let user = global.db.data.users[who];
    let username = user.name;
    let level = user.level > 99999 ? 'M̶a̶x̶ L̶e̶v̶e̶l' : user.level;
    let limit = user.vip ? 'Unlimited' : user.limit
    let status = user.vip ? "👑 *VIP User*" : user.premium ? "⭐ Premium" : "⚪ Free user";
    
    let infoUser = `
┏━━━━━━━━━━━━━━━━━┓
┃   📊 LIMIT 📊   
┣━━━━━━━━━━━━━━━━━┫
┃ 👤 *NAMA* : ${username}
┃ 🎫 *LIMIT* : ${limit}
┃ 🏆 *LEVEL* : ${level}
┃ 🔰 *STATUS* : ${status}
┗━━━━━━━━━━━━━━━━━┛`;
    
    conn.reply(m.chat, infoUser, m, {
        contextInfo: {
            externalAdReply: {
                mediaType: 1,
                title: 'User Dashboard',
                thumbnailUrl: 'https://telegra.ph/file/3f353d8508e2767a07871.jpg',
                renderLargerThumbnail: true,
                sourceUrl: ''
            }
        }
    });
  },
  
  command: /^(limit)$/i,
  help: ['limit *[tag]*'],
  tags: ['info']
}