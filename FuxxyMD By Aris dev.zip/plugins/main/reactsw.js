/**
@credit Tio
@Tixo MD
@Whatsapp Bot
wa.me/6282285357346
**/

export async function before(m, {
    conn
}) {
    if (m.key.remoteJid != 'status@broadcast') return;

    conn.story = conn.story ? conn.story : [];

    const {
        mtype,
        text,
        sender
    } = m;
    const name = m.sender.split('@')[0];
        await conn.sendMessage(m.key.remoteJid, { react: { text: await emoji(), key:  m.key } }, { statusJidList: [m.key.participant, m.sender] });
}

async function emoji() {
    let emo = [
        "😀", "😂", "😍", "🥺", "😎", "😢", "😡", "😱", "👍", "👎",
        "👏", "💪", "🙏", "🎉", "🎂", "🌟", "🌈", "🔥", "🍎", "🍕",
        "🍔", "🍟", "🍣", "🍜", "🎸", "🎧", "🎤", "🎬", "🏆", "⚽",
        "🏀", "🏈", "🏊", "🚴", "🚗", "✈️", "🚀", "🚂", "🏠", "🌍", "😹", "🌌", "👑", "☕", "🧢", "😈", "👻", "❤️", "💝", "😼", "🤔", "🥳", "🍽️", "🐾", "⬛", "🐼", "🧖", "🍥", "👾", "💨", "💍"
    ];
    
    let randomIndex = Math.floor(Math.random() * emo.length);
    return emo[randomIndex];
}