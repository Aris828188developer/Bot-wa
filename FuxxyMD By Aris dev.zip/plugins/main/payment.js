import fetch from 'node-fetch'
import { proto, generateWAMessageFromContent, prepareWAMessageMedia } from 'baileys-fuxxy'

const nomorown = global.nomorown
const dana = global.pdana
const gopay = global.pgopay
const qris = global.pqris
const namebot = global.namebot
const newsid = global.newsid
const newsname = global.newsname

const handler = async (m, { conn }) => {
  conn.sendMessage(m.chat, { react: { text: '💸', key: m.key } })

  const msg = generateWAMessageFromContent(m.chat, {
    viewOnceMessage: {
      message: {
        messageContextInfo: {
          deviceListMetadata: {},
          deviceListMetadataVersion: 2
        },
        interactiveMessage: proto.Message.InteractiveMessage.fromObject({
          contextInfo: {
            mentionedJid: [m.sender],
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
              newsletterJid: newsid,
              newsletterName: newsname,
              serverMessageId: -1
            },
            businessMessageForwardInfo: {
              businessOwnerJid: conn.decodeJid(conn.user.id)
            },
            forwardingScore: 256,
            externalAdReply: {
              title: namebot,
              thumbnailUrl: 'https://telegra.ph/file/e329775252389e84740c6.jpg',
              sourceUrl: '',
              mediaType: 2,
              renderLargerThumbnail: false
            }
          },
          body: proto.Message.InteractiveMessage.Body.fromObject({
            text: `*Hello, @${m.sender.replace(/@.+/g, '')}!*\nSilahkan Pilih Payment Di Bawah!`
          }),
          footer: proto.Message.InteractiveMessage.Footer.fromObject({
            text: `Powered By *${namebot}*`
          }),
          header: proto.Message.InteractiveMessage.Header.fromObject({
            hasMediaAttachment: false
          }),
          carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
            cards: [
              {
                body: proto.Message.InteractiveMessage.Body.fromObject({
                  text: '> Tab button di bawah ini untuk transaksi\n> Powered By GoPay'
                }),
                footer: proto.Message.InteractiveMessage.Footer.fromObject({}),
                header: proto.Message.InteractiveMessage.Header.fromObject({
                  title: '`</> GOPAY </>`\n',
                  hasMediaAttachment: true,
                  ...(await prepareWAMessageMedia(
                    { image: { url: 'https://files.catbox.moe/vz06sq.jpg' } },
                    { upload: conn.waUploadToServer }
                  ))
                }),
                nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                  buttons: [
                    {
                      name: 'cta_copy',
                      buttonParamsJson: JSON.stringify({
                        display_text: 'Copy no gopay',
                        id: '123456789',
                        copy_code: gopay
                      })
                    }
                  ]
                })
              },
              {
                body: proto.Message.InteractiveMessage.Body.fromObject({
                  text: '> Tab button di bawah ini untuk transaksi\n> Powered By Dana'
                }),
                footer: proto.Message.InteractiveMessage.Footer.fromObject({}),
                header: proto.Message.InteractiveMessage.Header.fromObject({
                  title: '`</> DANA </>`\n',
                  hasMediaAttachment: true,
                  ...(await prepareWAMessageMedia(
                    { image: { url: 'https://files.catbox.moe/n3pl02.jpg' } },
                    { upload: conn.waUploadToServer }
                  ))
                }),
                nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                  buttons: [
                    {
                      name: 'cta_copy',
                      buttonParamsJson: JSON.stringify({
                        display_text: 'Copy no dana',
                        id: '123456789',
                        copy_code: dana
                      })
                    }
                  ]
                })
              },
              {
                body: proto.Message.InteractiveMessage.Body.fromObject({
                  text: '> Download Gambar Diatas\n\n> Powered By GoPay Merchant'
                }),
                footer: proto.Message.InteractiveMessage.Footer.fromObject({}),
                header: proto.Message.InteractiveMessage.Header.fromObject({
                  title: '`</> QRIS ALLPAY </>`\n',
                  hasMediaAttachment: true,
                  ...(await prepareWAMessageMedia(
                    { image: { url: qris } },
                    { upload: conn.waUploadToServer }
                  ))
                }),
                nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                  buttons: [
                    {
                      name: 'cta_url',
                      buttonParamsJson: JSON.stringify({
                        display_text: 'Kirim Bukti Transfer!',
                        url: `https://wa.me/${nomorown}`,
                        merchant_url: `https://wa.me/${nomorown}`
                      })
                    }
                  ]
                })
              }
            ]
          })
        })
      }
    }
  }, { userJid: m.chat, quoted: m })

  conn.relayMessage(msg.key.remoteJid, msg.message, { messageId: msg.key.id })
}

handler.help = ['payment']
handler.tags = ['main']
handler.command = ['payment', 'pay']
handler.limit = false

export default handler