import moment from "moment-timezone";
import axios from "axios";
import PhoneNumber from "awesome-phonenumber";
import fetch from "node-fetch";
import os from "os";
import crypto from 'crypto';
let { generateWAMessageFromContent, proto, prepareWAMessageMedia } = (await import('baileys-fuxxy')).default;
let Button = (await import('../../plugins/system/Button.js')).default;

let Styles = (text, style = 1) => {
  const xStr = 'abcdefghijklmnopqrstuvwxyz1234567890'.split('');
  const yStr = {
    1: 'ᴀʙᴄᴅᴇꜰɢʜɪᴊᴋʟᴍɴᴏᴘqʀꜱᴛᴜᴠᴡxʏᴢ1234567890'
  };
  const replacer = xStr.map((v, i) => ({
    original: v,
    convert: yStr[style].split('')[i]
  }));
  return text.toLowerCase().split('').map(v => {
    const find = replacer.find(x => x.original === v);
    return find ? find.convert : v;
  }).join('');
};

let handler = async (m, { conn, usedPrefix, command, args, isOwner }) => {
  const more = String.fromCharCode(8206);
  const readMore = more.repeat(4001);
  const perintah = args[0] || "tags";
  const user = global.db.data.users[m.sender];
  
  const setting = global.db.data.settings[conn.user.jid] || {};
  const setmenu = setting.menu || "image";
  
  let sn = crypto.createHash('md5').update(m.sender).digest('hex')

  let tagCount = {};
  let tagHelpMapping = {};
  
  let fkontak = {
    "key": {
      "participants": "0@s.whatsapp.net",
      "remoteJid": "status@broadcast",
      "fromMe": false,
      "id": "Menu"
    },
    "message": {
      "contactMessage": {
        "vcard": `BEGIN:VCARD\nVERSION:3.0\nN:Sy;Bot;;;\nFN:y\nitem1.TEL;waid=${m.sender.split('@')[0]}:${m.sender.split('@')[0]}\nitem1.X-ABLabel:Ponsel\nEND:VCARD`
      }
    },
    "participant": "0@s.whatsapp.net"
  };
    
  let payment = {"key":{"remoteJid":"0@s.whatsapp.net","fromMe":false},"message":{"requestPaymentMessage":{"currencyCodeIso4217":"USD","amount1000":"99999999999","requestFrom":"0@s.whatsapp.net","noteMessage":{"extendedTextMessage":{"text":`${user.name}-san 🐼`,"contextInfo":{"mentionedJid":[`${m.sender}`]}}},"expiryTimestamp":"0","amount":{"value":"99999999999","offset":1000,"currencyCode":"USD"}}}}

  let userPP = global.db.data.users[m.sender].pp || global.gfx;
  try {
    userPP = await conn.profilePictureUrl(m.sender, 'image');
  } catch (e) {
    userPP = global.gfx;
  }
  
  const generateDashboard = () => `
╭━━━━━┈┈୨♡୧┈┈━━━━━
┊୨୧ Database : Mongodb
┊୨୧ Developer : ${global.author}
┊୨୧ Nama : ${user.name}
┊୨୧ Limit : ${user.limit || ""}
┊୨୧ Status : ${!user.registered ? "Not Registered" : global.owner.map(i => i[0]).includes(m.sender.split("@")[0]) ? "Developer ˎˊ˗" : user.vip ? "VIP User" : user.premium ? "Premium User" : "Free User 𓂸"}
╰━━━━━┈┈୨♡୧┈┈━━━━━

If you find an error or want to upgrade premium plan contact the owner.
${readMore}
`.trimStart();

  
  

  
  Object.keys(global.plugins)
    .filter(plugin => !global.plugins[plugin].disabled)
    .forEach(plugin => {
      const tagsArray = Array.isArray(global.plugins[plugin].tags) ? global.plugins[plugin].tags : [];
      if (tagsArray.length > 0) {
        let helpArray = Array.isArray(global.plugins[plugin].help)
          ? global.plugins[plugin].help
          : [global.plugins[plugin].help];
        helpArray = helpArray.map(v => (global.plugins[plugin].premium ? `${v} 🄿` : v) +
          (global.plugins[plugin].vip ? ` 🅅` : "") +
          (global.plugins[plugin].limit ? ` 🄻` : "")
        );

        tagsArray.forEach(tag => {
          if (tag) {
            if (tagCount[tag]) {
              tagCount[tag]++;
              tagHelpMapping[tag].push(...helpArray);
            } else {
              tagCount[tag] = 1;
              tagHelpMapping[tag] = [...helpArray];
            }
          }
        });
      }
    });

  const sections = [
    {
      title: 'All Menu Bot ( All )', 
      highlight_label: 'Populer Plugins',
      rows: [{
        title: 'All Menu',
        description: `Displays the entire Bot menu ( All )`, 
        id: '.menu all'
      }]
    }, 
    {
      title: 'Populer Menu ( List Menu )', 
      highlight_label: 'Populer Plugins',
      rows: [
        { title: 'Download Feature', description: `Displays menu Download ( List Menu )`, id: '.menu downloader' },
        { title: 'Rpg Feature', description: "Displays menu Rpg ( List Menu )", id: '.menu rpg' },
        { title: 'Ai Feature', description: "Displays menu Ai ( List Menu )", id: '.menu ai' },
        { title: 'Game Feature', description: "Displays menu Game ( List Menu )", id: '.menu game' },
        { title: 'Music Feature', description: "Displays menu Music ( List Menu )", id: '.menu music' }
      ]
    },
    {
      title: 'System Information ( info )', 
      highlight_label: 'Populer Plugins',
      rows: [
        { title: 'Creator Bot', description: `Bot owner info, who created it ( information )`, id: '.owner' },
        { title: 'Donate', description: "Donate to Support Bot ( information )", id: '.donasi' },
        { title: 'Sewa & Premium', description: "Displays Rental and Premium List ( Information )", id: '.sewa' }
      ]
    }
  ];

  let listMessage = {
    title: 'Pilih Menu',
    sections
  };

  let teks = '';

  if (perintah === "tags") {
    const tagslist = Object.keys(tagCount)
      .sort()
      .map(tag => `┊⤿ ִ ׄᥴ⃘ᦱ ${usedPrefix}${command} ${tag}ˎˊ˗`)
      .join("\n");

    teks = `
${generateDashboard()}
╭┈─୨୧ List Menu
┊
${tagslist} 
┊
╰━━━━━━━┈┈୨♡୧┈┈━━━━━━━
˚ · . ﾟ☾ ﾟ｡ ${namebot} ! ♡ˎˊ˗
`;

  } else if (tagCount[perintah]) {
    const helplist = tagHelpMapping[perintah]
      .map(helpItem => `┊⤿ ִ ׄᥴ⃘ᦱ ${usedPrefix}${helpItem} ˎˊ˗`)
      .join("\n");

    teks = `
${generateDashboard()} 
╭┈─୨୧ ${perintah.toUpperCase()}
┊           
${helplist}  
┊
╰━━━━━━━┈┈୨♡୧┈┈━━━━━━━
˚ · . ﾟ☾ ﾟ｡ ${namebot} ! ♡ˎˊ˗
`;

  } else if (perintah === "all") {
    const allTagsAndHelp = Object.keys(tagCount)
      .map(tag => {
        const helplist = tagHelpMapping[tag]
          .map(helpItem => `┊⤿ ִ ׄᥴ⃘ᦱ ${usedPrefix}${helpItem}ˎˊ˗`)
          .join("\n");
        return `╭┈─୨୧ ${tag.toUpperCase()}\n${helplist}\n╰━━━━━━━┈┈୨♡୧┈┈━━━━━━━\n`;
      })
      .join("\n");

    teks = `
${generateDashboard()}
*Features Available:*
${allTagsAndHelp}
Feel free to explore!
`;

  }
const buttonParam = {
  display_text: "Customer Support",
  url: `https://wa.me/${nomorwa}`,
  merchant_url: `https://wa.me/${nomorwa}`
};

const buttonParamsJson = JSON.stringify(buttonParam);
  
  const Message = async () => {
    if (setmenu === "image") {
      return conn.sendMessage(m.chat, {
        text: Styles(teks),
        contextInfo: {
          externalAdReply: {
            title: `Menu Bot`,
            body: `Silakan pilih perintah yang kamu inginkan`,
            thumbnailUrl: global.gfx,
            mediaType: 1,
            renderLargerThumbnail: true
          }
        }
      }, { quoted: fkontak });
    } else if (setmenu === "fullbutton") {
  let msg = generateWAMessageFromContent(m.chat, {
  viewOnceMessage: {
    message: {
      messageContextInfo: {
        deviceListMetadata: {},
        deviceListMetadataVersion: 2
      },
      interactiveMessage: proto.Message.InteractiveMessage.create({
        contextInfo: {
          mentionedJid: [m.sender],
          externalAdReply: {
            title: `Menu Bot`,
            body: `Silakan pilih perintah yang kamu inginkan`,
            thumbnailUrl: global.gfx, 
            mediaType: 1,
            renderLargerThumbnail: true
          }
        },
        body: proto.Message.InteractiveMessage.Body.create({
          text: Styles(teks).trim()
        }),
        footer: proto.Message.InteractiveMessage.Footer.create({
          text: global.newsname
        }),
        header: proto.Message.InteractiveMessage.Header.create({
          title: ``,
          subtitle: global.newsname,
          hasMediaAttachment: true,
          ...(await prepareWAMessageMedia(
            {
              document: { url: 'https://wa.me/' },
              mimetype: 'image/png',
              fileName: m.name,
              jpegThumbnail: await conn.resize(await getBuffer(userPP), 400, 400),
              fileLength: 0
            },
            { upload: conn.waUploadToServer }
          ))
        }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
            buttons: [
  {
    name: "single_select",
    buttonParamsJson: JSON.stringify(listMessage)
  },  
  {
    name: "cta_reminder",
    buttonParamsJson: JSON.stringify({
      display_text: "Aktifkan Reminder",
      id: "reminder_start"
    })
  },
  {
    name: "quick_reply",
    buttonParamsJson: JSON.stringify({
      display_text: "Sewa Bot",
      id: ".sewa"
    })
  },
  {
    name: "cta_copy",
    buttonParamsJson: JSON.stringify({
      display_text: "Salin Serial Number",
      copy_code: `${sn}`,
    })
  },
  {
    name: "cta_call",
    buttonParamsJson: JSON.stringify({
      display_text: "Hubungi Admin",
      phone_number: "+" + nomorwa
    })
  },
  {
    name: "cta_url",
    buttonParamsJson: JSON.stringify(buttonParam)
  },
]
          }),
        })
    }
  }
}, { userJid: m.chat, quoted: fkontak });

 conn.relayMessage(msg.key.remoteJid, msg.message, { messageId: msg.key.id });
} else if (setmenu === "payment") {
    await conn.sendMessage(m.chat, {
  audio: { url: "https://files.catbox.moe/4yt76r.mp3" },
  mimetype: 'audio/mp4',
  ptt: true,
  contextInfo: {
    externalAdReply: {
      title: `Display Menu`,
      body: `Tampilan Menu Hanya dapat dilihat oleh ${m.name} !`,
      mediaType: 1,
      thumbnailUrl: gfx,
      renderLargerThumbnail: true,
      showAdAttribution: true,
      sourceUrl: 'Simple WhatsApp Bot By ' + author
    }
  }
}, { quoted: payment });
  await conn.relayMessage(
    m.chat,
    {
      requestPaymentMessage: {
        currencyCodeIso4217: 'IDR',
        amount1000: 9999999999999,
        requestFrom: m.sender,
        noteMessage: {
          extendedTextMessage: {
            text: Styles(teks),
            contextInfo: {
              mentionedJid: [m.sender],
              externalAdReply: {
                showAdAttribution: true
              }
            }
          }
        }
      }
    },
    { messageId: m.key.id }
  )
} else if (setmenu === "button") {
      let msg = generateWAMessageFromContent(m.chat, {
  viewOnceMessage: {
    message: {
      messageContextInfo: {
        deviceListMetadata: {},
        deviceListMetadataVersion: 2
      },
      interactiveMessage: proto.Message.InteractiveMessage.create({
        contextInfo: {
          mentionedJid: [m.sender],
          externalAdReply: {
            title: `Menu Bot`,
            body: `Silakan pilih perintah yang kamu inginkan`,
            thumbnailUrl: global.gfx, 
            mediaType: 1,
            renderLargerThumbnail: true
          }
        },
        body: proto.Message.InteractiveMessage.Body.create({
          text: Styles(teks).trim()
        }),
        footer: proto.Message.InteractiveMessage.Footer.create({
          text: global.newsname
        }),
        header: proto.Message.InteractiveMessage.Header.create({
          title: ``,
          subtitle: global.newsname,
          hasMediaAttachment: true,
          ...(await prepareWAMessageMedia(
            {
              document: { url: 'https://wa.me/' },
              mimetype: 'image/png',
              fileName: m.name,
              jpegThumbnail: await conn.resize(await getBuffer(userPP), 400, 400),
              fileLength: 0
            },
            { upload: conn.waUploadToServer }
          ))
        }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
            buttons: [           
            {
                name: "single_select",
                buttonParamsJson: JSON.stringify(listMessage)
              },
            {        
                "name": "cta_url",
                "buttonParamsJson": JSON.stringify(buttonParam)
              },            
              ],
          }),
        })
    }
  }
}, { userJid: m.chat, quoted: fkontak });

 conn.relayMessage(msg.key.remoteJid, msg.message, { messageId: msg.key.id });
    } else if (setmenu === "imagepp") {
      let msg = generateWAMessageFromContent(m.chat, {
  viewOnceMessage: {
    message: {
      messageContextInfo: {
        deviceListMetadata: {},
        deviceListMetadataVersion: 2
      },
      interactiveMessage: proto.Message.InteractiveMessage.create({
        contextInfo: {
          mentionedJid: [m.sender],
          externalAdReply: {
            title: `Menu Bot`,
            body: `Silakan pilih perintah yang kamu inginkan`,
            thumbnailUrl: userPP, 
            mediaType: 1,
            renderLargerThumbnail: true
          }
        },
        body: proto.Message.InteractiveMessage.Body.create({
          text: teks.trim()
        }),
        footer: proto.Message.InteractiveMessage.Footer.create({
          text: global.newsname
        }),
        header: proto.Message.InteractiveMessage.Header.create({
          title: ``,
          subtitle: global.newsname,
          hasMediaAttachment: true,
          ...(await prepareWAMessageMedia(
            {
              document: { url: 'https://wa.me/' },
              mimetype: 'image/png',
              fileName: m.name,
              jpegThumbnail: await conn.resize(await getBuffer(mediamsg), 400, 400),
              fileLength: 0
            },
            { upload: conn.waUploadToServer }
          ))
        }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
            buttons: [           
            {        
                "name": "cta_url",
                "buttonParamsJson": JSON.stringify(buttonParam)
              },               
              ],
          }),
        })
    }
  }
}, { userJid: m.chat, quoted: fkontak });

 conn.relayMessage(msg.key.remoteJid, msg.message, { messageId: msg.key.id });
    }
  };

  await Message();
  
};

handler.help = ['menu'];
handler.tags = ['main'];
handler.command = /^(menu|help)$/i;
handler.register = true;

export default handler;

async function getBuffer(url, options) {
  try {
    const res = await axios({ method: "get", url, responseType: 'arraybuffer', ...options });
    return res.data;
  } catch (err) {
    return err;
  }
}