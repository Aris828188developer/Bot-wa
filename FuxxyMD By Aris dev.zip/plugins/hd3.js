import fetch from 'node-fetch'
import { remini } from 'betabotz-tools'
import uploadImage from '../../lib/uploadImage.js'
import uploadFile from '../../lib/uploadFile.js' 

let handler = async (m, { conn, usedPrefix, command, text }) => {
conn.remini = conn.remini ? conn.remini : {};
if (m.chat in conn.remini) {
return m.reply("_Mohon Tunggu Sebentar, Masih Ada Proses Yang Belum Selesai_");
}
let who = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.fromMe ? conn.user.jid : m.sender
let name = await conn.getName(who)
let q = m.quoted ? m.quoted : m
let mime = (q.msg || q).mimetype || ''
if (!mime) throw 'Send Foto Dengan Caption .hd'
m.reply(wait)
let media = await q.download()
let url = await uploadImage(media)
conn["remini"][m.chat] = true;
try {
let hasil = await fetch(`https://widipe.com/remini?url=${url}&resolusi=4`)
let hehw = await hasil.json()
await conn.sendFile(m.chat, hehw.url, '', '_Nih Kak Hasilnya_', m)
} catch (e) {
try {
let hasil = await remini(url)
await conn.sendFile(m.chat, hasil, '', '_Nih Kak Hasilnya_', m)
} catch (e) {
conn.sendFile(m.chat, eror, "anu.mp3", null, m, true, {
		type: "audioMessage",
		ptt: true,
	})
}
}
delete conn.remini[m.chat];
}
handler.command = /^(hd|jernih)$/i
handler.help = ['hd','jernih']
handler.tags = ['ai']
handler.register = false
handler.limit = true

export default handler