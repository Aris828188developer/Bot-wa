const handler = async (m, {
  conn,
  args,
  command,
  isBotAdmin
}) => {
  let q = m.quoted || m || null;
  if (!m.quoted) {
    throw "[❗] Reply to the bot message you want to edit."
  }
  let text = args?.length >= 1 ? args.join(' ') : m.text || q?.text || null;
  if (!text) {
    throw "[❗] Only Message"
  }
  if (m.quoted.sender !== conn.user.jid) throw "Must be a message sent by a bot"
  let editKey = m.quoted?.vM?.key || (m.getQuotedObj()?.key) || (m.quoted?.fakeObj?.key) || m.key;
  let editMessage = {
    text: text,
    edit: editKey
  };
  if (checkTrue(await conn.sendMessage(m.chat, editMessage)) || checkTrue(await conn.sendMessage(m.chat, {
      text: text,
      edit: {
        remoteJid: (editKey?.remoteJid || m.chat),
        fromMe: false,
        id: (editKey?.id || m.quoted?.id || m.key.id),
        participant: (m.quoted?.sender || editKey?.remoteJid || m.key.remoteJid)
      }
    })) || checkTrue(await conn.relayMessage(m.chat, {
      protocolMessage: {
        key: editKey,
        type: 14,
        editedMessage: {
          conversation: text
        }
      }
    }, {
      messageId: (editKey?.id || m.quoted?.id || m.key.id)
    }))) {
    throw "[❗] Error editing the message"
  }
};
handler.help = ["edit *[reply]*"];
handler.tags = ["main", "tools"];
handler.command = ["edit"];
handler.premium = true;
export default handler;

function checkTrue(input) {
  return input === false;
}