//WM COZY BOT
//Selasa [24, 12, 2024] by Ilham

let code = async(m, { conn, command }) => {
	if (!m.quoted?.text) return m.reply("`Reply kode yang mau di hapus komentarnya`\n" + `Ex: .${command} [reply code]`);
	
	const delwm = async(code) => {
		return code.replace(/(['"`])(?:\\.|[^\1])*?\1|\/\*[\s\S]*?\*\/|\/\/.*(?=[\n\r]|$)/g, (match, group1) => {
			if (/^['"`]/.test(match)) {
				return match;
			}
			return '';
		})
	}
	
	const result = await delwm(m.quoted.text)
	await conn.sendMessage(m.chat, { text: result.trim() }, { quoted: m });
}

export default {
	code,
	help: ["delcoment *[code]*"],
	command: ["delcoment", "delkomen"],
	tags: ["tools"],
	owner: true
}