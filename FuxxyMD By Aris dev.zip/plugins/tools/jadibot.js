import { makeWASocket } from "../../lib/simple2.js";
import { Boom } from "@hapi/boom";
import Pino from "pino";
import NodeCache from "node-cache";
import fs from "fs";
let { useMultiFileAuthState, DisconnectReason, makeInMemoryStore, jidNormalizedUser, makeCacheableSignalKeyStore, PHONENUMBER_MCC } = (await import("baileys-fuxxy")).default;

export default {
	code: async(m, { conn, args, usedPrefix, command }) => {
		if (conn.user.jid !== global.conn.user.jid) throw `Fitur ini hanya bisa digunakan di bot utama\nNo bot: ${global.conn.user.jid.split("@")[0]}`
		let phoneNumber = m.sender.split("@")[0];
		let authFile = 'plugins/jadibot/'+phoneNumber
		if (m.sender in global.conns && fs.existsSync(authFile)) throw "Masih Ada Koneksi Di Perangkat."
		if (Object.keys(global.conns).length >= 5) throw `Maaf Jadibot saat ini sudah penuh (${Object.keys(conns).length}/5)`;
		if (m.sender == global.conn.user.jid) throw "Tidak Bisa Jadibot Di Nomor Utama"
		let conns = global.conn
		let isInit = !fs.existsSync(authFile);
		let { state, saveCreds} = await useMultiFileAuthState(authFile);
		let msgRetryCounterCache = new NodeCache();
		
		const config = {
			logger: Pino({ level: "silent" }),
			printQRInTerminal: false,
			auth: {
				creds: state.creds,
				keys: makeCacheableSignalKeyStore(state.keys, Pino({ level: "fatal" }).child({ level: "fatal" }))
			},
			markOnlineOnConnect: true,
			browser: ["MacOS","Safari","15"],
			version: [2, 3000, 1015901307]
		}
		
		conn = makeWASocket(config);
		let ev = conn.ev;
		
		if (!conn.authState.creds.registered) {
			setTimeout(async () => {
				let code = await conn.requestPairingCode(phoneNumber);
				let result = code?.match(/.{1,4}/g)?.join("-") || code
				let msg = await conns.reply(m.sender, '```Masukan code dibawah ini untuk jadi bot sementara\n\n1. Klik titik tiga di pojok kanan atas\n2. Ketuk perangkat tertaut\n3. Ketuk tautkan perangkat\n4. Ketuk tautkan dengan nomor telepon saja\n5. Masukan code di bawah ini\n\nNote: code dapat expired kapan saja!```', m);
				await conns.reply(m.sender, result, msg);
			}, 3000)
		}
		
		async function connectionUpdate(update) {
			const { connection, lastDisconnect } = update;
			if (connection == 'open') {
				await conns.reply(m.sender, '```✅ Tersambung```', m);
                conn.uptime = Date.now();
				await conns.reply(m.sender, '*[ ! ]* Jangan Langsung Log-out Perangkat Jika Ingin Berhenti Jadibot\nKetik `.stopjadibot` Untuk Berhenti Jadibot')
			}
			if (connection == "close") {
				if (conn.newConnect) {
					await global.conn.sendMessage(m.sender, { text: `\`Koneksi Terputus.\`\nKetik \`${usedPrefix+command}\` Untuk Jadibot Ulang` })
				}
				if (!conn.newConnect) {
					conn.newConnect = true;
				}
			}
			if (lastDisconnect && lastDisconnect.error && lastDisconnect.error.output && lastDisconnect.error.output.statusCode !== DisconnectReason.loggedOut) {
				reloadhandler(true);
			}
		}
		if (!isInit) {
			await conns.sendMessage(m.sender, { text: `Mengoneksi Sesi Sebelumnya Mohon Tunggu Sebentar...\nJika Kamu Sudah Menghapus Perangkat Di Perangkat Tertaut Sebelumnya, Harap Jadibot Ulang.` }, { quoter: m })
		}
		
		let Handler = await import('../../handler.js');
		let handler = await import('../../handler.js');
		const reloadhandler = (restatConn) => {
			if (Object.keys(Handler || {}).length) handler = Handler;
			if (restatConn) {
				try { conn.ws.close() } catch { }
				conn = {
					...conn, ...makeWASocket(config)
				}
			}
			
			/*if (!isInit) {
				conn.ev.off('messages.upsert', conn.handler);
				conn.ev.off('group-participants.update', conn.participantsUpdate);
				conn.ev.off('message.update', conn.pollUpdate);
				conn.ev.off('groups.update', conn.groupsUpdate);
				conn.ev.off('connection.update', conn.connectionUpdate);
				conn.ev.off('creds.update', conn.credsUpdate);
			}*/
			
			conn.welcome = conns.welcome;
			conn.bye = conns.bye;
			conn.spromote = conns.spromote;
			conn.sdemote = conns.sdemote;
			conn.handler = handler.handler.bind(conn);
			conn.participantsUpdate = handler.participantsUpdate.bind(conn);
			conn.connectionUpdate = connectionUpdate.bind(conn);
			conn.credsUpdate = saveCreds.bind(conn);
			conn.pollUpdate = handler.pollUpdate.bind(conn);
			conn.groupsUpdate = handler.groupsUpdate.bind(conn);
			
			
			conn.ev.on('messages.upsert', conn.handler);
			conn.ev.on('group-participants.update', conn.participantsUpdate);
			conn.ev.on('connection.update', conn.connectionUpdate);
			conn.ev.on('messages.update', conn.pollUpdate);
			conn.ev.on('groups.update', conn.groupsUpdate);
			conn.ev.on('creds.update', conn.credsUpdate);
			global.conns[m.sender] = conn
			isInit = false;
			return true;
		}
		reloadhandler();
	},
	
	help: ["jadibot"],
	tags: ["tools"],
	command: /^jadibot$/i,
	owner: true
}