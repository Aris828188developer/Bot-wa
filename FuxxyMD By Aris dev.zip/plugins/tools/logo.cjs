/**
@credit Tio
@Tixo MD
@Whatsapp Bot
@Support dengan Donasi ✨
wa.me/6282285357346
**/

/*  

  Base : Scrape ( Kay  )
  Telegram : t.me/kayzuMD
  Type : Plug-in CJS
  Share Code :  GENERATOR IMAGE AI
  Link CH : https://whatsapp.com/channel/0029Vb2OwWCElagtreIoke17

*/


const axios = require('axios');

let handler = async (m, { args, conn }) => {
    if (args.length < 2) return m.reply('Masukkan judul & slogan! Contoh: .logo WhatsApp Bot|Powerful AI');

    const [title, slogan] = args.join(" ").split("|");

    try {
        // Kirim reaksi ⏱️ saat proses dimulai
        await conn.sendMessage(m.chat, {
            react: {
                text: "⏱️",
                key: m.key,
            }
        });

        let payload = {
            ai_icon: [333276, 333279],
            height: 300,
            idea: `A Icon ${title}`,
            industry_index: "N",
            industry_index_id: "",
            pagesize: 4,
            session_id: "",
            slogan: slogan || "",
            title: title,
            whiteEdge: 80,
            width: 400
        };

        let { data } = await axios.post("https://www.sologo.ai/v1/api/logo/logo_generate", payload);

        if (!data || !data.data || !data.data.logoList.length) {
            return m.reply('🚫 Gagal membuat logo.');
        }

        const logoUrls = data.data.logoList.map(logo => logo.logo_thumb);

        let message = `🎨 *Logo Generator*\n\n`;
        message += `📌 *Judul*: ${title}\n`;
        message += `📝 *Slogan*: ${slogan || "-"}\n`;
        message += `📥 *Sedang mengunduh logo...*`;

        // Kirim thumbnail pertama dengan informasi
        await conn.sendMessage(m.chat, { 
            image: { url: logoUrls[0] }, 
            caption: message
        }, { quoted: m });

        // Kirim semua logo hasil generate
        for (let i = 1; i < logoUrls.length; i++) {
            await conn.sendMessage(m.chat, { 
                image: { url: logoUrls[i] }
            }, { quoted: m });
        }

        // Ganti reaksi ke ✅ setelah logo terkirim
        await conn.sendMessage(m.chat, {
            react: {
                text: "✅",
                key: m.key,
            }
        });

    } catch (error) {
        console.error("Error generating logo:", error);
        m.reply('❌ Terjadi kesalahan saat membuat logo.');
    }
};

handler.help = ['logo *[judul]|[slogan]*'];
handler.tags = ['tools'];
handler.limit = true;
handler.command = ["logo", "logogenerator"];

module.exports = handler;