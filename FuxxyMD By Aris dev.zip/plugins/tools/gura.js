const {
  Gura
} = await await import("../../lib/gura.js");
let handler = async (m, {
  conn,
  usedPrefix,
  command
}) => {
  try {
    let _0x2e3432 = m.quoted ? m.quoted : m;
    let _0x506307 = (m.quoted ? m.quoted : m.msg).mimetype || "";
    let _0x530459 = global.db.data.chats[m.chat];
    if (!/video|audio/.test(_0x506307)) {
      throw "Reply Video/Vn Nya";
    }
    conn.reply(m.chat, "```Sedang di proses, Mungkin memerlukan waktu beberapa menit...```", m);
    let aud = await _0x2e3432.download?.();
    if (!aud) {
      throw "Can't download media";
    }
    let dio = await Gura(aud);
    if (!dio.base64) {
      throw "Can't convert media to audio";
    }
    conn.sendFile(m.chat, dio.base64, "audio.mp3", "", m, null, {
      mimetype: "audio/mp4",
      asDocument: _0x530459.useDocument
    });
  } catch (_) {
    throw _
  }
};
handler.help = ["vngura", "gura"];
handler.tags = ["tools"];
handler.command = /^(vngura|gura)$/i;
export default handler;