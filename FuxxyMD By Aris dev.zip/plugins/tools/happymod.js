/*
   * COZY MD
   * Credit Nzx | wa.me/6282223537406
   * Dilarang share/menjual sc ini tanpa seizin saya
*/

import { happymod } from '../../scrape/happymod.js'; 

let handler = async (m, { text }) => {
    if (!text) return m.reply('Masukkan Nama Apk Yang Mau Kamu Cari!');

    try {
        let results = await happymod(text); 
        let message = `Hasil Yang Kamu Cari: *${text}*\n\n`;
        results.forEach((app, i) => {
            message += `${i + 1}. *${app.title}*\n`;
            message += `Rating: ${app.rating}\n`;
            message += `Link: ${app.link}\n\n`;
        });
        m.reply(message);
    } catch (e) {
        m.reply(e.message);
    }
};

handler.help = ['happymod *[query]*'];
handler.tags = ['tools'];
handler.command = /^(happymod)$/i;
handler.limit = true;

export default handler;