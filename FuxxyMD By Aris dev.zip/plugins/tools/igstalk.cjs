/* 
- Fitur By Maki, Ig Stalk
- Type Plugins Cjs
- https://whatsapp.com/channel/0029VakSf6V5K3zaOcozHU2J

- Scraper By Lang's
- https://whatsapp.com/channel/0029VafnytH2kNFsEp5R8Q3n/170
*/
const axios = require('axios');
const cheerio = require('cheerio');

async function igStalk(username) {
    try {
        let { data } = await axios.get(`https://greatfon.io/v/${username}`, {
            headers: {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36",
                "priority": "u=0, i",
                "sec-ch-ua": '"Not(A:Brand";v="99", "Google Chrome";v="133", "Chromium";v="133"',
                "sec-ch-ua-mobile": "?0",
                "sec-ch-ua-platform": '"Windows"',
                "sec-fetch-dest": "document",
                "sec-fetch-mode": "navigate",
                "sec-fetch-site": "none",
                "sec-fetch-user": "?1",
                "upgrade-insecure-requests": 1,
                "authority": "greatfon.io",
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7"
            }
        });

        const $ = cheerio.load(data);
        let name = $('div.items-top h2').text().trim();
        let profileImg = $('figure img').attr('src') || '';
        let bio = $('div.items-top div.text-sm').text().trim();
        let postValue = $('div.stats .stat').eq(0).find('.stat-value').text().trim();
        let followers = $('div.stats .stat').eq(1).find('.stat-value').text().trim();
        let following = $('div.stats .stat').eq(2).find('.stat-value').text().trim();
        let posts = [];

        $('div.items-center:has(.card) .card').each((i, e) => {
            let description = $(e).find('p').html()?.replace(/<br\s*\/?>/g, '\n').trim() || '';
            let image = $(e).find('img').attr('src') || '';

            posts.push({ description, image });
        });

        return { username, profileImg, name, bio, postValue, followers, following, posts };
    } catch (err) {
        console.error(err);
        return null;
    }
}

let handler = async (m, { conn, text, usedPrefix, command }) => {
    if (!text) return m.reply(`Gunakan format: *${usedPrefix + command} username*`);

    let result = await igStalk(text);
    if (!result) return m.reply('Gagal mengambil data. Mungkin akun tidak ditemukan atau terjadi error.');

    let caption = `*Instagram Stalk*\n\n`
        + `*Username:* ${result.username}\n`
        + `*Nama:* ${result.name}\n`
        + `*Bio:* ${result.bio || 'Tidak ada'}\n`
        + `*Post:* ${result.postValue}\n`
        + `*Followers:* ${result.followers}\n`
        + `*Following:* ${result.following}`;

    if (result.profileImg) {
        await conn.sendFile(m.chat, result.profileImg, 'profile.jpg', caption, m);
    } else {
        m.reply(caption);
    }
};

handler.help = ["igstalk"];
handler.tags = ["tools"];
handler.command = ["igstalk"];

module.exports = handler;