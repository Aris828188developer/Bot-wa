let handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!m.quoted)
    throw `*• Example :* ${usedPrefix + command} sticker`;
  let array = Object.keys(db.data.sticker);

  if (array.includes(await m.quoted.fileSha256.toString("base64"))) {
    delete db.data.sticker[m.quoted.fileSha256]
    await m.reply("> Succes");
  } else {
    return m.reply("> _Sticker Tidak Memiliki data_");
  }
};

handler.help = ["delcmd *[sticker]*"]
handler.tags = ["tools"];
handler.command = ["delcmd"];
handler.register = true

export default handler