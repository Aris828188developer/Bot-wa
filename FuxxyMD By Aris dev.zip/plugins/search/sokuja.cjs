const axios = require("axios");
const cheerio = require("cheerio");

let handler = async (m, { conn, text, usedPrefix, command }) => {
  class Sokuja {
    // Fungsi untuk mengambil HTML dari URL
    async fetchHtml(url) {
      try {
        const response = await axios.get(url, {
          headers: {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
          },
        });
        return response.data;
      } catch (error) {
        console.error(`Error fetching URL ${url}:`, error.message);
        throw new Error("Gagal mengambil data dari situs.");
      }
    }

    // Fungsi untuk mencari berdasarkan query
    async search(query) {
      const url = `https://x1.sokuja.uk?s=${encodeURIComponent(query)}`;
      const html = await this.fetchHtml(url);
      const $ = cheerio.load(html);

      const results = [];
      $(".listupd .bs .bsx").each((i, element) => {
        const title = $(element).find("a").attr("title");
        const type = $(element).find(".limit .typez").text();
        const thumbnail = $(element).find(".limit img").attr("src");
        const status = $(element).find(".limit .status").text();
        const link = $(element).find("a").attr("href");

        results.push({
          title,
          type: type || "Unknown",
          thumbnail: thumbnail || "No Image",
          status: status || "Unknown",
          url: link,
        });
      });

      if (results.length === 0) {
        throw new Error("Tidak ada hasil yang ditemukan.");
      }

      return results;
    }

    // Fungsi untuk menampilkan hasil scraping
    async displayResults(m, results) {
      let message = "Hasil Pencarian:\n";
      results.forEach((result, index) => {
        message += `${index + 1}. Title: ${result.title}\n`;
        message += `   Type: ${result.type}\n`;
        message += `   Status: ${result.status}\n`;
        message += `   URL: ${result.url}\n`;
        message += `   Thumbnail: ${result.thumbnail}\n`;
        message += '---------------------------------------\n';
      });
      conn.reply(m.chat, message, m);
    }
  }

  // Inisialisasi dan pencarian berdasarkan query
  const sokuja = new Sokuja();
  if (!text) {
    return conn.reply(m.chat, "Harap masukkan query untuk pencarian.", m);
  }
  try {
    const results = await sokuja.search(text);
    await sokuja.displayResults(m, results);
  } catch (error) {
    conn.reply(m.chat, `Terjadi kesalahan: ${error.message}`, m);
  }
};

handler.help = ["sokuja *[query]*"];
handler.tags = ["search"];
handler.command = ["sokuja", "sokujasearch"];

module.exports = handler;