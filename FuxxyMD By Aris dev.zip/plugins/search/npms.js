/*
   * COZY MD
   * Credit Nzx | wa.me/6282223537406
   * Dilarang share/menjual sc ini tanpa seizin saya
*/

import fetch from 'node-fetch';

export default {
	code: async (m, { text }) => {
		if (!text) return conn.reply(m.chat, '• *Example :* .npmjs api-dylux', m);
		let res = await fetch(`http://registry.npmjs.com/-/v1/search?text=${text}`);
		let { objects } = await res.json();
		if (!objects.length) throw `Query "${text}" not found :/`;
		let txt = objects.map(({ package: pkg }) => {
			return `*${pkg.name}* (v${pkg.version})\n_${pkg.links.npm}_\n_${pkg.description}_`;
		}).join`\n\n`;
		m.reply(txt);
	},
	
	command: /^npm(js|search)?$/i,
	help: ['npmsearch *[text]*'],
	tags: ['tools', 'search']
};