/*
   * COZY MD
   * Credit Nzx | wa.me/6282223537406
   * Dilarang share/menjual sc ini tanpa seizin saya
*/

import { googleImage } from '@bochilteam/scraper'

export default {
	code: async(m, { conn, text, usedPrefix, command }) => {
		if (!text) return m.reply(`Masukkan Query\n\`Contoh ${usedPrefix+command} Waifu\``);
		await m.reply(wait);
		let result = await googleImage(text)
		result = await shuffleArray(result)
		let img = []
		for (let i = 0; i < 5; i++) {
			img.push({
				type: "image",
				data: {
					url: result[i]
				}
			})
		}
		await conn.sendAlbumMessage(m.chat, img, { caption: `Result: ${text.toUpperCase()}`, quoted: m });
	},
	
	help: ["googleimage *[query]*"],
	tags: ["search", "internet"],
	command: ["gimage", "googleimage"],
	limit: 5,
	premium: true
}

async function shuffleArray(array) {
  for (let i = array.length - 1; i > 0; i--) {
    const randomIndex = Math.floor(Math.random() * (i + 1));
    [array[i], array[randomIndex]] = [array[randomIndex], array[i]];
  }
  return array;
}