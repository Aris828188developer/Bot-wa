const axios = require('axios');

let handler = async (m, { conn, args, text, usedPrefix, command }) => {
  const isUrl = (url) => {
    try {
      new URL(url);
      return url.includes('tiktok.com');
    } catch {
      return false;
    }
  };

  let [action, ...query] = text.split(' ');
  query = query.join(' ');
  
  // Jika input adalah URL, langsung jalankan fungsi download
  if (isUrl(action)) {
    query = action;
    action = 'download';
  }
  
  const Tiktok = {
    search: async(q) => {
      const maxRetries = 10;
      let attempt = 0; 
      let response;
      while (attempt < maxRetries) {
        try {
          const data = {
            count: 20,
            cursor: 0,
            web: 1,
            hd: 1,
            keywords: q,
          };
          const config = {
            method: "post",
            url: "https://tikwm.com/api/feed/search",
            headers: {
              "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
              Accept: "application/json, text/javascript, */*; q=0.01",
              "X-Requested-With": "XMLHttpRequest",
              "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Mobile Safari/537.36",
              Referer: "https://tikwm.com/",
            },
            data: data,
          };
          response = await axios(config);
          if (response.data.data) {
            return response.data.data.videos.map((a) => ({
              title: a.title,
              duration: a.duration,
              play: "https://tikwm.com" + a.play,
              stats: {
                play: Number(a.play_count).toLocaleString(),
                like: Number(a.digg_count).toLocaleString(),
                comment: Number(a.comment_count).toLocaleString(),
                share: Number(a.share_count).toLocaleString()
              },
              author: {
                name: a.author.nickname,
                username: "@" + a.author.unique_id
              }
            }));
          } else {
            attempt++;
            await new Promise(resolve => setTimeout(resolve, 2000)); 
          }
        } catch (error) {
          attempt++;
          await new Promise(resolve => setTimeout(resolve, 2000));
        }
      }
      return "Terlalu banyak request, mohon tunggu sebentar...";
    },
    download: async(url) => {
      return new Promise(async (resolve, reject) => {
        try {
          const encodedParams = new URLSearchParams();
          encodedParams.set("url", url);
          encodedParams.set("hd", "1");

          const response = await axios({
            method: "POST",
            url: "https://tikwm.com/api/",
            headers: {
              "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
              Cookie: "current_language=en",
              "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36",
            },
            data: encodedParams,
          });
          resolve(response.data.data);
        } catch (error) {
          reject(error);
        }
      });
    },
    stalk: async function(nickname) {
      return new Promise(async(resolve, reject) => {
        const headers = {
          "Referer": 'https://countik.com/user/@' + nickname,
          "User-Agent": require("fake-useragent")()
        }
        await axios.get(`https://countik.com/api/exist/${nickname.toLowerCase()}`, { headers })
          .then(async(a) => {
            let id = a.data.sec_uid
            if (!id) reject({
              msg: "ID tidak ditemukan!"
            })
            let { data } = await axios.get(`https://countik.com/api/userinfo?sec_user_id=${id}`, { headers }).catch(e => e.response);
            if (!data.followerCount) return reject({
              msg: "Username Tiktok tidak ditemukan!"
            })
            resolve({
              nickname: a.data.nickname,
              avatar: data.avatarThumb,
              country: data.country,
              followers: data.followerCount.toLocaleString(),
              following: data.followingCount.toLocaleString(),
              bio: data.signature,
              heart: data.heartCount.toLocaleString()
            })
          }).catch((e) => reject({ msg: "Gagal mendapatkan data dari Web", error: e.response.data }))
      })
    }
  };

        if (!text) return m.reply('Masukkan kata kunci pencarian!');
        const results = await shuffleArray(await Tiktok.search(query))
        
        if (typeof results === 'string') return m.reply(results);
        let vids = []
        let stats = []
        for (let i = 0; i < Math.min(results.length, 3); i++) {
          vids.push({
          	type: "video",
          	data: { url: results[i].play }
          })
     }
     await conn.sendAlbumMessage(m.chat, vids, { caption: "TIKTOK SEARCH", quoted: m });
};

handler.help = ['tiktoksearch *[query]*'];
handler.tags = ['search'];
handler.command = /^((tiktok|tt)search)$/i;
handler.limit = true;

module.exports = handler;

async function shuffleArray(array) {
  for (let i = array.length - 1; i > 0; i--) {
    const randomIndex = Math.floor(Math.random() * (i + 1));
    [array[i], array[randomIndex]] = [array[randomIndex], array[i]];
  }
  return array;
}