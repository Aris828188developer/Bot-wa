/*
kyzryzz.t.me
Created by 𝘒𝘺𝘻𝘙𝘺𝘻𝘻 𝘟𝘋
https://whatsapp.com/channel/0029VaRI1OB2P59cTdJKZh3q
TITENONO LEK KO HAPUS😂
*/
import yts from "yt-search"
const { proto, generateWAMessageFromContent, prepareWAMessageMedia } = (await import('baileys-fuxxy')).default;
import { format } from 'util';

let handler = async (m, {
    conn,
    usedPrefix,
    command,
    text
}) => {
let input = `[❗] Masukan Salah

Contoh: ${usedPrefix+command} Dj The Spectre`
  if (!text) return m.reply(input);
let anu = (await yts(text)).all
let video = anu.filter(v => v.type === 'video') 
let channel = anu.filter(v => v.type === 'channel') 
let teks = `${channel.map(v => `*${v.name}*
Uʀʟ: ${v.url}
Sᴜʙsᴄʀɪʙᴇʀ: ${v.subCountLabel}
Uʀʟ: ${v.subCount}
${v.videoCount} ᴠɪᴅᴇᴏ\n────────────────`.trim()

).join("\n")}`+`${video.map(v =>  `Jᴜᴅᴜʟ: *${v.title}*
Uʀʟ: ${v.url}
Duʀᴀᴛɪᴏɴ: ${v.timestamp}
Uᴘʟᴏᴀᴅ: ${v.ago}
vɪᴇᴡs: ${v.views}\n─────────────────`.trim() ).join("\n")}`
  let id = m.sender
  let search = await yts(text);
  let vid = search.videos[0];
  let { title, thumbnail, timestamp, views, ago, url } = vid;

let sections = []

video.forEach(async(data) => {
sections.push({
    title: data.title, 
    rows: [{
    header: 'TYPE AUDIO 🔊', 
	title: `${data.title}`,
	description: `${data.timestamp}`, 
	id: `.ytmp3 ${data.url}`
	},
	{
		header: 'TYPE VIDEO 🎥', 
		title: `${data.title}`,
		description: `${data.timestamp}`,
		id: `.ytmp4 ${data.url}`
		}]
	})
})

let listMessage = {
    title: 'Dᴏᴡɴʟᴏᴀᴅ ʜᴇʀᴇ! 🎶', 
    sections
};

let msg = generateWAMessageFromContent(m.chat, {
  viewOnceMessage: {
      message: {
        "messageContextInfo": {
          "deviceListMetadata": {},
          "deviceListMetadataVersion": 2
        },
        interactiveMessage: proto.Message.InteractiveMessage.create({
          body: proto.Message.InteractiveMessage.Body.create({
            text: teks,
          }),
          footer: proto.Message.InteractiveMessage.Footer.create({
            text: wm,
          }),
          header: proto.Message.InteractiveMessage.Header.create({
            title: null,
            hasMediaAttachment: true,
            ...(
              await prepareWAMessageMedia({
                image: { url: thumbnail },
              }, { upload: conn.waUploadToServer })
            )
          }),
          contextInfo: {
            forwardingScore: 2024,
            isForwarded: true,
            mentionedJid: [m.sender],
            forwardedNewsletterMessageInfo: {
              newsletterJid: newsid,
              serverMessageId: null,
              newsletterName: `Powered By ${author}`,
            },
            gifPlayback: true,
            externalAdReply: {
              showAdAttribution: true,
              title: '1:16 ━━●───────── ' + timestamp,
              body: '↻      ◁ II ▷     ↺',
              mediaType: 1,
              sourceUrl: url,
              thumbnailUrl: "https://files.catbox.moe/t993sc.jpg",
              renderLargerThumbnail: true
            }
          },
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
            buttons: [
              {
                "name": "single_select",
                "buttonParamsJson": JSON.stringify(listMessage) 
              }
           ],
          })
        })
    }
  }
}, { quoted: { key: { participant: '0@s.whatsapp.net', remoteJid: "0@s.whatsapp.net" }, message: { conversation: `_${namebot}. Powerfull WhatsApp Bot By ${author}`}}});

await conn.relayMessage(msg.key.remoteJid, msg.message, {
  messageId: msg.key.id
})
}
handler.help = ["yts", "ytsearch"].map(v => v + " *[text]*")
handler.tags = ["internet","search"]
handler.command = /^(ytsearch|yts)$/i
export default handler