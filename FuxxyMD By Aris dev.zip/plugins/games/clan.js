import fs from 'fs';

const dataFile = '../../clans.json';
let clans = {};

if (fs.existsSync(dataFile)) {
  clans = JSON.parse(fs.readFileSync(dataFile, 'utf8'));
} else {
  fs.writeFileSync(dataFile, JSON.stringify(clans, null, 2));
}

export const handler = async (m, { conn, participants, text }) => {
  const command = m.text.split(' ')[0].replace('!', '').trim().toLowerCase();
  const args = m.text.split(' ').slice(1).join(' ').trim();
  const sender = m.sender;
  const senderClan = clans[sender]?.clan;

  switch (command) {
    case 'clancreate': {
      const clanName = args;
      if (!clanName) throw 'Masukkan nama clan!';
      if (clans[clanName]) throw 'Nama clan sudah digunakan!';

      clans[clanName] = {
        owner: sender,
        members: [sender],
        name: clanName
      };
      clans[sender] = { clan: clanName };

      fs.writeFileSync(dataFile, JSON.stringify(clans, null, 2));

      m.reply(`Clan *${clanName}* berhasil dibuat!\nPemimpin: ${conn.getName(sender)}`);
      break;
    }

    case 'clanjoin': {
      const clanName = args;
      if (!clanName) throw 'Masukkan nama clan yang ingin kamu gabung!';
      if (!clans[clanName]) throw 'Clan tidak ditemukan!';

      const clan = clans[clanName];
      if (clan.members.includes(sender)) throw 'Kamu sudah bergabung dalam clan ini!';

      clan.members.push(sender);
      clans[sender] = { clan: clanName };

      fs.writeFileSync(dataFile, JSON.stringify(clans, null, 2));

      m.reply(`Berhasil bergabung dengan clan *${clanName}*`);
      break;
    }

    case 'claninfo': {
      const clanName = args || senderClan;
      if (!clanName) throw 'Masukkan nama clan yang ingin kamu lihat atau bergabung ke dalam clan terlebih dahulu!';
      if (!clans[clanName]) throw 'Clan tidak ditemukan!';

      const clan = clans[clanName];
      const members = clan.members.map(id => conn.getName(id)).join(', ');

      m.reply(`*Nama Clan:* ${clan.name}\n*Pemimpin:* ${conn.getName(clan.owner)}\n*Anggota (${clan.members.length}):* ${members}`);
      break;
    }

    case 'clanwar': {
      if (!senderClan) throw 'Kamu tidak tergabung dalam clan manapun!';

      conn.level = clans[sender]?.level || 0;
      conn.fight = conn.fight || {};
      const delay = (time) => new Promise(res => setTimeout(res, time));
      const thumb = 'https://telegra.ph/file/22384cfe132439a632d9e.jpg';

      if (new Date() - clans[sender].lastmulung < 1800000) {
        throw `Clan kamu sudah kecapekan berperang\n\nTunggu ${msToTime(1800000 - (new Date() - clans[sender].lastmulung))} lagi`;
      }

      const users = participants.map(u => u.id);
      let lawan = users[Math.floor(users.length * Math.random())];

      while (!clans[lawan] || lawan === sender || clans[lawan].clan === senderClan) {
        lawan = users[Math.floor(users.length * Math.random())];
      }

      const opponentClan = clans[lawan].clan;
      const lamaPertarungan = getRandom(1, 1);

      m.reply(`Clan *${senderClan}* sedang dalam pertarungan sengit dengan clan *${opponentClan}*.\n\nTunggu ${lamaPertarungan} menit lagi dan lihat siapa yang menang.`);

      conn.fight[sender] = true;

      await delay(lamaPertarungan * 1 * 60000);

      let kesempatan = [];
      for (let i = 0; i < clans[sender].money; i++) kesempatan.push(sender);
      for (let i = 0; i < clans[lawan].money; i++) kesempatan.push(lawan);

      let pointPemain = 0;
      let pointLawan = 0;
      for (let i = 0; i < 10; i++) {
        const unggul = getRandom(0, kesempatan.length - 1);
        if (kesempatan[unggul] === sender) pointPemain++;
        else pointLawan++;
      }

      if (pointPemain > pointLawan) {
        const hadiah = (pointPemain - pointLawan) * 10000;
        clans[sender].money += hadiah;
        clans[sender].tiketcoin += 1;
        const menang = `*${conn.getName(sender)}* [${pointPemain * 10}] - [${pointLawan * 10}] *${conn.getName(lawan)}*\n\nClan *${senderClan}* menang melawan *${opponentClan}*\n\nHadiah Rp. ${hadiah.toLocaleString()}\n+1 Tiketcoin`;
        conn.sendFile(m.chat, thumb, 'war.jpg', menang, m);
      } else if (pointPemain < pointLawan) {
        const denda = (pointLawan - pointPemain) * 100000;
        clans[sender].money -= denda;
        clans[sender].tiketcoin += 1;
        const kalah = `*${conn.getName(sender)}* [${pointPemain * 10}] - [${pointLawan * 10}] *${conn.getName(lawan)}*\n\nClan *${senderClan}* kalah melawan *${opponentClan}*\n\nUang kamu berkurang Rp. ${denda.toLocaleString()}\n+1 Tiketcoin`;
        conn.sendFile(m.chat, thumb, 'war.jpg', kalah, m);
      } else {
        m.reply(`*${conn.getName(sender)}* [${pointPemain * 10}] - [${pointLawan * 10}] *${conn.getName(lawan)}*\n\nHasil imbang, tidak ada hadiah.`);
      }

      delete conn.fight[sender];
      break;
    }

    case 'clankick': {
      const target = args;
      if (!senderClan) throw 'Kamu tidak berada di clan manapun!';
      if (clans[senderClan].owner !== sender) throw 'Kamu bukan pemimpin clan ini!';

      const memberIndex = clans[senderClan].members.indexOf(target);
      if (memberIndex === -1) throw 'Anggota tidak ditemukan dalam clan!';

      clans[senderClan].members.splice(memberIndex, 1);
      clans[target] = { clan: null };

      fs.writeFileSync(dataFile, JSON.stringify(clans, null, 2));

      m.reply(`Berhasil mengeluarkan anggota ${conn.getName(target)} dari clan ${senderClan}`);
      break;
    }

    case 'clanmembers': {
      if (!senderClan) throw 'Kamu tidak berada di clan manapun!';

      const clan = clans[senderClan];
      const members = clan.members.map(id => conn.getName(id)).join(', ');

      if (!members) throw 'Clan kamu tidak memiliki anggota lainnya!';

      m.reply(`Anggota clan *${senderClan}*:\n${members}`);
      break;
    }

    default:
      throw 'Err!';
  }
};

function getRandom(min, max) {
  min = Math.ceil(min);
  max = Math.floor(max);
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function msToTime(duration) {
  let seconds = Math.floor((duration / 1000) % 60),
      minutes = Math.floor((duration / (1000 * 60)) % 60),
      hours = Math.floor((duration / (1000 * 60 * 60)) % 24);

  hours = (hours < 10) ? "0" + hours : hours;
  minutes = (minutes < 10) ? "0" + minutes : minutes;
  seconds = (seconds < 10) ? "0" + seconds : seconds;

  return hours + " jam " + minutes + " menit " + seconds + " detik";
}

handler.help = ['clancreate', 'clanjoin', 'claninfo', 'clanwar', 'clankick', 'clanmember'];
handler.tags = ['game'];
handler.command = /^(clancreate|clanjoin|claninfo|clanwar|clankick|clanmembers)$/i;

export default handler;