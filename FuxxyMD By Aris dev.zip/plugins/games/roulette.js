/**
This code created by Angga dont delete the wm or u will go hell
#MahiruMD #RAFF #Nzx #prenn
😹😹😹😹😹😹😹😹
**/

import { createCanvas } from 'canvas';
import fs from 'fs';
import path from 'path';
import { exec } from 'child_process';

let handler = async (m, { conn, args, usedPrefix }) => {
    try {
        conn.games = conn.games || {};
        conn.games.roulette = conn.games.roulette || {};
        if (m.chat in conn.games.roulette) return m.reply('Masih ada game roulette yang berlangsung!');

        if (args.length < 3 || m.mentionedJid.length < 1 || m.mentionedJid.length > 3) {
            return conn.reply(m.chat, `Cara main:\n${usedPrefix}roulette <jumlah> <item> @user1 [@user2] [@user3]\n\nContoh:\n${usedPrefix}roulette 1000 diamond/bank @user1 @user2`, m);
        }

        let betAmount = parseInt(args[0]);
        let betItem = args[1].toLowerCase();
        let players = [m.sender, ...m.mentionedJid];

        if (!['diamond', 'bank'].includes(betItem)) return m.reply('Taruhan cuman bisa pake *diamond* atau *bank*.');

        let multiplier = players.length;
        betAmount *= multiplier;

        if (!global.db || !global.db.data || !global.db.data.users) {
            return m.reply('yang lu tantang ga blom terdaftar.');
        }

        for (let player of players) {
            if (!player || typeof player !== 'string') {
                return m.reply('cannot reading player.');
            }

            if (!(player in global.db.data.users)) {
                return m.reply(`@${player.split('@')[0]} belum ada di database!`);
            }

            if (global.db.data.users[player][betItem] < betAmount) {
                return m.reply(`Saldo @${player.split('@')[0]} ga cukup!`);
            }
        }

        let gameMessage = `🎰 *Game Roulette Dimulai!*  
💰 Taruhan: *${betAmount.toLocaleString()} ${betItem}*  
📢 Pemain: ${players.map(p => `@${p.split('@')[0]}`).join(', ')}`;

        if (players.length > 2) {
            let lastPlayer = players[players.length - 1];
            gameMessage += `\n\n📩 @${lastPlayer.split('@')[0]}, ketik *gas* untuk mulai atau *reset* untuk membatalkan.`;
        } else {
            gameMessage += `\n\nKetik *gas* untuk mulai atau *reset* untuk membatalkan game.`;
        }

        conn.games.roulette[m.chat] = {
            players,
            betAmount,
            betItem,
            choices: {},
            accepted: players.length === 2,
            waitingForApproval: players.length >= 2 ? players[players.length - 1] : null,
            timeout: setTimeout(() => {
                delete conn.games.roulette[m.chat];
                conn.reply(m.chat, `⌛ *Timeout!* Game dibatalkan karena ga ada respon.`, m, { mentions: players });
            }, 600000) // 10 menit timeout
        };

        return conn.reply(m.chat, gameMessage, m, { mentions: players });
    } catch (error) {
        console.error('Error in roulette game:', error);
        conn.reply(m.chat, 'Terjadi error saat memproses permainan. Silakan coba lagi.', m);
    }
};

handler.before = async (m, { conn }) => {
    try {
    	if (!conn.games?.roulette) return
        let game = conn.games.roulette[m.chat];
        if (!game) return;

        if (m.text === 'reset') {
            if (!game.players.includes(m.sender)) return;
            clearTimeout(game.timeout);
            delete conn.games.roulette[m.chat];
            return conn.reply(m.chat, `🛑 Game dibatalkan oleh @${m.sender.split("@")[0]}.`, m, { mentions: game.players });
        }

        if (game.waitingForApproval && m.sender === game.waitingForApproval && m.text.toLowerCase() === 'gas') {
            game.accepted = true;
            game.waitingForApproval = null;
            return conn.reply(m.chat, `🎰 *Game Dimulai!*  
Setiap pemain ketik 🔴 *red*, ⚫ *black*, atau 🟡 *odd*!`, m, { mentions: game.players });
        }

        if (!game.accepted || !game.players.includes(m.sender) || game.choices[m.sender]) return;

        let choice = m.text.toLowerCase();
        if (!['red', 'black', 'odd'].includes(choice)) return;

        game.choices[m.sender] = choice;

        if (Object.keys(game.choices).length < game.players.length) {
            return conn.reply(m.chat, `📝 @${m.sender.split("@")[0]} sudah memilih. Tunggu pemain lain!`, m, { mentions: game.players });
        }
       let sticker = await spin();
       if (sticker) {
          await conn.sendMessage(m.chat, { sticker: fs.readFileSync(sticker) });
       }

        let animationFrames = [
            "🎰 Roulette berputar...",
            "🎰 🎲 *Putaran makin cepat!*",
            "🎰 💫 *Bentar lagi berhenti!*",
            "🎰 🎯 *Angka keluar sebentar lagi!*"
        ];

        for (let frame of animationFrames) {
            conn.reply(m.chat, frame, m);
            await conn.delay(2000);
        }

        let randomNumber = Math.floor(Math.random() * 37);
        let resultColor = randomNumber % 2 === 0 ? 'red' : 'black';
        let resultOdd = randomNumber % 2 !== 0 ? 'odd' : null;

        let winners = game.players.filter(p => game.choices[p] === resultColor || game.choices[p] === resultOdd);
        let losers = game.players.filter(p => !winners.includes(p));

        if (game.players.length === 4) {
            if (winners.length > 2) {
                winners = winners.slice(0, 2);
            } else if (winners.length < 2) {
                winners = winners.concat(losers.slice(0, 2 - winners.length));
            }
            losers = game.players.filter(p => !winners.includes(p));
        }

        let resultMsg = `🎰 *Hasil Roulette!*  
🎯 Angka *${randomNumber}* (${winners.length ? game.choices[winners[0]] : 'gada yangmenang'})`;

        if (winners.length) {
            let reward = game.betAmount * winners.length;
            winners.forEach(winner => {
                global.db.data.users[winner][game.betItem] += reward;
            });

            losers.forEach(loser => {
                global.db.data.users[loser][game.betItem] -= game.betAmount;
            });

            resultMsg += `\n🏆 Pemenang: ${winners.map(p => `@${p.split("@")[0]}`).join(", ")}  
💰 Hadiah: +${reward.toLocaleString()} ${game.betItem}`;
        } else {
            resultMsg += `\nGada yang menang 😹`;
        }

        conn.reply(m.chat, resultMsg, m, { mentions: game.players });

        if (game.players.length === 4) {
            conn.games.roulette[m.chat] = {
                players: winners,
                betAmount: game.betAmount,
                betItem: game.betItem,
                choices: {},
                accepted: false,
                timeout: setTimeout(() => {
                    delete conn.games.roulette[m.chat];
                    conn.reply(m.chat, `⌛ *Timeout!* Ronde kedua dibatalkan.`, m, { mentions: winners });
                }, 600000) // 10 menit timeout
            };

            conn.reply(m.chat, `🔥 *Ronde Kedua Dimulai!*  
💥 @${winners[0].split("@")[0]} vs @${winners[1].split("@")[0]}  
Ketik *gas* untuk lanjut!`, m, { mentions: winners });
        }

        delete conn.games.roulette[m.chat];
    } catch (error) {
        console.error('Error in roulette game:', error);
        conn.reply(m.chat, 'Terjadi error saat memproses permainan. Silakan coba lagi.', m);
    }
};

handler.help = ['roulette <jumlah> <item> @user1 @user2 @user3'];
handler.tags = ['game'];
handler.command = /^(roulettepvp|rolpvp)$/i;
handler.register = true;

export default handler;

async function spin() {
    const canvasSize = 600;
    const canvas = createCanvas(canvasSize, canvasSize);
    const ctx = canvas.getContext('2d');

    const outputDir = './tmp';
    if (!fs.existsSync(outputDir)) fs.mkdirSync(outputDir, { recursive: true });

    const frameCount = 20;
    const framePaths = [];
    const totalSlices = 37;
    const numbers = [
        0, 32, 15, 19, 4, 21, 2, 25, 17, 34, 6, 27, 13, 36, 11, 30, 8, 23, 10,
        5, 24, 16, 33, 1, 20, 14, 31, 9, 22, 18, 29, 7, 28, 12, 35, 3, 26,
    ];
    const centerX = canvasSize / 2;
    const centerY = canvasSize / 2;
    const radius = canvasSize / 2 - 20;
    const sliceAngle = (2 * Math.PI) / totalSlices;

    for (let frame = 0; frame < frameCount; frame++) {
        ctx.clearRect(0, 0, canvasSize, canvasSize);

        const progress = frame / frameCount;
        const easeOut = 1 - Math.pow(1 - progress, 4);
        const angle = easeOut * 8 * Math.PI;

        ctx.save();
        ctx.translate(centerX, centerY);
        ctx.rotate(angle);
        ctx.translate(-centerX, -centerY);

        for (let i = 0; i < totalSlices; i++) {
            const startAngle = i * sliceAngle;
            const endAngle = (i + 1) * sliceAngle;

            ctx.beginPath();
            ctx.moveTo(centerX, centerY);
            ctx.arc(centerX, centerY, radius, startAngle, endAngle);
            ctx.closePath();

            ctx.fillStyle = i === 0 ? 'green' : i % 2 === 0 ? 'red' : 'black';
            ctx.fill();
            ctx.stroke();

            const textAngle = (startAngle + endAngle) / 2;
            const textX = centerX + (radius - 35) * Math.cos(textAngle);
            const textY = centerY + (radius - 35) * Math.sin(textAngle);

            ctx.shadowColor = 'rgba(255, 255, 255, 0.8)';
            ctx.shadowBlur = 6;
            ctx.fillStyle = 'white';
            ctx.font = 'bold 22px Arial';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText(numbers[i], textX, textY);
            ctx.shadowBlur = 0;
        }

        ctx.fillStyle = 'rgba(255, 255, 255, 0.2)';
        ctx.beginPath();
        ctx.arc(centerX, centerY, radius, 0, Math.PI * 2);
        ctx.fill();

        const ballAngle = angle * 1.8;
        const ballRadius = radius - 35 + (frame % 2 === 0 ? 2 : -2);
        const ballX = centerX + ballRadius * Math.cos(ballAngle);
        const ballY = centerY + ballRadius * Math.sin(ballAngle);

        ctx.beginPath();
        ctx.arc(ballX, ballY, 10, 0, 2 * Math.PI);
        ctx.fillStyle = 'white';
        ctx.shadowColor = 'rgba(255, 255, 255, 0.6)';
        ctx.shadowBlur = 5;
        ctx.fill();
        ctx.shadowBlur = 0;
        ctx.stroke();

        ctx.restore();

        ctx.save();
        ctx.translate(centerX, 25);
        ctx.beginPath();
        ctx.moveTo(0, 0);
        ctx.lineTo(-12, 25);
        ctx.lineTo(12, 25);
        ctx.closePath();
        ctx.fillStyle = 'gold';
        ctx.fill();
        ctx.restore();

        if (frame > frameCount - 5) {
            ctx.save();
            ctx.translate(centerX, 25);
            ctx.rotate(((Math.random() - 0.5) * Math.PI) / 180);
            ctx.restore();
        }

        const framePath = path.join(outputDir, `frame_${frame}.png`);
        const out = fs.createWriteStream(framePath);
        const stream = canvas.createPNGStream();
        stream.pipe(out);
        await new Promise((resolve) => out.on('finish', resolve));
        framePaths.push(framePath);
    }

    const gifPath = path.join(outputDir, 'roulette.gif');
    await new Promise((resolve, reject) => {
        exec(
            `ffmpeg -framerate 10 -i ${outputDir}/frame_%d.png -loop 0 ${gifPath}`,
            (error) => (error ? reject(error) : resolve())
        );
    });

    const webpPath = path.join(outputDir, 'roulette.webp');
    await new Promise((resolve, reject) => {
        exec(
            `ffmpeg -i ${gifPath} -vcodec libwebp -filter:v fps=10 -loop 0 -q:v 40 ${webpPath}`,
            (error) => (error ? reject(error) : resolve())
        );
    });

    if (fs.existsSync(webpPath)) {
        return webpPath
    } else {
        await console.error('❌ Gagal membuat stiker animasi roulette.')
    }
};