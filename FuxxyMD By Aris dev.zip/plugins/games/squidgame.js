/**
 * Squid Game Fiture
 * Created By Angga
 * Dont delete my wm please
*/

let handler = async (m, { conn, args }) => {
    if (!conn.squidgame) conn.squidgame = {};

    if (m.chat in conn.squidgame) return m.reply('🦑 Lagi ada yang main! Tunggu selesai dulu.');

    conn.squidgame[m.chat] = {
        players: [],
        status: 'waiting',
        round: 0,
        maxRounds: 4,
        responses: {}
    };

    m.reply(`🦑 *Squid Game Dimulai!*
🎮 Minimal 2 pemain, Maksimal 10 pemain 
Ketik *ikut* buat masuk atau *batal* untuk membatalkan game.`);
};

handler.before = async (m, { conn }) => {
    if (!conn.squidgame) return;
    let game = conn.squidgame[m.chat];
    if (!game) return;

    let text = m.text.toLowerCase();

    if (text === 'ikut' && game.status === 'waiting') {
        if (game.players.includes(m.sender)) return m.reply('🦑 Lo udah ikut!');
        if (game.players.length >= 10) return m.reply('🎮 Udah penuh! Maksimal 10 pemain.');

        game.players.push(m.sender);
        conn.reply(m.chat, `✅ @${m.sender.split('@')[0]} masuk game! (${game.players.length}/10)`, m, { mentions: game.players });

        if (game.players.length === 10) {
            setTimeout(() => startGame(m, conn), 5000);
        }
        return;
    }

    if (text === 'start' && game.status === 'waiting') {
        if (game.players.length < 2) return m.reply('⚠️ Minimal 2 pemain untuk memulai game!');
        startGame(m, conn);
    }

    if (text === 'batal' && game.status === 'waiting') {
        delete conn.squidgame[m.chat];
        return m.reply('❌ Game Squid Game telah dibatalkan!');
    }

    if (game.status === 'playing') {
        game.responses[m.sender] = text;
    }
};

async function startGame(m, conn) {
    let game = conn.squidgame[m.chat];
    if (!game) return;

    game.status = 'playing';

    conn.reply(m.chat, `🦑 *Squid Game Dimulai!*\n🔹 Pemain: ${game.players.map(p => `@${p.split('@')[0]}`).join(', ')}\n⚠️ Siap-siap untuk Game Pertama!`, m, { mentions: game.players });

    setTimeout(() => nextRound(m, conn), 5000);
}

async function nextRound(m, conn) {
    let game = conn.squidgame[m.chat];
    if (!game || game.players.length <= 1) return endGame(m, conn);

    game.round++;
    game.responses = {}; // Reset responses setiap ronde

    let games = [redLightGreenLight, dalgonaCandy, tugOfWar, glassBridge];

    if (game.round > games.length) return endGame(m, conn);

    games[game.round - 1](m, conn);
}

async function redLightGreenLight(m, conn) {
    let game = conn.squidgame[m.chat];
    game.responses = {};
    m.reply("🟢 *Green Light!* Ketik 'jalan' dalam 5 detik!");

    setTimeout(() => m.reply("🔴 *Red Light!* Ketik 'stop' dalam 3 detik!"), 5000);

    setTimeout(() => {
        let eliminated = game.players.filter(p => game.responses[p] !== 'stop');
        game.players = game.players.filter(p => !eliminated.includes(p));

        conn.reply(m.chat, eliminated.length ? `💀 Tereliminasi: ${eliminated.map(p => `@${p.split('@')[0]}`).join(', ')}` : "✅ Semua pemain lolos!", m, { mentions: game.players });

        if (game.players.length === 1) return endGame(m, conn);
        setTimeout(() => nextRound(m, conn), 5000);
    }, 8000);
}

async function dalgonaCandy(m, conn) {
    let game = conn.squidgame[m.chat];
    let difficulty = { "lingkaran": 5000, "bintang": 7000, "payung": 10000 };

    game.responses = {};
    let shapes = {};

    for (let p of game.players) {
        let shape = Object.keys(difficulty)[Math.floor(Math.random() * 3)];
        shapes[p] = shape;
        conn.reply(m.chat, `🍪 @${p.split('@')[0]} mendapat bentuk *${shape}*! Ketik "${shape}" dalam ${difficulty[shape] / 1000} detik!`, m, { mentions: [p] });
    }

    await new Promise(resolve => setTimeout(resolve, Math.max(...Object.values(difficulty))));

    let eliminated = game.players.filter(p => game.responses[p] !== shapes[p]);
    game.players = game.players.filter(p => !eliminated.includes(p));

    conn.reply(m.chat, eliminated.length ? `💀 Permen patah! Tereliminasi: ${eliminated.map(p => `@${p.split('@')[0]}`).join(', ')}` : "✅ Semua pemain berhasil!", m, { mentions: game.players });

    if (game.players.length === 1) return endGame(m, conn);
    setTimeout(() => nextRound(m, conn), 5000);
}

async function tugOfWar(m, conn) {
    let game = conn.squidgame[m.chat];
    let teamA = game.players.slice(0, Math.ceil(game.players.length / 2));
    let teamB = game.players.slice(Math.ceil(game.players.length / 2));

    game.responses = {};
    m.reply("🏋️‍♂️ *Tug of War!* Ketik 'tarik' sebanyak-banyaknya dalam 5 detik!");

    setTimeout(() => {
        let scoreA = teamA.reduce((total, p) => total + (game.responses[p] ? game.responses[p].split(' ').length : 0), 0);
        let scoreB = teamB.reduce((total, p) => total + (game.responses[p] ? game.responses[p].split(' ').length : 0), 0);

        let winner = scoreA > scoreB ? teamA : teamB;
        let eliminated = winner === teamA ? teamB : teamA;
        game.players = winner;

        conn.reply(m.chat, `🎖️ Pemenang: ${winner.map(p => `@${p.split('@')[0]}`).join(', ')}\n💀 Tereliminasi: ${eliminated.map(p => `@${p.split('@')[0]}`).join(', ')}`, m, { mentions: game.players });

        if (game.players.length === 1) return endGame(m, conn);
        setTimeout(() => nextRound(m, conn), 5000);
    }, 5000);
}

async function glassBridge(m, conn) {
    let game = conn.squidgame[m.chat];
    game.responses = {};
    m.reply("🏗️ *Glass Bridge!* Pilih 'kiri' atau 'kanan' dalam 5 detik!");

    setTimeout(() => {
        let correctPath = Math.random() < 0.5 ? "kiri" : "kanan";
        let eliminated = game.players.filter(p => game.responses[p] !== correctPath);
        game.players = game.players.filter(p => !eliminated.includes(p));

        conn.reply(m.chat, eliminated.length ? `💀 Salah loncat! Tereliminasi: ${eliminated.map(p => `@${p.split('@')[0]}`).join(', ')}` : "✅ Semua pemain berhasil!", m, { mentions: game.players });

        if (game.players.length === 1) return endGame(m, conn);
        setTimeout(() => endGame(m, conn), 5000);
    }, 5000);
}

async function endGame(m, conn) {
    let game = conn.squidgame[m.chat];
    conn.reply(m.chat, `🎉 *Game Selesai!*\n🏆 Pemenang: @${game.players[0].split('@')[0]}`, m, { mentions: game.players });
    delete conn.squidgame[m.chat];
}
handler.help = ["squidgame"];
handler.tags = ["game"];
handler.command = /^(squidgame)$/i;
handler.group = true;
export default handler;