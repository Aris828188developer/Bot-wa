import { Chess } from "chess.js";
export async function before(m, { conn }) {
  if (db.data.users[m.sender].banned) return;
  if (!(m.quoted && m.quoted?.fromMe && m.quoted?.isBaileys && m.text))
    return !0;
  if (
    ((conn.chessgame = conn.chessgame || {}),
    !conn.chessgame[m.chat] ||
      m.quoted?.id !== conn.chessgame[m.chat].msg.key.id)
  )
    return;
  let txt = m.text.toLowerCase();
  if (!txt) return await conn.reply(m.chat, "Masukkan input from to", m), !0;
  if (/^accept?$/i.test(txt))
    if (conn.chessgame[m.chat].player1 !== m.sender) {
      (conn.chessgame[m.chat].player2 = m.sender),
        (conn.chessgame[m.chat].turn =
          conn.chessgame[m.chat].player2);
      const encodedFen = encodeURI(conn.chessgame[m.chat].fen),
        giliran = `\nGiliran: @${m.sender.split("@")[0]}`,
        boardUrl = `https://www.chess.com/dynboard?fen=${encodedFen}&board=graffiti&piece=graffiti&size=3&coordinates=inside`,
        boardUrl2 = `https://chessboardimage.com/${encodedFen}.png`,
        boardUrl3 = `https://backscattering.de/web-boardimage/board.png?fen=${encodedFen}`;
      let soal;
      try {
        soal = await conn.sendMessage(
          m.chat,
          {
            image: {
              url: boardUrl,
            },
            caption: "🎮 *Chess start* 🎮" + giliran,
            mentions: [m.sender],
          },
          {
            quoted: m,
          },
        );
      } catch (error) {
        try {
          soal = await conn.sendMessage(
            m.chat,
            {
              image: {
                url: boardUrl2,
              },
              caption: "🎮 *Chess start* 🎮" + giliran,
              mentions: [m.sender],
            },
            {
              quoted: m,
            },
          );
        } catch (error) {
          try {
            soal = await conn.sendMessage(
              m.chat,
              {
                image: {
                  url: boardUrl3,
                },
                caption: "🎮 *Chess start* 🎮" + giliran,
                mentions: [m.sender],
              },
              {
                quoted: m,
              },
            );
          } catch (error) {
            return (
              await conn.reply(m.chat, "Gagal mengirim papan catur.", m),
              console.error(error),
              error
            );
          }
        }
      }
      conn.chessgame[m.chat].msg = soal;
    } else await conn.reply(m.chat, "Anda tidak dapat menerima permainan.", m);
  else
    /^cancel?$/i.test(txt) &&
      (delete conn.chessgame[m.chat],
      await conn.reply(m.chat, "Berhasil keluar dari sesi Chess.", m));
  if (
    conn.chessgame[m.chat] &&
    /^\S+(\s|[\W])\S+$/.test(txt) &&
    conn.chessgame[m.chat].turn ===
      conn.chessgame[m.chat].player2
  ) {
    const chess = new Chess(conn.chessgame[m.chat].fen);
    if (chess.isCheckmate())
      return (
        delete conn.chessgame[m.chat],
        void (await conn.reply(
          m.chat,
          `⚠️ *Game Checkmate.*\n🏳️ *Permainan catur dihentikan.*\n*Pemenang:* @${m.sender.split("@")[0]}`,
          m,
          {
            contextInfo: {
              mentionedJid: [m.sender],
            },
          },
        ))
      );
    if (chess.isDraw())
      return (
        delete conn.chessgame[m.chat],
        void (await conn.reply(
          m.chat,
          "⚠️ *Game Draw.*\n🏳️ *Permainan catur dihentikan.",
          m,
        ))
      );
    const [from, to] = txt.split(" ");
    if (m.sender !== conn.chessgame[m.chat].player2)
      await conn.reply(m.chat, "❌ Bukan giliran Anda.", m);
    else
      try {
        chess.move({
          from: from,
          to: to,
          promotion: "q",
        }),
          (conn.chessgame[m.chat].fen = chess.fen()),
          (conn.chessgame[m.chat].turn =
            conn.chessgame[m.chat].player1);
        const encodedFen = encodeURI(chess.fen()),
          giliran = `\nGiliran: @${conn.chessgame[m.chat].turn.split("@")[0]}`,
          flipParam =
            conn.chessgame[m.chat].turn !==
            conn.chessgame[m.chat].player1
              ? ""
              : "&flip=true",
          boardUrl =
            (conn.chessgame[m.chat].turn,
            conn.chessgame[m.chat].player1,
            `https://www.chess.com/dynboard?fen=${encodedFen}&board=graffiti&piece=graffiti&size=3&coordinates=inside${flipParam}`);
        let soal;
        try {
          soal = await conn.sendMessage(
            m.chat,
            {
              image: {
                url: boardUrl,
              },
              caption: "🎮 *Chess start* 🎮" + giliran,
              mentions: [conn.chessgame[m.chat].turn],
            },
            {
              quoted: m,
            },
          );
        } catch (error) {
          try {
            soal = await conn.sendMessage(
              m.chat,
              {
                image: {
                  url: `https://chessboardimage.com/${encodedFen}.png`,
                },
                caption: "🎮 *Chess start* 🎮" + giliran,
                mentions: [conn.chessgame[m.chat].turn],
              },
              {
                quoted: m,
              },
            );
          } catch (error) {
            try {
              soal = await conn.sendMessage(
                m.chat,
                {
                  image: {
                    url: `https://backscattering.de/web-boardimage/board.png?fen=${encodedFen}`,
                  },
                  caption: "🎮 *Chess start* 🎮" + giliran,
                  mentions: [conn.chessgame[m.chat].turn],
                },
                {
                  quoted: m,
                },
              );
            } catch (error) {
              return (
                await conn.reply(m.chat, "Gagal mengirim papan catur.", m),
                console.error(error),
                error
              );
            }
          }
        }
        conn.chessgame[m.chat].msg = soal;
      } catch (e) {
        await conn.reply(m.chat, "❌ *Langkah tidak valid.*", m),
          console.error(e);
      }
  }
  return !0;
}