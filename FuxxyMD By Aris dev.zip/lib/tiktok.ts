import axios from 'axios';
import * as cheerio from 'cheerio';

class SnapTikScraper {
  private baseUrl: string = 'https://snaptik.app';
  private session = axios.create({
    headers: {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
      'Accept-Language': 'en-US,en;q=0.9',
    }
  });

  async extractVideoId(url: string): Promise<string | null> {
    const patterns = [
      /https?:\/\/(?:www\.|vm\.|m\.)?tiktok\.com\/.+\/video\/(\d+)/,
      /https?:\/\/(?:www\.)?tiktok\.com\/@[^/]+\/(?:video\/)?(\d+)/,
      /https?:\/\/m\.tiktok\.com\/v\/(\d+)\.html/,
      /https?:\/\/vt\.tiktok\.com\/(\w+)/,
      /https?:\/\/v\.douyin\.com\/(\w+)/
    ];

    for (const pattern of patterns) {
      const match = url.match(pattern);
      if (match) return match[1];
    }
    return null;
  }

  async getDownloadLinks(tiktokUrl: string): Promise<any> {
    try {
      const response = await this.session.post(`${this.baseUrl}/abc2.php`, {
        url: tiktokUrl,
        lang: 'en2',
        token: 'eyMTc0MjkxMzkxNg==c'
      });

      const $ = cheerio.load(response.data);
      const result: any = {
        status: 'success',
        original_url: tiktokUrl,
        video_id: await this.extractVideoId(tiktokUrl),
        download_links: []
      };

      const videoHeader = $('.video-header');
      if (videoHeader.length) {
        result.title = $('.video-title', videoHeader).text().trim();
        result.author = $('.info span', videoHeader).first().text().trim();
      }

      $('.download-render').each((_, element) => {
        const href = $(element).attr('href');
        if (href) {
          const quality = $(element).text().includes('HD') ? 'hd' : 'standard';
          result.download_links.push({
            quality,
            url: href,
            type: 'video/mp4'
          });
        }
      });

      if (!result.download_links.length) {
        const renderWrapper = $('.render-wrapper');
        if (renderWrapper.length) {
          result.render_token = renderWrapper.attr('data-token') || '';
        }
      }

      return result;

    } catch (error) {
      return {
        status: 'error',
        message: error instanceof Error ? error.message : 'Unknown error',
        original_url: tiktokUrl
      };
    }
  }

  async getHdVideo(token: string): Promise<any> {
    try {
      const response = await this.session.get(`${this.baseUrl}/hd.php?token=${token}`);
      const data = response.data;

      if (data.status === 0 && data.download_url) {
        return {
          status: 'success',
          hd_url: data.download_url
        };
      } else {
        return {
          status: 'error',
          message: data.message || 'HD video not available'
        };
      }
    } catch (error) {
      return {
        status: 'error',
        message: error instanceof Error ? error.message : 'Unknown error'
      };
    }
  }
}

export default SnapTikScraper;