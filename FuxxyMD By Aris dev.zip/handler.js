import { smsg } from './lib/simple.js'
import { format } from 'util'
import { fileURLToPath } from 'url'
import path, { join } from 'path'
import { unwatchFile, watchFile } from 'fs'
import chalk from 'chalk'
import fs from 'fs'
import fetch from 'node-fetch'
import moment from 'moment-timezone'
import database from './database.js'

const { 
proto,
areJidsSameUser,
generateWAMessage,
getAggregateVotesInPollMessage
 } = (await import('baileys-fuxxy')).default
const isNumber = x => typeof x === 'number' && !isNaN(x)
const delay = ms => isNumber(ms) && new Promise(resolve => setTimeout(function () {
    clearTimeout(this)
    resolve()
}, ms))

export async function handler(chatUpdate) {
    if (!chatUpdate)
        return
    this.pushMessage(chatUpdate.messages).catch(console.error)
    let m = chatUpdate.messages[chatUpdate.messages.length - 1]
    
    if (!m)
        return
    if (global.db.data == null)
        await global.loadDatabase()
    try {
        m = smsg(this, m) || m
        if (!m)
            return
        m.exp = 0
        m.limit = false
        try {
            database(this, m);
        } catch (e) {
        	if (/(returnoverlimit|timed|timeout|users|item|time)/ig.test(e.message)) return
            console.error(e)
        }
        global.db.data.users[m.sender].lastonline = new Date()*1;
        const isROwner = global.owner.some(item => item[0] === m.sender.split("@")[0] && item[2] === true);

        const isOwner = isROwner || [conn.decodeJid(global.conn.user.id), ...global.owner.map(([number]) => number)].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)
        const isVip = global.db.data.users[m.sender].vip
        const isMods = global.db.data.users[m.sender].moderator
        const isPrems = isROwner || db.data.users[m.sender].premium == true
        if (isVip) {
        	global.db.data.users[m.sender].limit = Infinity
        }
        if (isMods) {
        	global.db.data.users[m.sender].vip = true
            global.db.data.users[m.sender].vipTime = Infinity
            global.db.data.users[m.sender].premium = true
            global.db.data.users[m.sender].premiumTime = Infinity
        }
        if (opts['nyimak'])
            return
        if (!m.fromMe && (opts['self'] || global.db.data.settings[this.user.jid].self) && !isOwner)
            return
        if (opts['pconly'] && m.chat.endsWith('g.us'))
            return
        if (opts['swonly'] && (m.chat !== 'status@broadcast' && !isOwner))
            return
            
        if (typeof m.text !== 'string')
            m.text = ''
            
        m.exp += Math.ceil(Math.random() * 125)

        let usedPrefix
        let _user = global.db.data && global.db.data.users && global.db.data.users[m.sender]

        const groupMetadata = (m.isGroup ? ((conn.chats[m.chat] || {}).metadata || await this.groupMetadata(m.chat).catch(_ => null)) : {}) || {}
        const participants = (m.isGroup ? groupMetadata.participants : []) || []
        const user = (m.isGroup ? participants.find(u => conn.decodeJid(u.id) === m.sender) : {}) || {} 
        const bot = (m.isGroup ? participants.find(u => conn.decodeJid(u.id) == this.user.jid) : {}) || {} 
        const isRAdmin = user?.admin == 'superadmin' || false
        const isAdmin = isRAdmin || user?.admin == 'admin' || false 
        const isBotAdmin = bot?.admin || false 
        const ___dirname = path.join(path.dirname(fileURLToPath(import.meta.url)), `./plugins/`)
        await this.sendPresenceUpdate("available")
        for (let name in global.plugins) {
        var plugin;
        if (typeof plugins[name].code === "function") {
          var ai = plugins[name];
          plugin = ai.code;
          for (var prop in ai) {
            if (prop !== "run") {
              plugin[prop] = ai[prop];
            }
          }
        } else {
          plugin = plugins[name];
        }
        if (!plugin) continue;
        if (plugin.disabled) continue;
        if (typeof plugin.all === "function") {
          try {
            await plugin.all.call(this, m, chatUpdate);
          } catch (e) {
                    
                    console.error(e)
                    for (let [jid] of global.owner.filter(([number, _, isDeveloper]) => isDeveloper && number)) {
                        let data = (await conn.onWhatsApp(jid))[0] || {}
                        if (data.exists && global.conn.user.jid == this.user.jid)
                            await m.reply(`❲ SYSTEM ERROR ❳

*📚Plugins:* ${name}
*👤Sender:* ${m.sender.split("@")[0]}
*💬Chat:* ${m.chat}
*📮Command:* ${m.text}

\`\`\`${format(e)}\`\`\`

${global.namebot}
`.trim(), null, data.jid)
                    }
                }
            }
            
            if (!opts['restrict'])
                if (plugin.tags && plugin.tags.includes('admin')) {
                    global.dfail('restrict', m, this)
                    continue
                }
            if (m.isBaileys) return;
                
            const str2Regex = str => str.replace(/[|\\{}()[\]^$+*?.]/g, '\\$&')
            let _prefix = plugin.customPrefix ? plugin.customPrefix : conn.prefix ? conn.prefix : global.prefix
            let match = (_prefix instanceof RegExp ? 
                [[_prefix.exec(m.text), _prefix]] :
                Array.isArray(_prefix) ? 
                    _prefix.map(p => {
                        let re = p instanceof RegExp ? 
                            p :
                            new RegExp(str2Regex(p))
                        return [re.exec(m.text), re]
                    }) :
                    typeof _prefix === 'string' ? 
                        [[new RegExp(str2Regex(_prefix)).exec(m.text), new RegExp(str2Regex(_prefix))]] :
                        [[[], new RegExp]]
            ).find(p => p[1])
            
            if (typeof plugin.before === 'function') {
                if (await plugin.before.call(this, m, {
                    match,
                    conn: this,
                    participants,
                    groupMetadata,
                    user,
                    bot,
                    isROwner,
                    isOwner,
                    isRAdmin,
                    isAdmin,
                    isBotAdmin,
                    isPrems,
                    chatUpdate,
                    __dirname: ___dirname,
                    __filename
                }))
                    continue
            }
            if (typeof plugin !== 'function')
                continue
            if ((usedPrefix = (match[0] || '')[0])) {
                let noPrefix = m.text.replace(usedPrefix, '')
                let [command, ...args] = noPrefix.trim().split` `.filter(v => v)
                args = args || []
                let _args = noPrefix.trim().split` `.slice(1)
                let text = _args.join` `
                
                command = (command || '').toLowerCase()
                let fail = plugin.fail || global.dfail
                let isAccept = plugin.command instanceof RegExp ? 
                    plugin.command.test(command) :
                    Array.isArray(plugin.command) ? 
                        plugin.command.some(cmd => cmd instanceof RegExp ? 
                            cmd.test(command) :
                            cmd === command
                        ) :
                        typeof plugin.command === 'string' ? 
                            plugin.command === command :
                            false
                if (!isAccept)
                    continue
                
                if (m.chat in global.db.data.chats || m.sender in global.db.data.users) {
                    let chat = global.db.data.chats[m.chat]
                    let user = global.db.data.users[m.sender]
                    if (chat.isBanned && !isOwner)
                        return 
                    if (name != 'owner/unbanuser.js' && user?.banned && !user?.owner)
                        return
                }
                if (global.db.data.chats[m.chat].shutup && !isAdmin) return;
                if (global.db.data.settings[this.user.jid].allakses) {
                	if (!m.isGroup) {
	                 
	                let update = await this.groupMetadata(idgc);
	                let user = update.participants;
                	let participants = user.map(jid => jid.id)
	                if (!participants.includes(m.sender)) {
	            	return await this.sendMessage(m.chat, {
	        		text: `*Halo* @${m.sender.split("@")[0]} 👋\n_Sebelum menggunakan fitur bot, Kamu harus bergabung ke grup bot terlebih dahulu._\n\n_*Berikut adalah link grupnya:*_\n${sgc}`,
		        	contextInfo: {
		     		mentionedJid: [m.sender],
			     	externalAdReply: {
					showAdAttribution: true,
					title: global.namebot,
					thumbnailUrl: "https://files.catbox.moe/dlq6hg.jpg",
					sourceUrl: sgc,
					sourceId: sgc,
					mediaType: 1,
					renderLargerThumbnail: true
				}
		    	}
	        	}, {
		        	quoted: m
           		});
                }
                }
                }
                if (m.isGroup && db.data.chats[m.chat].adminonly && (!isAdmin && !isOwner)) {
                	global.dfail("adminonly", m, this)
                    continue
                }

                if (!m.isGroup && opts['gconly'] && !m.chat.endsWith('g.us') && !isROwner) {
                global.dfail('groups', m, this)
                continue 
                }
                if (m.isGroup && !db.data.chats[m.chat].games && plugin.tags && plugin.tags.includes("game") && (!isOwner && !isAdmin)) {
                fail('game', m, this)
                continue
                }
                if (m.isGroup && !db.data.chats[m.chat].rpg && plugin.tags && plugin.tags.includes("rpg") && (!isOwner && !isAdmin)) {
                fail('rpg', m, this)
                continue
                }
                if (plugin.rowner && !isROwner) { 
                    fail('rowner', m, this)
                    continue
                }
                if (plugin.owner && !isOwner) { 
                    fail('owner', m, this)
                    continue
                }
                if (plugin.mods && (!isMods && !isOwner)) { 
                    fail('mods', m, this)
                    continue
                }
                if (plugin.vip && (!isVip && !isOwner)) { 
                    fail('vip', m, this)
                    continue
                }
                if (plugin.premium && (!isPrems && !isOwner && !isVip)) { 
                    fail('premium', m, this)
                    continue
                }
                if (plugin.group && (!m.isGroup && !isOwner)) { 
                    fail('group', m, this)
                    continue
                } else if (plugin.botAdmin && !isBotAdmin) { 
                    fail('botAdmin', m, this)
                    continue
                } else if (plugin.admin && (!isAdmin && !isOwner)) { 
                    fail('admin', m, this)
                    continue
                }
                if (plugin.private && (!m.isGroup && !isOwner)) { 
                    fail('private', m, this)
                    continue
                }
                if (plugin.register && (!_user.registered && !isOwner)) { 
                    fail('unreg', m, this)
                    continue
                }
                if (!isROwner && global.db.data.settings[conn.user.jid].rownerOnly) return;
                m.isCommand = true
                m.plugin = (name  && m.isCommand) ? name : null
                let xp = 'exp' in plugin ? parseInt(plugin.exp) : 156
                if (xp > 20000000000)
                    m.reply('Ngecit -_-') 
                else
                    m.exp += xp
                    let limit = plugin.limit * 1
                    m.limit = limit
                if (plugin.limit && global.db.data.users[m.sender].limit < limit && !isOwner) {
                    this.reply(m.chat, `${limit} Limit Required To Use This Feature\n*Your Limit:* ${global.db.data.users[m.sender].limit}\n\`You Can Buy a Limit or Premium From The Owner\``, m)
                    continue 
                }
                if (plugin.level > _user.level) {
                    this.reply(m.chat, `${plugin.level} Level Required To Use This Command\n*Your Level:* ${_user.level}`, m)
                    continue 
                }
                let extra = {
                    match,
                    usedPrefix,
                    noPrefix,
                    _args,
                    args,
                    command,
                    text,
                    conn: this,
                    participants,
                    groupMetadata,
                    user,
                    bot,
                    isROwner,
                    isOwner,
                    isRAdmin,
                    isAdmin,
                    isBotAdmin,
                    isPrems,
                    chatUpdate,
                    __dirname: ___dirname,
                    __filename
                }
                try {
                    await plugin.call(this, m, extra)
                    if (!isPrems) {
                        m.limit = m.limit || false
                        
                        }
                } catch (e) {
                    
                    m.error = e
                    console.error(e)
                    if (e) {
                        let text = format(e)
                        for (let key of Object.values(global.APIKey))
                            text = text.replace(new RegExp(key, 'g'), '#HIDDEN#')
                        if (e.name)
                            for (let [jid] of global.owner.filter(([number, _, isDeveloper]) => isDeveloper && number)) {
                                let data = (await conn.onWhatsApp(jid))[0] || {}
                                if (data.exists && global.conn.user.jid == this.user.jid)
                                    await m.reply(`❲ SYSTEM REPORT ❳
                                    
*📚Plugins:* ${name}
*👤Sender:* ${m.sender.split("@")[0]}
*💬Chat:* ${m.chat}
*📮Command:* ${m.text}
❲ ERROR LOG ❳ : 

\`\`\`${text}\`\`\`

${global.namebot}
`.trim(), null, data.jid)
                            }
                        await m.reply(text)
                    }
                } finally {
                    if (typeof plugin.after === 'function') {
                        try {
                            await plugin.after.call(this, m, extra)
                        } catch (e) {
                            console.error(e)
                        }
                    }
                }
                break
            }
        }
    } catch (e) {
        console.error(e)
    } finally {
        let user, stats = global.db.data.stats
        if (global.db.data.users[m.sender].limit < 0) global.db.data.users[m.sender].limit = 0;
        if (m) {
            if (m.sender && (user = global.db.data.users[m.sender]) && user.limit > 0) {
                user.exp += m.exp
                user.limit -= m.limit
            }

            let stat
            if (m.plugin) {
              let rn = ['recording','composing']
              let jd = rn[Math.floor(Math.random() * rn.length)]
              if (db.data.settings[this.user.jid].composing) await this.sendPresenceUpdate(jd,m.chat)
                let now = +new Date
                if (m.plugin in stats) {
                    stat = stats[m.plugin]
                    if (!isNumber(stat.total)) stat.total = 1
                    if (!isNumber(stat.success)) stat.success = m.error != null ? 0 : 1
                    if (!isNumber(stat.last)) stat.last = now
                    if (!isNumber(stat.lastSuccess)) stat.lastSuccess = m.error != null ? 0 : now
                } else stat = stats[m.plugin] = {
                    total: 1,
                    success: m.error != null ? 0 : 1,
                    last: now,
                    lastSuccess: m.error != null ? 0 : now
                }
                stat.total += 1
                
                if (m.isGroup) global.db.data.chats[m.chat].delay = now
                else global.db.data.users[m.sender].delay = now

                stat.last = now
                if (m.error == null) {
                    stat.success += 1
                    stat.lastSuccess = now
                }
            }
        }

        try {
            if (!opts['noprint']) await (await import(`./lib/print.js`)).default(m, this)
        } catch (e) {
            console.log(m, m.quoted, e)
        }
        if (global.db.data.settings[this.user.jid].autoreadpc && !m.isGroup) await this.readMessages([m.key])
        if (global.db.data.settings[this.user.jid].autoread) await this.readMessages([m.key])
    }
}



export async function participantsUpdate({ id, participants, action }) {
    if (global.db.data.settings[this.user.jid].self) return
    if (this.isInit) return

    if (global.db.data == null)
        await loadDatabase()

    let chat = global.db.data.chats[id] || {}
    let settings = global.db.data.settings[this.user.jid]
    let text = ''

    switch (action) {
        case 'add':
            case 'remove':
            if (chat.welcome) {
                let groupMetadata = await this.groupMetadata(id) || (conn.chats[id] || {}).metadata
                for (let user of participants) {
						let pp = 'https://telegra.ph/file/24fa902ead26340f3df2c.png'
						let ppgc = 'https://telegra.ph/file/24fa902ead26340f3df2c.png'
						let gcname = groupMetadata.subject
						try {
							pp = await this.profilePictureUrl(user, 'image')
							ppgc = await this.profilePictureUrl(id, 'image') 
						} catch (e) {} finally {
							text = (action === 'add' ? (chat.sWelcome || this.welcome || conn.welcome || 'Welcome, @user!').replace('@subject', await this.getName(id)).replace('@desc', groupMetadata.desc ? String.fromCharCode(8206).repeat(4001) + groupMetadata.desc : '') :
								(chat.sBye || this.bye || conn.bye || 'Bye, @user!')).replace(/@user/g, '@' + user.split`@`[0])
							let wel = pp
							let lea = pp
						    this.sendMessage(id, {
                            text: text,
                            contextInfo: {
                            mentionedJid: [user],
                            externalAdReply: {
                            showAdAttribution: true,
                            title: namebot,
                            thumbnailUrl: pp,
                            body: "Simple WhatsApp Bot By " + author,
                            mediaType: 1,
                            renderLargerThumbnail: true
                            }}}, {quoted: null})
                        }
						
					}
            }        
            break

        case 'promote':
            text = (chat.sPromote || this.spromote || conn.spromote || '@user ```is now Admin```')
            // Fall through intentionally to 'demote'

        case 'demote':
            if (!text)
                text = (chat.sDemote || this.sdemote || conn.sdemote || '@user ```is no longer Admin```')

            text = text.replace('@user', '@' + participants[0].split('@')[0])

            if (chat.detect)
                this.sendMessage(id, {
                    text,
                    mentions: this.parseMention(text)
                })
            break
    }
}
async function getMessage(key){
        if (store) {
            const msg = await store.loadMessage(key.remoteJid, key.id)
            return msg?.message
        }
        return {
            conversation: "Fuxxy"
        }
    }
async function appenTextMessage(text, chatUpdate) {
        let messages = await generateWAMessage(m.chat, { text: text, mentions: m.mentionedJid }, {
            userJid: conn.user.id,
            quoted: m.quoted && m.quoted.fakeObj
        })
        messages.key.fromMe = areJidsSameUser(m.sender, conn.user.id)
        messages.key.id = m.key.id
        messages.pushName = m.pushName
        if (m.isGroup) messages.participant = m.sender
        let msg = {
            ...chatUpdate,
            messages: [proto.WebMessageInfo.fromObject(messages)],
            type: 'append'
        }
        conn.ev.emit('messages.upsert', msg)
    }
    
export async function pollUpdate(chatUpdate) {
for(const { key, update } of chatUpdate) {
			if(update.pollUpdates && key.fromMe) {
				const pollCreation = await getMessage(key)
				if(pollCreation) {
				    const pollUpdate = await getAggregateVotesInPollMessage({
							message: pollCreation,
							pollUpdates: update.pollUpdates,
						})
	                var toCmd = pollUpdate.filter(v => v.voters.length !== 0)[0]?.name
	                if (toCmd == undefined) return
                    var prefCmd = prefix+toCmd
	                await appenTextMessage(prefCmd, chatUpdate)
		await conn.delay(1000)
		conn.sendMessage(key.remoteJid, { delete: key })
		}
		
				}
			}
		}
export async function groupsUpdate(groupsUpdate) {
    if (opts['self'])
        return
    for (const groupUpdate of groupsUpdate) {
        const id = groupUpdate.id
        if (!id) continue
        let chats = global.db.data.chats[id], text = ''
        if (!chats?.detect) continue
        if (groupUpdate.desc) text = (chats.sDesc || this.sDesc || conn.sDesc || '```Description has been changed to```\n@desc').replace('@desc', groupUpdate.desc)
        if (groupUpdate.icon) text = (chats.sIcon || this.sIcon || conn.sIcon || '```Icon has been changed to```').replace('@icon', groupUpdate.icon)
        if (groupUpdate.revoke) text = (chats.sRevoke || this.sRevoke || conn.sRevoke || '```Group link has been changed to```\n@revoke').replace('@revoke', groupUpdate.revoke)
        if (!text) continue
        await conn.sendMessage(id, { text: text })
    }
}

export async function antiCall(call) {
    this.call = this.call ? this.call : {};
    const callData = call[0];
    if (!global.db.data.settings[this.user.jid].anticall) return
    if (callData.id in this.call) return;
    console.log(callData);
    await this.sendMessage(callData.from, { 
        text: `Kamu tidak boleh menelepon bot.`
    });
    await this.rejectCall(callData.id, callData.from);
    this.call[callData.id] = true;
}

export async function deleteUpdate(message) {
    try {
        const { fromMe, id, remoteJid, participant} = message
        if (fromMe)
            return
        let msg = await this.serializeM(await this.loadMessage(id))
        if (!msg)
            return
        let chat = global.db.data.chats[remoteJid]
    
        if (chat.antidelete) {
        await this.reply(remoteJid, `
\`@${participant.split(`@`)[0]} Telah menghapus pesan\`
`.trim(), msg, {contextInfo: {
            mentionedJid: [participant]
            }
        })
        this.copyNForward(remoteJid, msg)
        }
    } catch (e) {
        console.error(e)
    }
}

global.dfail = (type, m, conn) => {
let tag = `@${m.sender.replace(/@.+/, '')}`
let mentionedJid = [m.sender]
let name = conn.getName(m.sender)

global.fkon = { key: { fromMe: false, participant: `${m.sender.split`@`[0]}@s.whatsapp.net`, ...(m.chat ? { remoteJid: m.sender } : {}) }, message: { contactMessage: { displayName: `${name}`, vcard: `BEGIN:VCARD\nVERSION:3.0\nN:;a,;;;\nFN:${name}\nitem1.TEL;waid=${m.sender.split('@')[0]}:${m.sender.split('@')[0]}\nitem1.X-ABLabel:Ponsel\nEND:VCARD`}}}

let msg = {
        premium: 'Sorry, this feature can only be used by *Premium* users.',
        vip: 'Sorry, this feature can only be used by *VIP* users.',
        group: 'This feature can only be used within groups',       
        private: 'This feature can only be used within private',       
        botAdmin: 'Make the bot an admin, to be able to access the group',
        admin: 'This feature is specifically for admin',
        restrict: 'Restrict Not Turned On For This Chat',
        adminonly: 'Feature has been disabled for members',
        groups: `Saat ini fitur hanya aktif untuk grup saja. silahkan gunakan fitur bot di dalam grup. Jika belum Join grup. Silahkan join lewat link ini\n${sgc}`,
        gconly: `You can't access the feature ❗\n Please join the Haruka Bot group to get access to the feature\n\n> ${sgc}`,
        game: 'Feature *Game* Not Turned On For This Chat',
        rpg: 'Feature *Rpg* Not Turned On For This Chat',
        rowner: `Real Owner only feature, *User* can't access it :!`,
        owner: `Owner only feature, *User* can't access it :!`,
        mods: 'This Feature is for Moderators Only!'
        }[type]
        
  if (msg) return conn.sendMessage(m.chat, {
      text: msg, 
      contextInfo: {
      externalAdReply: {
      title: 'ACCES DENIED',
      body: 'Cannot use this feature',
      thumbnailUrl: 'https://files.catbox.moe/a4bpur.jpg',
      sourceUrl: sgc,
      mediaType: 1,
      renderLargerThumbnail: true
      }}}, { quoted: fkon})
        
    let daftar = {
  unreg: `\`You are not registered in the Database. Please register immediately by typing:\`
  
- .daftar nama.umur`}[type]
  
  if (daftar) return conn.sendMessage(m.chat, {
      text: daftar,
      contextInfo: {
      externalAdReply: {
      title: 'YOU ARE NOT REGISTERED YET',
      body: 'Please Register first. Type: [.register]',
      thumbnailUrl: "https://files.catbox.moe/hz16wf.jpg",
      sourceUrl: sgc,
      mediaType: 1,
      renderLargerThumbnail: true
      }}}, { quoted: fkon})
        }

function ucapan() {
  const time = moment.tz('Asia/Jakarta').format('HH')
  let res = "Udah pagi ni kak masih belum tidur?"
  if (time >= 4) {
    res = "Pagi Kak 🌄"
  }
  if (time >= 10) {
    res = "Selamat Siang Kak ☀️"
  }
  if (time >= 15) {
    res = "Selamat Sore Kak 🌇"
  }
  if (time >= 18) {
    res = "Malam Kak 🌙"
  }
  return res
}

function pickRandom(list) {
     return list[Math.floor(Math.random() * list.length)]
     }

let file = global.__filename(import.meta.url, true)
watchFile(file, async () => {
    unwatchFile(file)
    console.log(chalk.redBright("Update 'handler.js'"))
    if (global.reloadHandler) console.log(await global.reloadHandler())
})