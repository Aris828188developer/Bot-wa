export default (conn, m) => {
	const isNumber = x => typeof x === 'number' && !isNaN(x)
	const delay = ms => isNumber(ms) && new Promise(resolve => setTimeout(function () {
		clearTimeout(this)
		resolve()
	}, ms))
	
	let user = global.db.data.users[m.sender]
    if (typeof user !== 'object')
                global.db.data.users[m.sender] = {}
            if (user) {
                if (!("BannedReason" in user)) user.BannedReason = ""
                if (!("Banneduser" in user)) user.Banneduser = false
                if (!("afkReason" in user)) user.afkReason = ""
                if (!("autolevelup" in user)) user.autolevelup = true
                if (!("banned" in user)) user.banned = false
                if (!("catatan" in user)) user.catatan = ""
                if (!("job" in user)) user.job = ""
                if (!("kingdom" in user)) user.kingdom = true
                if (!("misi" in user)) user.misi = ""
                if (!("moderator" in user)) user.moderator = false
                if (!("pasangan" in user)) user.pasangan = ""
                if (!("premium" in user)) user.premium = false
                if (!("owner" in user)) user.owner = false
                if (!("registered" in user)) user.registered = false
                if (!("role" in user)) user.role = "Beginner"
                if (!("sewa" in user)) user.sewa = false
                if (!("skill" in user)) user.skill = ""
                if (!("title" in user)) user.title = ""
                if (!("vip" in user)) user.vip = false
                if (!("lastonline" in user)) user.lastonline = new Date() * 1

                if (!user.registered) {
                    if (!("name" in user)) user.name = m.name
                    if (!isNumber(user.age)) user.age = -1
                    if (!isNumber(user.anggur)) user.anggur = 0
                    if (!isNumber(user.apel)) user.apel = 0
                    if (!isNumber(user.bibitanggur)) user.bibitanggur = 0
                    if (!isNumber(user.bibitapel)) user.bibitapel = 0
                    if (!isNumber(user.bibitjeruk)) user.bibitjeruk = 0
                    if (!isNumber(user.bibitmangga)) user.bibitmangga = 0
                    if (!isNumber(user.bibitpisang)) user.bibitpisang = 0
                    if (!isNumber(user.emas)) user.emas = 0
                    if (!isNumber(user.jeruk)) user.jeruk = 0
                    if (!isNumber(user.kayu)) user.kayu = 0
                    if (!isNumber(user.mangga)) user.mangga = 0
                    if (!isNumber(user.pisang)) user.pisang = 0
                    if (!isNumber(user.onwerDate)) user.ownerDate = -1
                    if (!isNumber(user.regTime)) user.regTime = -1
                    if (!isNumber(user.semangka)) user.semangka = 0
                    if (!isNumber(user.stroberi)) user.stroberi = 0
                }


                if (!isNumber(user.afk)) user.afk = -1
                if (!isNumber(user.agility)) user.agility = 0
                if (!isNumber(user.anggur)) user.anggur = 0
                if (!isNumber(user.antispam)) user.antispam = 0
                if (!isNumber(user.antispamlastclaim)) user.antispamlastclaim = 0
                if (!isNumber(user.apel)) user.apel = 0
                if (!isNumber(user.aqua)) user.aqua = 0
                if (!isNumber(user.arcdurability)) user.arcdurability = 0
                if (!isNumber(user.armor)) user.armor = 0
                if (!isNumber(user.armordurability)) user.armordurability = 0
                if (!isNumber(user.armormonster)) user.armormonster = 0
                if (!isNumber(user.atm)) user.atm = 0
                if (!isNumber(user.axe)) user.axe = 0
                if (!isNumber(user.axedurability)) user.axedurability = 0
                if (!isNumber(user.ayam)) user.ayam = 0
                if (!isNumber(user.babi)) user.babi = 0
                if (!isNumber(user.babihutan)) user.babihutan = 0
                if (!isNumber(user.bank)) user.bank = 0
                if (!isNumber(user.banteng)) user.banteng = 0
                if (!isNumber(user.batu)) user.batu = 0
                if (!isNumber(user.berlian)) user.berlian = 10
                if (!isNumber(user.bibitanggur)) user.bibitanggur = 0
                if (!isNumber(user.bibitapel)) user.bibitapel = 0
                if (!isNumber(user.bibitjeruk)) user.bibitjeruk = 0
                if (!isNumber(user.bibitmangga)) user.bibitmangga = 0
                if (!isNumber(user.bibitpisang)) user.bibitpisang = 0
                if (!isNumber(user.botol)) user.botol = 0
                if (!isNumber(user.bow)) user.bow = 0
                if (!isNumber(user.bowdurability)) user.bowdurability = 0
                if (!isNumber(user.boxs)) user.boxs = 0
                if (!isNumber(user.buaya)) user.buaya = 0
                if (!isNumber(user.buntal)) user.buntal = 0
                if (!isNumber(user.cat)) user.cat = 0
                if (!isNumber(user.catexp)) user.catexp = 0
                if (!isNumber(user.catlastfeed)) user.catlastfeed = 0
                if (!isNumber(user.centaur)) user.centaur = 0
                if (!isNumber(user.centaurexp)) user.centaurexp = 0
                if (!isNumber(user.centaurlastclaim)) user.centaurlastclaim = 0
                if (!isNumber(user.centaurlastfeed)) user.centaurlastfeed = 0
                if (!isNumber(user.clay)) user.clay = 0
                if (!isNumber(user.coal)) user.coal = 0
                if (!isNumber(user.coin)) user.coin = 0
                if (!isNumber(user.common)) user.common = 0
                if (!isNumber(user.crystal)) user.crystal = 0
                if (!isNumber(user.cumi)) user.cumi = 0
                if (!isNumber(user.cupon)) user.cupon = 0
                if (!isNumber(user.diamond)) user.diamond = 0
                if (!isNumber(user.dailylimit)) user.dailylimit = 0
                if (!isNumber(user.dog)) user.dog = 0
                if (!isNumber(user.dogexp)) user.dogexp = 0
                if (!isNumber(user.doglastfeed)) user.doglastfeed = 0
                if (!isNumber(user.dory)) user.dory = 0
                if (!isNumber(user.dragon)) user.dragon = 0
                if (!isNumber(user.dragonexp)) user.dragonexp = 0
                if (!isNumber(user.dragonlastfeed)) user.dragonlastfeed = 0
                if (!isNumber(user.emas)) user.emas = 0
                if (!isNumber(user.emerald)) user.emerald = 0
                if (!isNumber(user.enchant)) user.enchant = 0
                if (!isNumber(user.esteh)) user.esteh = 0
                if (!isNumber(user.exp)) user.exp = 0
                if (!isNumber(user.expg)) user.expg = 0
                if (!isNumber(user.exphero)) user.exphero = 0
                if (!isNumber(user.fishingrod)) user.fishingrod = 0
                if (!isNumber(user.fishingroddurability)) user.fishingroddurability = 0
                if (!isNumber(user.fortress)) user.fortress = 0
                if (!isNumber(user.freelimit)) user.freelimit = 0
                if (!isNumber(user.fullatm)) user.fullatm = Infinity
                if (!isNumber(user.gadodado)) user.gadodado = 0
                if (!isNumber(user.gajah)) user.gajah = 0
                if (!isNumber(user.gamemines)) user.gamemines = false
                if (!isNumber(user.ganja)) user.ganja = 0
                if (!isNumber(user.gardenboxs)) user.gardenboxs = 0
                if (!isNumber(user.gems)) user.gems = 0
                if (!isNumber(user.glass)) user.glass = 0
                if (!isNumber(user.glimit)) user.glimit = 20
                if (!isNumber(user.glory)) user.glory = 0
                if (!isNumber(user.gold)) user.gold = 0
                if (!isNumber(user.griffin)) user.griffin = 0
                if (!isNumber(user.griffinexp)) user.griffinexp = 0
                if (!isNumber(user.griffinlastclaim)) user.griffinlastclaim = 0
                if (!isNumber(user.griffinlastfeed)) user.griffinlastfeed = 0
                if (!isNumber(user.gulai)) user.gulai = 0
                if (!isNumber(user.gurita)) user.gurita = 0
                if (!isNumber(user.harimau)) user.harimau = 0
                if (!isNumber(user.haus)) user.haus = 100
                if (!isNumber(user.healt)) user.healt = 100
                if (!isNumber(user.health)) user.health = 100
                if (!isNumber(user.healthmonster)) user.healthmonster = 0
                if (!isNumber(user.healtmonster)) user.healtmonster = 0
                if (!isNumber(user.hero)) user.hero = 1
                if (!isNumber(user.herolastclaim)) user.herolastclaim = 0
                if (!isNumber(user.hiu)) user.hiu = 0
                if (!isNumber(user.horse)) user.horse = 0
                if (!isNumber(user.horseexp)) user.horseexp = 0
                if (!isNumber(user.horselastfeed)) user.horselastfeed = 0
                if (!isNumber(user.ikan)) user.ikan = 0
                if (!isNumber(user.intelligence)) user.intelligence = 0
                if (!isNumber(user.iron)) user.iron = 0
                if (!isNumber(user.jagung)) user.jagung = 0
                if (!isNumber(user.jeruk)) user.jeruk = 0
                if (!isNumber(user.kaleng)) user.kaleng = 0
                if (!isNumber(user.kambing)) user.kambing = 0
                if (!isNumber(user.kangkung)) user.kangkung = 0
                if (!isNumber(user.kapak)) user.kapak = 0
                if (!isNumber(user.kardus)) user.kardus = 0
                if (!isNumber(user.katana)) user.katana = 0
                if (!isNumber(user.katanadurability)) user.katanadurability = 0
                if (!isNumber(user.kayu)) user.kayu = 0
                if (!isNumber(user.kentang)) user.kentang = 0
                if (!isNumber(user.kentanggoreng)) user.kentanggoreng = 0
                if (!isNumber(user.kepiting)) user.kepiting = 0
                if (!isNumber(user.kerbau)) user.kerbau = 0
                if (!isNumber(user.kubis)) user.kubis = 0
                if (!isNumber(user.labu)) user.labu = 0
                if (!isNumber(user.lastadventure)) user.lastadventure = 0
                if (!isNumber(user.lastbansos)) user.lastbansos = 0
                if (!isNumber(user.lastberkebon)) user.lastberkebon = 0
                if (!isNumber(user.lastdagang)) user.lastdagang = 0
                if (!isNumber(user.lastduel)) user.lastduel = 0
                if (!isNumber(user.lastdungeon)) user.lastdungeon = 0
                if (!isNumber(user.lasteasy)) user.lasteasy = 0
                if (!isNumber(user.lastfight)) user.lastfight = 0
                if (!isNumber(user.lastfishing)) user.lastfishing = 0
                if (!isNumber(user.lastgift)) user.lastgift = 0
                if (!isNumber(user.lastgojek)) user.lastgojek = 0
                if (!isNumber(user.lastgrab)) user.lastgrab = 0
                if (!isNumber(user.lasthourly)) user.lasthourly = 0
                if (!isNumber(user.lasthunt)) user.lasthunt = 0
                if (!isNumber(user.lastjb)) user.lastjb = 0
                if (!isNumber(user.lastkill)) user.lastkill = 0
                if (!isNumber(user.lastmancingeasy)) user.lastmancing = 0
                if (!isNumber(user.lastmining)) user.lastmining = 0
                if (!isNumber(user.lastmisi)) user.lastmisi = 0
                if (!isNumber(user.lastmonthly)) user.lastmonthly = 0
                if (!isNumber(user.lastmulung)) user.lastmulung = 0
                if (!isNumber(user.lastnambang)) user.lastnambang = 0
                if (!isNumber(user.lastnebang)) user.lastnebang = 0
                if (!isNumber(user.lastngocok)) user.lastngocok = 0
                if (!isNumber(user.lastngojek)) user.lastngojek = 0
                if (!isNumber(user.lastopen)) user.lastopen = 0
                if (!isNumber(user.lastpekerjaan)) user.lastpekerjaan = 0
                if (!isNumber(user.lastrampok)) user.lastrampok = 0
                if (!isNumber(user.lastlont)) user.lastlont = 0
                if (!isNumber(user.lastrob)) user.lastrob = 0
                if (!isNumber(user.lastroket)) user.lastroket = 0
                if (!isNumber(user.lastweaponclaim)) user.lastweaponclaim = 0
                if (!isNumber(user.lastweekly)) user.lastweekly = 0
                if (!isNumber(user.lastwork)) user.lastwork = 0
                if (!isNumber(user.legendary)) user.legendary = 0
                if (!isNumber(user.lele)) user.lele = 0
                if (!isNumber(user.level)) user.level = 0
                if (!isNumber(user.limit)) user.limit = 10
                if (!isNumber(user.lobster)) user.lobster = 0
                if (!isNumber(user.lumba)) user.lumba = 0
                if (!isNumber(user.magicwand)) user.magicwand = 0
                if (!isNumber(user.magicwanddurability)) user.magicwanddurability = 0
                if (!isNumber(user.mana)) user.mana = 0
                if (!isNumber(user.mangga)) user.mangga = 0
                if (!isNumber(user.money)) user.money = 100
                if (!isNumber(user.monyet)) user.monyet = 0
                if (!isNumber(user.mythic)) user.mythic = 0
                if (!isNumber(user.net)) user.net = 0
                if (!isNumber(user.nila)) user.nila = 0
                if (!isNumber(user.ojekk)) user.ojekk = 0
                if (!isNumber(user.oporayam)) user.oporayam = 0
                if (!isNumber(user.orca)) user.orca = 0
                if (!isNumber(user.pancing)) user.pancing = 0
                if (!isNumber(user.pancingan)) user.pancingan = 1
                if (!isNumber(user.panda)) user.panda = 0
                if (!isNumber(user.paus)) user.paus = 0
                if (!isNumber(user.pc)) user.pc = 0
                if (!isNumber(user.pepesikan)) user.pepesikan = 0
                if (!isNumber(user.pertambangan)) user.pertambangan = 0
                if (!isNumber(user.pertanian)) user.pertanian = 0
                if (!isNumber(user.pet)) user.pet = 0
                if (!isNumber(user.petFood)) user.petFood = 0
                if (!isNumber(user.pickaxe)) user.pickaxe = 0
                if (!isNumber(user.pickaxedurability)) user.pickaxedurability = 0
                if (!isNumber(user.pillhero)) user.pillhero = 0
                if (!isNumber(user.pisang)) user.pisang = 0
                if (!isNumber(user.pointxp)) user.pointxp = 0
                if (!isNumber(user.potion)) user.potion = 0
                if (!isNumber(user.psenjata)) user.psenjata = 0
                if (!isNumber(user.psepick)) user.psepick = 0
                if (!isNumber(user.ramuan)) user.ramuan = 0
                if (!isNumber(user.reglast)) user.reglast = 0
                if (!isNumber(user.rendang)) user.rendang = 0
                if (!isNumber(user.rock)) user.rock = 0
                if (!isNumber(user.roket)) user.roket = 0
                if (!isNumber(user.roti)) user.roti = 0
                if (!isNumber(user.sampah)) user.sampah = 0
                if (!isNumber(user.sand)) user.sand = 0
                if (!isNumber(user.sapi)) user.sapi = 0
                if (!isNumber(user.sapir)) user.sapir = 0
                if (!isNumber(user.secret_document)) user.secret_document = 0
                if (!isNumber(user.seedbayam)) user.seedbayam = 0
                if (!isNumber(user.seedbrokoli)) user.seedbrokoli = 0
                if (!isNumber(user.seedjagung)) user.seedjagung = 0
                if (!isNumber(user.seedkangkung)) user.seedkangkung = 0
                if (!isNumber(user.seedkentang)) user.seedkentang = 0
                if (!isNumber(user.seedkubis)) user.seedkubis = 0
                if (!isNumber(user.seedlabu)) user.seedlabu = 0
                if (!isNumber(user.seedtomat)) user.seedtomat = 0
                if (!isNumber(user.seedwortel)) user.seedwortel = 0
                if (!isNumber(user.serigala)) user.serigala = 0
                if (!isNumber(user.serigalalastclaim)) user.serigalalastclaim = 0
                if (!isNumber(user.shield)) user.shield = false
                if (!isNumber(user.skillexp)) user.skillexp = 0
                if (!isNumber(user.soda)) user.soda = 0
                if (!isNumber(user.stamina)) user.stamina = 100
                if (!isNumber(user.steak)) user.steak = 0
                if (!isNumber(user.stick)) user.stick = 0
                if (!isNumber(user.strength)) user.strength = 0
                if (!isNumber(user.string)) user.string = 0
                if (!isNumber(user.superior)) user.superior = 0
                if (!isNumber(user.sushi)) user.sushi = 0
                if (!isNumber(user.sword)) user.sword = 0
                if (!isNumber(user.sworddurability)) user.sworddurability = 0
                if (!isNumber(user.tiketcoin)) user.tiketcoin = 0
                if (!isNumber(user.title)) user.title = 0
                if (!isNumber(user.tomat)) user.tomat = 0
                if (!isNumber(user.trash)) user.trash = 0
                if (!isNumber(user.trofi)) user.trofi = 0
                if (!isNumber(user.udang)) user.udang = 0
                if (!isNumber(user.umpan)) user.umpan = 0
                if (!isNumber(user.uncommon)) user.uncommon = 0
                if (!isNumber(user.upgrader)) user.upgrader = 0
                if (!isNumber(user.vodka)) user.vodka = 0
                if (!isNumber(user.vipTime)) user.vipTime = 0
                if (!isNumber(user.warn)) user.warn = 0
                if (!isNumber(user.weapon)) user.weapon = 0
                if (!isNumber(user.weapondurability)) user.weapondurability = 0
                if (!isNumber(user.wolf)) user.wolf = 0
                if (!isNumber(user.wolfexp)) user.wolfexp = 0
                if (!isNumber(user.wolflastfeed)) user.wolflastfeed = 0
                if (!isNumber(user.wood)) user.wood = 0
                if (!isNumber(user.wortel)) user.wortel = 0

                if (!user.job) user.job = "Pengangguran"
                if (!user.owner) user.owner = false
                if (!user.owner) user.ownerTime = 0
                if (!user.rtrofi) user.rtrofi = "Perunggu"
            } else
                global.db.data.users[m.sender] = {
                    afk: -1,
                    afkReason: "",
                    age: -1,
                    agility: 16,
                    anggur: 0,
                    antispam: 0,
                    antispamlastclaim: 0,
                    apel: 0,
                    aqua: 0,
                    arcdurability: 0,
                    arlok: 0,
                    armor: 0,
                    armordurability: 0,
                    armormonster: 0,
                    as: 0,
                    atm: 0,
                    autolevelup: true,
                    axe: 0,
                    axedurability: 0,
                    ayam: 0,
                    ayamb: 0,
                    babi: 0,
                    babihutan: 0,
                    bandage: 0,
                    bank: 0,
                    banned: false,
                    BannedReason: "",
                    Banneduser: false,
                    banteng: 0,
                    batu: 0,
                    bawal: 0,
                    bayam: 0,
                    berlian: 100,
                    bibitanggur: 0,
                    bibitapel: 0,
                    bibitjeruk: 0,
                    bibitmangga: 0,
                    bibitpisang: 0,
                    botol: 0,
                    bow: 0,
                    bowdurability: 0,
                    boxs: 0,
                    brick: 0,
                    brokoli: 0,
                    buaya: 0,
                    buntal: 0,
                    cat: 0,
                    catlastfeed: 0,
                    catngexp: 0,
                    centaur: 0,
                    centaurexp: 0,
                    centaurlastclaim: 0,
                    centaurlastfeed: 0,
                    clay: 0,
                    coal: 0,
                    coin: 0,
                    common: 0,
                    crystal: 0,
                    cumi: 0,
                    cupon: 0,
                    dailylimit: 0,
                    diamond: 0,
                    dog: 0,
                    dogexp: 0,
                    doglastfeed: 0,
                    dory: 0,
                    dragon: 0,
                    dragonexp: 0,
                    dragonlastfeed: 0,
                    emas: 0,
                    emerald: 0,
                    esteh: 0,
                    exp: 0,
                    expg: 0,
                    exphero: 0,
                    expired: 0,
                    fishingrod: 0,
                    fishingroddurability: 0,
                    fortress: 0,
                    freelimit: 0,
                    fullatm: Infinity,
                    gadodado: 0,
                    gajah: 0,
                    gamemines: false,
                    ganja: 0,
                    gardenboxs: 0,
                    gems: 0,
                    glass: 0,
                    gold: 0,
                    griffin: 0,
                    griffinexp: 0,
                    griffinlastclaim: 0,
                    griffinlastfeed: 0,
                    gulai: 0,
                    gurita: 0,
                    harimau: 0,
                    haus: 100,
                    healt: 100,
                    health: 100,
                    healtmonster: 100,
                    hero: 1,
                    herolastclaim: 0,
                    hiu: 0,
                    horse: 0,
                    horseexp: 0,
                    horselastfeed: 0,
                    ikan: 0,
                    intelligence: 10,
                    iron: 0,
                    jagung: 0,
                    jeruk: 0,
                    job: "Pengangguran",
                    judilast: 0,
                    kaleng: 0,
                    kambing: 0,
                    kangkung: 0,
                    kapak: 0,
                    kardus: 0,
                    katana: 0,
                    katanadurability: 0,
                    kayu: 0,
                    kentang: 0,
                    kentanggoreng: 0,
                    kepiting: 0,
                    kerbau: 0,
                    korbanngocok: 0,
                    kubis: 0,
                    labu: 0,
                    lastadventure: 0,
                    lastberkebon: 0,
                    lastdagang: 0,
                    lastduel: 0,
                    lastlont: 0,
                    lastdungeon: 0,
                    lastonline: new Date() * 1,
                    lasteasy: 0,
                    lastfight: 0,
                    lastfishing: 0,
                    lastgojek: 0,
                    lasthourly: 0,
                    lasthunt: 0,
                    lastjb: 0,
                    lastkill: 0,
                    lastmancing: 0,
                    lastmining: 0,
                    lastmisi: 0,
                    lastmonthly: 0,
                    lastmulung: 0,
                    lastnambang: 0,
                    lastnebang: 0,
                    lastngocok: 0,
                    lastngojek: 0,
                    lastopen: 0,
                    lastpekerjaan: 0,
                    lastrob: 0,
                    lastroket: 0,
                    lastsmancingclaim: 0,
                    lastweekly: 0,
                    lastwork: 0,
                    legendary: 0,
                    lele: 0,
                    leleb: 0,
                    leleg: 0,
                    level: 0,
                    limit: 10,
                    lobster: 0,
                    lumba: 0,
                    magicwand: 0,
                    magicwanddurability: 0,
                    mana: 20,
                    mangga: 0,
                    misi: "",
                    moderator: false,
                    money: 100,
                    monyet: 0,
                    mythic: 0,
                    naga: 0,
                    nagalastclaim: 0,
                    name: m.name,
                    net: 0,
                    nila: 0,
                    catatan: "",
                    ojekk: 0,
                    oporayam: 0,
                    orca: 0,
                    owner: false,
                    ownerTime: 0,
                    pancingan: 1,
                    panda: 0,
                    pasangan: "",
                    paus: 0,
                    pc: 0,
                    pepesikan: 0,
                    pet: 0,
                    pickaxe: 0,
                    pickaxedurability: 0,
                    pillhero: 0,
                    pisang: 0,
                    pointxp: 0,
                    potion: 10,
                    premium: false,
                    premiumTime: 0,
                    ramuan: 0,
                    registered: false,
                    reglast: 0,
                    regTime: -1,
                    rendang: 0,
                    rock: 0,
                    roket: 0,
                    role: "Newbie ㋡",
                    roti: 0,
                    rtrofi: "perunggu",
                    sampah: 0,
                    sand: 0,
                    sapi: 0,
                    sapir: 0,
                    secret_document: 0,
                    seedbayam: 0,
                    seedbrokoli: 0,
                    seedjagung: 0,
                    seedkangkung: 0,
                    seedkentang: 0,
                    seedkubis: 0,
                    seedlabu: 0,
                    seedtomat: 0,
                    seedwortel: 0,
                    semangka: 0,
                    serigala: 0,
                    serigalalastclaim: 0,
                    sewa: false,
                    shield: 0,
                    skill: "",
                    skillexp: 0,
                    snlast: 0,
                    soda: 0,
                    sop: 0,
                    spammer: 0,
                    spinlast: 0,
                    ssapi: 0,
                    stamina: 100,
                    steak: 0,
                    stick: 0,
                    strength: 30,
                    string: 0,
                    stroberi: 0,
                    superior: 0,
                    suplabu: 0,
                    sushi: 0,
                    sword: 0,
                    sworddurability: 0,
                    tigame: 50,
                    tiketcoin: 0,
                    title: "",
                    tomat: 0,
                    tprem: 0,
                    trash: 0,
                    trofi: 0,
                    troopcamp: 0,
                    udang: 0,
                    umpan: 0,
                    uncommon: 0,
                    unreglast: 0,
                    upgrader: 0,
                    vodka: 0,
                    vip: false,
                    vipTime: 0,
                    wallet: 0,
                    warn: 0,
                    weapon: 0,
                    weapondurability: 0,
                    wolf: 0,
                    wolfexp: 0,
                    wolflastfeed: 0,
                    wood: 0,
                    wortel: 0,
                }
            let chat = global.db.data.chats[m.chat]
            if (typeof chat !== 'object')
                global.db.data.chats[m.chat] = {}
            if (chat) {
            	if (!('antidelete' in chat))
                    chat.antidelete = true
                if (!('antiMeta' in chat))
                    chat.antiMeta = true
                if (!('welcome' in chat))
                    chat.welcome = false
                if (!('detect' in chat))
                    chat.detect = false
                if (!('sWelcome' in chat))
                    chat.sWelcome = ''
                if (!('sBye' in chat))
                    chat.sBye = ''
                if (!('sPromote' in chat))
                    chat.sPromote = ''
                if (!('sDemote' in chat))
                    chat.sDemote = ''
                if (!('delete' in chat))
                    chat.delete = false
                if (!('antiedit' in chat))
                    chat.antiedit = false
                if (!('antiLink' in chat))
                    chat.antiLink = false
                if (!('antiSpam' in chat)) 
                    chat.antiSpam = false
                if (!('antiTagsw' in chat))
                    chat.antiTagsw = true
                if (!('antiToxic' in chat))
                    chat.antiToxic = false
                if (!('viewonce' in chat))
                    chat.viewonce = false
                if (!('antiToxic' in chat)) 
                    chat.antiBadword = false
                if (!('antiNsfw' in chat)) 
                    chat.antiNsfw = false
                if (!isNumber(chat.expired))
                    chat.expired = 0
            } else
                global.db.data.chats[m.chat] = {
                	antidelete: true,
                    isBanned: false,
                    antiSpam: false,
                    welcome: true,
                    bye: true,
                    detect: false,
                    sWelcome: '',
                    sBye: '',
                    sPromote: '',
                    sDemote: '',
                    viewonce: false,
                    antiToxic: false,
                    antiTagsw: false,
                    simi: false,
                    expired: 0,
                    rpg: false,
                    games: false
                }
            let settings = global.db.data.settings[conn.user.jid]
            if (typeof settings !== 'object') global.db.data.settings[conn.user.jid] = {}
            if (settings) {
                if (!('self' in settings)) settings.self = false
                if (!('rownerOnly' in settings)) settings.rownerOnly = false
                if (!('allakses' in settings)) settings.allakses = false
                if (!('autoread' in settings)) settings.autoread = true
                if (!("autoreadpc" in settings)) settings.autoreadpc = true
                if (!('adReply' in settings)) settings.adReply = false
                if (!('restrict' in settings)) settings.restrict = true
                if (!('autorestart' in settings)) settings.autorestart = true
                if (!('anticall' in settings)) settings.anticall = true
                if (!('image' in settings)) settings.image = true
                if (!('gif' in settings)) settings.gif = false 
                if (!('composing' in settings)) settings.composing = false
                if (!('teks' in settings)) settings.teks = false
                if (!('doc' in settings)) settings.doc = false
                if (!('button' in settings)) settings.button = false
                if (!('backupDB' in settings)) settings.restartDB = false
            } else global.db.data.settings[conn.user.jid] = {
                self: false,
                rownerOnly: false,
                allakses: false,
                autoBio: false,
                adminonly: false,
                adReply: false,
                autoread: true,
                autoreadpc: true,
                anticall: true, 
                restrict: true,
                image: true,
                gif: false,
                composing: true,
                teks: false,
                doc: false,
                button: false,
                gcImg: true,
                gcGif: false,
                gcTeks: false,
                gcDoc: false,
                timeChat: 0,
                resetTime: 0,
                backupDB: false,
                backup: false
      }
      let rpg = global.db.data.rpg
      if (typeof rpg !== 'object') global.db.data.rpg = {}
      if (rpg) {
         if (!('ah' in rpg)) rpg.ah = {}
      } else global.db.data.rpg = {
         ah: {}
      }
}

global.rpg = {
	emoticon: (string) => {
        string = string.toLowerCase()
        let emot = {
            level: '📊',
            limit: '🎫',
            health: '❤️',
            exp: '✨',
            atm: '💳',
            money: '💰',
            bank: '🏦',
            potion: '🥤',
            diamond: '💎',
            common: '📦',
            uncommon: '🛍️',
            mythic: '🎁',
            legendary: '🗃️',
            superior: '💼',
            pet: '🔖',
            trash: '🗑',
            armor: '🥼',
            sword: '⚔️',
            pickaxe: '⛏️',
            fishingrod: '🎣',
            wood: '🪵',
            rock: '🪨',
            string: '🕸️',
            horse: '🐴',
            cat: '🐱',
            dog: '🐶',
            fox: '🦊',
            robo: '🤖',
            petfood: '🍖',
            iron: '⛓️',
            gold: '🪙',
            emerald: '❇️',
            upgrader: '🧰',
            bibitanggur: '🌱',
            bibitjeruk: '🌿',
            bibitapel: '☘️',
            bibitmangga: '🍀',
            bibitpisang: '🌴',
            anggur: '🍇',
            jeruk: '🍊',
            apel: '🍎',
            mangga: '🥭',
            pisang: '🍌',
            botol: '🍾',
            kardus: '📦',
            kaleng: '🏮',
            plastik: '📜',
            gelas: '🧋',
            chip: '♋',
            umpan: '🪱',
            skata: '🧩',
            kecap: '🍾',
                gula: '🍶',
                asam: '🌿',
                jahe: '🫚',
                garam: '🧂',
                cabai: '??️',
                bawang: '🧄',
                kemiri: '🫚',
                kunyit: '🫚',
                terasi: '🧂',
                nuggets: '🍗',
rendang: '🍛',
salads: '🥗',
steak: '🥩',
candy: '🍬',
ramen: '🍜',
pizza: '🍕',
vodka: '🍸',
sushi: '🍣',
bandage: '🩹',
ganja: '🌿',
soda: '🥤',
roti: '🍞',
spagetti: '🍝',
croissant: '🥐',
onigiri: '🍙',
hamburger: '🍔',
hotdog: '🌭',
cake: '🍰',
sandwich: '🥪',
escream: '🍦',
pudding: '🍮',
juice: '🧃',
teh: '🍵',
popcorn: '🍿',
kopi: '☕',
boba: '🧋',
susu: '🥛',
kopimatcha: '🍵',
soju: '🍶',
soup: '🥣',
kentang: '🍟',
rawon: '🍲',
semur: '🥘',
nasiuduk: '🍚',
soto: '🍲',
sate: '🍢',
ayamgoreng: '🍗',
babiguling: '🐷',
mieayam: '🍜',
ikanbakar: '🐟',
ayamgulai: '🍛',
pempek: '🍥'
        }
        let results = Object.keys(emot).map(v => [v, new RegExp(v, 'gi')]).filter(v => v[1].test(string))
        if (!results.length) return ''
        else return emot[results[0][0]]
    }
}